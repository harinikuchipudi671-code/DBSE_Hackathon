const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const { createSlot, getSlotsByStation, updateSlot, deleteSlot } = require('../controllers/slotController');

router.post('/', authenticate, authorize('HOMEOWNER'), createSlot);
router.get('/:stationId', authenticate, getSlotsByStation);
router.put('/:id', authenticate, authorize('HOMEOWNER'), updateSlot);
router.delete('/:id', authenticate, authorize('HOMEOWNER'), deleteSlot);

module.exports = router;
