const prisma = require('../config/database');
const { v4: uuidv4 } = require('uuid');

const createNotification = async (userId, title, message, type) => {
  try { await prisma.notification.create({ data: { userId, title, message, notificationType: type } }); }
  catch (e) { console.error(e); }
};

// POST /api/sessions/start
const startSession = async (req, res) => {
  try {
    const { reservationId } = req.body;
    if (!reservationId) return res.status(400).json({ success: false, message: 'reservationId is required' });

    const reservation = await prisma.reservation.findUnique({
      where: { id: parseInt(reservationId) },
      include: { station: true, chargingSession: true }
    });

    if (!reservation) return res.status(404).json({ success: false, message: 'Reservation not found' });
    if (reservation.station.homeownerId !== req.user.id) return res.status(403).json({ success: false, message: 'Only the homeowner can start sessions' });
    if (reservation.bookingStatus !== 'CONFIRMED') return res.status(400).json({ success: false, message: 'Only confirmed reservations can start a session' });
    if (reservation.chargingSession) return res.status(409).json({ success: false, message: 'Session already started' });

    const session = await prisma.chargingSession.create({
      data: {
        reservationId: parseInt(reservationId),
        sessionStart: new Date(),
        pricePerKwh: reservation.station.pricePerKwh,
        sessionStatus: 'ACTIVE'
      }
    });

    await createNotification(reservation.evOwnerId, 'Charging Session Started', `Your charging session at ${reservation.station.stationName} has started!`, 'SESSION');

    res.status(201).json({ success: true, message: 'Charging session started', data: session });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// PATCH /api/sessions/:id/complete
const completeSession = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { energyConsumedKwh } = req.body;

    if (!energyConsumedKwh || parseFloat(energyConsumedKwh) <= 0) {
      return res.status(400).json({ success: false, message: 'Valid energy consumed (kWh) is required' });
    }

    const session = await prisma.chargingSession.findUnique({
      where: { id },
      include: { reservation: { include: { station: true } } }
    });

    if (!session) return res.status(404).json({ success: false, message: 'Session not found' });
    if (session.reservation.station.homeownerId !== req.user.id) return res.status(403).json({ success: false, message: 'Not authorized' });
    if (session.sessionStatus !== 'ACTIVE') return res.status(400).json({ success: false, message: 'Session is not active' });

    const energy = parseFloat(energyConsumedKwh);
    const totalAmount = parseFloat((energy * session.pricePerKwh).toFixed(2));

    const updated = await prisma.$transaction(async (tx) => {
      const updatedSession = await tx.chargingSession.update({
        where: { id },
        data: {
          sessionEnd: new Date(),
          energyConsumedKwh: energy,
          totalAmount,
          sessionStatus: 'COMPLETED'
        }
      });

      await tx.reservation.update({
        where: { id: session.reservationId },
        data: { bookingStatus: 'COMPLETED' }
      });

      return updatedSession;
    });

    const reservation = session.reservation;
    await createNotification(reservation.evOwnerId, 'Charging Complete', `Session ended. Energy: ${energy} kWh. Total: ₹${totalAmount.toFixed(2)}`, 'SESSION');
    await createNotification(reservation.station.homeownerId, 'Session Completed', `Charging session completed. Earned: ₹${totalAmount.toFixed(2)}`, 'PAYMENT');

    res.json({ success: true, message: 'Session completed', data: updated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/sessions/history
const getSessionHistory = async (req, res) => {
  try {
    let sessions;
    if (req.user.role === 'HOMEOWNER') {
      const stations = await prisma.chargingStation.findMany({ where: { homeownerId: req.user.id }, select: { id: true } });
      const stationIds = stations.map(s => s.id);
      sessions = await prisma.chargingSession.findMany({
        where: { reservation: { stationId: { in: stationIds } } },
        include: {
          reservation: {
            include: {
              evOwner: { select: { fullName: true, email: true } },
              station: { select: { stationName: true, pricePerKwh: true } }
            }
          },
          payment: true
        },
        orderBy: { sessionStart: 'desc' }
      });
    } else {
      sessions = await prisma.chargingSession.findMany({
        where: { reservation: { evOwnerId: req.user.id } },
        include: {
          reservation: {
            include: {
              station: { select: { stationName: true, completeAddress: true, pricePerKwh: true } }
            }
          },
          payment: true
        },
        orderBy: { sessionStart: 'desc' }
      });
    }
    res.json({ success: true, data: sessions });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// POST /api/payments
const createPayment = async (req, res) => {
  try {
    const { sessionId, paymentMethod } = req.body;
    if (!sessionId || !paymentMethod) return res.status(400).json({ success: false, message: 'sessionId and paymentMethod are required' });

    const session = await prisma.chargingSession.findUnique({
      where: { id: parseInt(sessionId) },
      include: {
        payment: true,
        reservation: { include: { station: true, evOwner: true } }
      }
    });

    if (!session) return res.status(404).json({ success: false, message: 'Session not found' });
    if (session.sessionStatus !== 'COMPLETED') return res.status(400).json({ success: false, message: 'Session must be completed before payment' });
    if (session.payment) return res.status(409).json({ success: false, message: 'Payment already exists for this session' });
    if (session.reservation.evOwnerId !== req.user.id) return res.status(403).json({ success: false, message: 'Not authorized' });

    // Server-side amount calculation — never trust client
    const amount = session.totalAmount;
    const transactionReference = 'TXN-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9).toUpperCase();

    const payment = await prisma.payment.create({
      data: {
        sessionId: parseInt(sessionId),
        payerId: req.user.id,
        receiverId: session.reservation.station.homeownerId,
        amount,
        paymentMethod,
        paymentStatus: 'COMPLETED',
        transactionReference
      }
    });

    await createNotification(session.reservation.station.homeownerId, 'Payment Received', `Payment of ₹${amount.toFixed(2)} received via ${paymentMethod}. TXN: ${transactionReference}`, 'PAYMENT');

    res.status(201).json({ success: true, message: 'Payment recorded', data: payment });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/payments/history
const getPaymentHistory = async (req, res) => {
  try {
    const payments = await prisma.payment.findMany({
      where: {
        OR: [{ payerId: req.user.id }, { receiverId: req.user.id }]
      },
      include: {
        session: {
          include: {
            reservation: {
              include: {
                station: { select: { stationName: true } },
                evOwner: { select: { fullName: true } }
              }
            }
          }
        },
        payer: { select: { fullName: true } },
        receiver: { select: { fullName: true } }
      },
      orderBy: { paymentDate: 'desc' }
    });
    res.json({ success: true, data: payments });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { startSession, completeSession, getSessionHistory, createPayment, getPaymentHistory };
