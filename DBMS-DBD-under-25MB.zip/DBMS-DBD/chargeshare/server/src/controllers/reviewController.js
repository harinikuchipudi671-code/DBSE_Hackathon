const prisma = require('../config/database');

// POST /api/reviews
const createReview = async (req, res) => {
  try {
    const { reservationId, rating, comment } = req.body;
    if (!reservationId || !rating) return res.status(400).json({ success: false, message: 'reservationId and rating are required' });
    if (rating < 1 || rating > 5) return res.status(400).json({ success: false, message: 'Rating must be between 1 and 5' });

    const reservation = await prisma.reservation.findUnique({
      where: { id: parseInt(reservationId) },
      include: { station: true, review: true }
    });

    if (!reservation) return res.status(404).json({ success: false, message: 'Reservation not found' });
    if (reservation.evOwnerId !== req.user.id) return res.status(403).json({ success: false, message: 'Only the EV owner can leave a review' });
    if (reservation.bookingStatus !== 'COMPLETED') return res.status(400).json({ success: false, message: 'Can only review completed reservations' });
    if (reservation.review) return res.status(409).json({ success: false, message: 'Review already submitted for this reservation' });

    const review = await prisma.review.create({
      data: {
        reservationId: parseInt(reservationId),
        reviewerId: req.user.id,
        homeownerId: reservation.station.homeownerId,
        stationId: reservation.stationId,
        rating: parseInt(rating),
        comment
      },
      include: { reviewer: { select: { fullName: true, profileImage: true } } }
    });

    await prisma.notification.create({
      data: {
        userId: reservation.station.homeownerId,
        title: 'New Review Received',
        message: `You received a ${rating}-star review for ${reservation.station.stationName}`,
        notificationType: 'REVIEW'
      }
    });

    res.status(201).json({ success: true, message: 'Review submitted', data: review });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/stations/:id/reviews
const getStationReviews = async (req, res) => {
  try {
    const stationId = parseInt(req.params.id);
    const reviews = await prisma.review.findMany({
      where: { stationId },
      include: { reviewer: { select: { fullName: true, profileImage: true } } },
      orderBy: { createdAt: 'desc' }
    });
    const avg = reviews.length ? (reviews.reduce((a, r) => a + r.rating, 0) / reviews.length).toFixed(1) : null;
    res.json({ success: true, data: { reviews, avgRating: avg, count: reviews.length } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/notifications
const getNotifications = async (req, res) => {
  try {
    const notifications = await prisma.notification.findMany({
      where: { userId: req.user.id },
      orderBy: { createdAt: 'desc' },
      take: 50
    });
    res.json({ success: true, data: notifications });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// PATCH /api/notifications/:id/read
const markRead = async (req, res) => {
  try {
    if (req.params.id === 'all') {
      await prisma.notification.updateMany({ where: { userId: req.user.id, isRead: false }, data: { isRead: true } });
      return res.json({ success: true, message: 'All notifications marked read' });
    }
    const id = parseInt(req.params.id);
    const notif = await prisma.notification.findUnique({ where: { id } });
    if (!notif || notif.userId !== req.user.id) return res.status(404).json({ success: false, message: 'Not found' });
    await prisma.notification.update({ where: { id }, data: { isRead: true } });
    res.json({ success: true, message: 'Notification marked as read' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/admin/dashboard
const getAdminDashboard = async (req, res) => {
  try {
    const [users, stations, reservations, sessions, payments, reviews] = await Promise.all([
      prisma.user.count(),
      prisma.chargingStation.count(),
      prisma.reservation.groupBy({ by: ['bookingStatus'], _count: true }),
      prisma.chargingSession.count(),
      prisma.payment.aggregate({ _sum: { amount: true }, _count: true }),
      prisma.review.aggregate({ _avg: { rating: true }, _count: true })
    ]);

    const totalRevenue = payments._sum.amount || 0;
    res.json({
      success: true,
      data: {
        totalUsers: users,
        totalStations: stations,
        reservationsByStatus: reservations,
        totalSessions: sessions,
        totalPayments: payments._count,
        totalRevenue: totalRevenue.toFixed(2),
        avgRating: reviews._avg.rating?.toFixed(1) || '0',
        totalReviews: reviews._count
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/admin/users
const getAdminUsers = async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      select: {
        id: true, fullName: true, email: true, role: true, phoneNumber: true,
        createdAt: true,
        _count: { select: { chargingStations: true, reservationsAsEV: true } }
      },
      orderBy: { createdAt: 'desc' }
    });
    res.json({ success: true, data: users });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/admin/stations
const getAdminStations = async (req, res) => {
  try {
    const stations = await prisma.chargingStation.findMany({
      include: {
        homeowner: { select: { fullName: true, email: true } },
        _count: { select: { reservations: true } }
      },
      orderBy: { createdAt: 'desc' }
    });
    const mapped = stations.map(s => ({ ...s, amenities: s.amenities ? JSON.parse(s.amenities) : [] }));
    res.json({ success: true, data: mapped });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// PATCH /api/admin/stations/:id/status
const updateStationStatus = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { verificationStatus, isActive } = req.body;
    const updated = await prisma.chargingStation.update({
      where: { id },
      data: {
        verificationStatus: verificationStatus || undefined,
        isActive: isActive !== undefined ? isActive : undefined
      }
    });
    res.json({ success: true, message: 'Station status updated', data: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { createReview, getStationReviews, getNotifications, markRead, getAdminDashboard, getAdminUsers, getAdminStations, updateStationStatus };
