import { useAuth } from '../context/AuthContext';
import HomeownerDashboard from './HomeownerDashboard';
import EVOwnerDashboard from './EVOwnerDashboard';
import AdminDashboard from './AdminDashboard';

export default function Dashboard() {
  const { user } = useAuth();

  if (user?.role === 'HOMEOWNER') return <HomeownerDashboard />;
  if (user?.role === 'ADMIN') return <AdminDashboard />;
  return <EVOwnerDashboard />;
}
