import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Calendar, Clock, Zap, MapPin, Star, X
} from 'lucide-react';
import DashboardLayout from '../layouts/DashboardLayout';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function Reservations() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [actionLoading, setActionLoading] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Review modal state
  const [reviewModalOpen, setReviewModalOpen] = useState(false);
  const [reviewReservation, setReviewReservation] = useState(null);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    fetchReservations();
  }, [user]);

  const fetchReservations = async () => {
    try {
      setLoading(true);
      setErrorMsg('');
      const endpoint = user?.role === 'HOMEOWNER' ? '/reservations/received' : '/reservations/my';
      const res = await api.get(endpoint);
      setReservations(res.data?.data || res.data || []);
    } catch (err) {
      console.error('Error fetching reservations:', err);
      setErrorMsg('Failed to load reservations.');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (id, status) => {
    try {
      setActionLoading(id);
      await api.patch(`/reservations/${id}/status`, { status });
      setSuccessMsg(`Reservation ${status.toLowerCase()} successfully.`);
      fetchReservations();
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Failed to update reservation status.');
    } finally {
      setActionLoading(null);
    }
  };

  const handleCancelReservation = async (id) => {
    if (!window.confirm('Are you sure you want to cancel this reservation?')) return;
    try {
      setActionLoading(id);
      await api.post(`/reservations/${id}/cancel`);
      setSuccessMsg('Reservation cancelled.');
      fetchReservations();
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Failed to cancel reservation.');
    } finally {
      setActionLoading(null);
    }
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    if (!reviewReservation) return;
    try {
      setSubmittingReview(true);
      await api.post('/reviews', {
        stationId: reviewReservation.stationId,
        reservationId: reviewReservation.id,
        rating: Number(rating),
        comment,
      });
      setSuccessMsg('Thank you for your review!');
      setReviewModalOpen(false);
      fetchReservations();
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Failed to submit review.');
    } finally {
      setSubmittingReview(false);
    }
  };

  const filteredReservations = reservations.filter((r) => {
    const s = r.bookingStatus || r.status;
    if (statusFilter === 'ALL') return true;
    return s === statusFilter;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case 'CONFIRMED':
        return <span className="badge badge-confirmed">Confirmed</span>;
      case 'PENDING':
        return <span className="badge badge-pending">Pending</span>;
      case 'COMPLETED':
        return <span className="badge badge-completed">Completed</span>;
      case 'REJECTED':
        return <span className="badge badge-rejected">Rejected</span>;
      case 'CANCELLED':
        return <span className="badge badge-cancelled">Cancelled</span>;
      default:
        return <span className="badge badge-pending">{status}</span>;
    }
  };

  return (
    <DashboardLayout>
      <div style={{ paddingBottom: 40 }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 16, marginBottom: 20 }}>
          <div>
            <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
              {user?.role === 'HOMEOWNER' ? 'Booking Inquiries' : 'My Reservations'}
            </h1>
            <p style={{ color: '#8a8f98', fontSize: 13 }}>
              {user?.role === 'HOMEOWNER'
                ? 'Review and manage incoming driver reservation requests'
                : 'Track upcoming charging windows and verify reservation approvals'}
            </p>
          </div>

          {user?.role === 'EV_OWNER' && (
            <Link to="/find" className="btn-primary" style={{ textDecoration: 'none', padding: '7px 14px', fontSize: 13 }}>
              <Zap size={14} /> Book Charger
            </Link>
          )}
        </div>

        {/* Feedback alerts */}
        {errorMsg && (
          <div
            style={{
              background: 'rgba(235, 87, 87, 0.1)',
              border: '1px solid rgba(235, 87, 87, 0.25)',
              color: '#f87171',
              padding: '10px 14px',
              borderRadius: 6,
              marginBottom: 16,
              fontSize: 12,
            }}
          >
            {errorMsg}
          </div>
        )}
        {successMsg && (
          <div
            style={{
              background: 'rgba(39, 166, 68, 0.1)',
              border: '1px solid rgba(39, 166, 68, 0.25)',
              color: '#34d399',
              padding: '10px 14px',
              borderRadius: 6,
              marginBottom: 16,
              fontSize: 12,
            }}
          >
            {successMsg}
          </div>
        )}

        {/* Filter Segmented Controls */}
        <div
          style={{
            display: 'inline-flex',
            gap: 2,
            background: '#0f1011',
            padding: 3,
            borderRadius: 6,
            border: '1px solid #23252a',
            marginBottom: 16,
          }}
        >
          {['ALL', 'PENDING', 'CONFIRMED', 'COMPLETED', 'CANCELLED'].map((tab) => {
            const active = statusFilter === tab;
            return (
              <button
                key={tab}
                onClick={() => setStatusFilter(tab)}
                style={{
                  padding: '5px 12px',
                  borderRadius: 4,
                  fontSize: 12,
                  fontWeight: active ? 500 : 400,
                  border: 'none',
                  cursor: 'pointer',
                  background: active ? '#191a1b' : 'transparent',
                  color: active ? '#f7f8f8' : '#8a8f98',
                  transition: 'all 0.15s ease',
                }}
              >
                {tab.charAt(0) + tab.slice(1).toLowerCase()}
              </button>
            );
          })}
        </div>

        {/* List of Reservations */}
        {loading ? (
          <div style={{ textAlign: 'center', padding: 60, color: '#8a8f98' }}>
            <div className="spinner mx-auto mb-3" />
            Fetching reservations...
          </div>
        ) : filteredReservations.length === 0 ? (
          <div className="panel" style={{ padding: '48px 20px', textAlign: 'center' }}>
            <Calendar size={28} color="#3e3e44" style={{ margin: '0 auto 10px' }} />
            <h3 style={{ color: '#f7f8f8', fontWeight: 500, fontSize: 14, marginBottom: 4 }}>
              No Reservations Found
            </h3>
            <p style={{ fontSize: 12, color: '#62666d' }}>
              {statusFilter === 'ALL'
                ? 'No reservation history recorded.'
                : `No bookings found matching filter "${statusFilter}".`}
            </p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {filteredReservations.map((res) => {
              const station = res.station || {};
              const currentStatus = res.bookingStatus || res.status;
              const dateStr = res.bookingDate
                ? new Date(res.bookingDate).toLocaleDateString(undefined, {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                  })
                : 'N/A';

              return (
                <div
                  key={res.id}
                  className="panel"
                  style={{
                    padding: '16px 18px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'flex-start',
                    flexWrap: 'wrap',
                    gap: 14,
                  }}
                >
                  {/* Left Info */}
                  <div style={{ flex: '1 1 300px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      {getStatusBadge(currentStatus)}
                      <span style={{ fontSize: 11, color: '#62666d', fontFamily: 'monospace' }}>
                        #{res.id.slice(0, 8)}
                      </span>
                    </div>

                    <h3 style={{ fontSize: 14, fontWeight: 500, color: '#f7f8f8', marginBottom: 2 }}>
                      {station.stationName || station.name || 'Charging Station'}
                    </h3>

                    <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: '#8a8f98', fontSize: 11, marginBottom: 8 }}>
                      <MapPin size={12} color="#62666d" />
                      <span>{station.completeAddress || station.address || 'Mumbai'}</span>
                    </div>

                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, fontSize: 12, color: '#d0d6e0' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                        <Calendar size={13} color="#8a8f98" />
                        <span style={{ fontFamily: 'monospace' }}>{dateStr}</span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                        <Clock size={13} color="#8a8f98" />
                        <span style={{ fontFamily: 'monospace' }}>
                          {res.startTime} – {res.endTime}
                        </span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                        <Zap size={13} color="#8a8f98" />
                        <span style={{ fontFamily: 'monospace' }}>{res.estimatedKwh || 20} kWh est.</span>
                      </div>
                    </div>

                    {/* Driver or Host metadata */}
                    <div style={{ marginTop: 8, fontSize: 11, color: '#62666d' }}>
                      {user?.role === 'HOMEOWNER' ? (
                        <span>
                          Driver: <strong style={{ color: '#d0d6e0' }}>{res.evOwner?.fullName || res.user?.fullName || 'Driver'}</strong> · Vehicle:{' '}
                          <span style={{ color: '#f7f8f8' }}>{res.vehicleModel || 'EV'}</span> ({res.licensePlate || '—'})
                        </span>
                      ) : (
                        <span>
                          Host: <strong style={{ color: '#d0d6e0' }}>{station.homeowner?.fullName || station.host?.fullName || 'Host'}</strong> · Tariff:{' '}
                          <span style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>₹{station.pricePerKwh || 18}/kWh</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Right Actions */}
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 8, minWidth: 140 }}>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 10, color: '#62666d', textTransform: 'uppercase' }}>Est. Cost</div>
                      <div style={{ fontSize: 16, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                        ₹{(res.estimatedCost || (res.estimatedKwh || 20) * (station.pricePerKwh || 18)).toFixed(2)}
                      </div>
                    </div>

                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, justifyContent: 'flex-end' }}>
                      {/* Host Actions */}
                      {user?.role === 'HOMEOWNER' && currentStatus === 'PENDING' && (
                        <>
                          <button
                            onClick={() => handleUpdateStatus(res.id, 'CONFIRMED')}
                            disabled={actionLoading === res.id}
                            className="btn-primary"
                            style={{ padding: '4px 10px', fontSize: 11 }}
                          >
                            Accept
                          </button>
                          <button
                            onClick={() => handleUpdateStatus(res.id, 'REJECTED')}
                            disabled={actionLoading === res.id}
                            className="btn-danger"
                            style={{ padding: '4px 10px', fontSize: 11 }}
                          >
                            Decline
                          </button>
                        </>
                      )}

                      {/* EV Owner Actions */}
                      {user?.role === 'EV_OWNER' &&
                        (currentStatus === 'PENDING' || currentStatus === 'CONFIRMED') && (
                          <button
                            onClick={() => handleCancelReservation(res.id)}
                            disabled={actionLoading === res.id}
                            className="btn-secondary"
                            style={{ padding: '4px 10px', fontSize: 11, color: '#f87171' }}
                          >
                            Cancel
                          </button>
                        )}

                      {/* Go to Session if confirmed */}
                      {currentStatus === 'CONFIRMED' && (
                        <Link
                          to="/sessions"
                          className="btn-secondary"
                          style={{ padding: '4px 10px', fontSize: 11, textDecoration: 'none' }}
                        >
                          <Zap size={12} color="#5e6ad2" /> Live Session
                        </Link>
                      )}

                      {/* Review Host */}
                      {user?.role === 'EV_OWNER' && currentStatus === 'COMPLETED' && (
                        <button
                          onClick={() => {
                            setReviewReservation(res);
                            setReviewModalOpen(true);
                          }}
                          className="btn-secondary"
                          style={{ padding: '4px 10px', fontSize: 11 }}
                        >
                          <Star size={12} color="#f59e0b" fill="#f59e0b" /> Review
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Review Modal */}
        {reviewModalOpen && reviewReservation && (
          <div
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9999,
              background: 'rgba(0, 0, 0, 0.75)',
              backdropFilter: 'blur(4px)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 16,
            }}
          >
            <div
              style={{
                background: '#0f1011',
                border: '1px solid #23252a',
                borderRadius: 8,
                width: '100%',
                maxWidth: 420,
                padding: '24px',
                position: 'relative',
                boxShadow: '0 24px 64px rgba(0,0,0,0.8)',
              }}
            >
              <button
                onClick={() => setReviewModalOpen(false)}
                aria-label="Close"
                style={{
                  position: 'absolute',
                  right: 16,
                  top: 16,
                  background: 'none',
                  border: 'none',
                  color: '#62666d',
                  cursor: 'pointer',
                }}
              >
                <X size={16} />
              </button>

              <h2 style={{ fontSize: 16, fontWeight: 600, color: '#f7f8f8', marginBottom: 4 }}>
                Review Charging Station
              </h2>
              <p style={{ color: '#8a8f98', fontSize: 12, marginBottom: 18 }}>
                {reviewReservation.station?.stationName || reviewReservation.station?.name || 'Charging Station'}
              </p>

              <form onSubmit={handleSubmitReview}>
                {/* Rating Stars */}
                <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 16 }}>
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      style={{
                        background: 'none',
                        border: 'none',
                        cursor: 'pointer',
                        padding: 2,
                      }}
                    >
                      <Star
                        size={24}
                        color={star <= rating ? '#f59e0b' : '#34343a'}
                        fill={star <= rating ? '#f59e0b' : 'none'}
                      />
                    </button>
                  ))}
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label className="form-label">Feedback & Host Experience</label>
                  <textarea
                    rows="3"
                    placeholder="Charger speed, accessibility, parking comfort..."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    required
                    className="form-input"
                    style={{ resize: 'none' }}
                  />
                </div>

                <div style={{ display: 'flex', gap: 10 }}>
                  <button
                    type="button"
                    onClick={() => setReviewModalOpen(false)}
                    className="btn-secondary"
                    style={{ flex: 1, padding: '7px 14px' }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submittingReview}
                    className="btn-primary"
                    style={{ flex: 1.5, padding: '7px 14px' }}
                  >
                    {submittingReview ? 'Posting...' : 'Post Review'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
