import { useState, useEffect } from 'react';
import { User, Car, Zap, CheckCircle, AlertCircle, Save } from 'lucide-react';
import DashboardLayout from '../layouts/DashboardLayout';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const CONNECTOR_TYPES = ['CCS', 'Type2', 'CHAdeMO', 'J1772'];

export default function Profile() {
  const { user, refreshUser } = useAuth();

  // Personal form
  const [personalForm, setPersonalForm] = useState({
    fullName: user?.fullName || '',
    phoneNumber: user?.phoneNumber || '',
  });
  const [personalLoading, setPersonalLoading] = useState(false);
  const [personalMsg, setPersonalMsg] = useState({ type: '', text: '' });

  // EV form
  const [evForm, setEvForm] = useState({
    vehicleModel: user?.evProfile?.vehicleModel || '',
    registrationNumber: user?.evProfile?.registrationNumber || '',
    batteryCapacity: user?.evProfile?.batteryCapacity || '',
    connectorType: user?.evProfile?.connectorType || 'CCS',
  });
  const [evLoading, setEvLoading] = useState(false);
  const [evMsg, setEvMsg] = useState({ type: '', text: '' });

  useEffect(() => {
    if (user) {
      setPersonalForm({
        fullName: user.fullName || '',
        phoneNumber: user.phoneNumber || '',
      });
      if (user.evProfile) {
        setEvForm({
          vehicleModel: user.evProfile.vehicleModel || '',
          registrationNumber: user.evProfile.registrationNumber || '',
          batteryCapacity: user.evProfile.batteryCapacity || '',
          connectorType: user.evProfile.connectorType || 'CCS',
        });
      }
    }
  }, [user]);

  const handleUpdatePersonal = async (e) => {
    e.preventDefault();
    setPersonalLoading(true);
    setPersonalMsg({ type: '', text: '' });
    try {
      await api.put('/auth/profile', personalForm);
      await refreshUser();
      setPersonalMsg({ type: 'success', text: 'Personal details updated successfully.' });
      setTimeout(() => setPersonalMsg({ type: '', text: '' }), 3000);
    } catch (err) {
      setPersonalMsg({ type: 'error', text: err.response?.data?.message || 'Failed to update profile.' });
    } finally {
      setPersonalLoading(false);
    }
  };

  const handleUpdateEvProfile = async (e) => {
    e.preventDefault();
    setEvLoading(true);
    setEvMsg({ type: '', text: '' });
    try {
      await api.post('/auth/ev-profile', evForm);
      await refreshUser();
      setEvMsg({ type: 'success', text: 'Vehicle telemetry profile registered.' });
      setTimeout(() => setEvMsg({ type: '', text: '' }), 3000);
    } catch (err) {
      setEvMsg({ type: 'error', text: err.response?.data?.message || 'Failed to save vehicle profile.' });
    } finally {
      setEvLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
          Account Settings & Telemetry
        </h1>
        <p style={{ color: '#8a8f98', fontSize: 13 }}>
          Identity details, vehicle specifications, and authentication parameters
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 16 }}>
        {/* Left Column: Account Summary & Personal Form */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Account Overview Card */}
          <div className="panel" style={{ padding: '24px', textAlign: 'center' }}>
            <div
              style={{
                width: 56,
                height: 56,
                borderRadius: 8,
                background: '#141516',
                border: '1px solid #23252a',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 20,
                fontWeight: 600,
                color: '#f7f8f8',
                margin: '0 auto 12px',
              }}
            >
              {user?.fullName?.charAt(0).toUpperCase() || 'U'}
            </div>
            <h2 style={{ fontSize: 15, fontWeight: 600, color: '#f7f8f8', marginBottom: 2 }}>
              {user?.fullName}
            </h2>
            <p style={{ fontSize: 12, color: '#8a8f98', marginBottom: 12 }}>
              {user?.email}
            </p>
            <div style={{ display: 'inline-flex' }}>
              <span className="badge badge-completed">
                {user?.role} ROLE
              </span>
            </div>
            <div style={{ marginTop: 16, paddingTop: 12, borderTop: '1px solid #1a1c20', fontSize: 11, color: '#62666d' }}>
              Member since {user?.createdAt ? new Date(user.createdAt).toLocaleDateString(undefined, { month: 'long', year: 'numeric' }) : '2026'}
            </div>
          </div>

          {/* Personal Information Form */}
          <div className="panel" style={{ padding: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
              <User size={15} color="#8a8f98" />
              <h3 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8' }}>
                Personal Credentials
              </h3>
            </div>

            {personalMsg.text && (
              <div
                style={{
                  marginBottom: 14,
                  padding: '8px 12px',
                  borderRadius: 6,
                  background: personalMsg.type === 'success' ? 'rgba(39, 166, 68, 0.1)' : 'rgba(235, 87, 87, 0.1)',
                  border: personalMsg.type === 'success' ? '1px solid rgba(39, 166, 68, 0.25)' : '1px solid rgba(235, 87, 87, 0.25)',
                  color: personalMsg.type === 'success' ? '#34d399' : '#f87171',
                  fontSize: 12,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                }}
              >
                {personalMsg.type === 'success' ? <CheckCircle size={14} /> : <AlertCircle size={14} />}
                <span>{personalMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleUpdatePersonal} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <label className="form-label">Full Name</label>
                <input
                  type="text"
                  className="form-input"
                  value={personalForm.fullName}
                  onChange={(e) => setPersonalForm((f) => ({ ...f, fullName: e.target.value }))}
                  required
                />
              </div>

              <div>
                <label className="form-label">Email Address (Immutable)</label>
                <input
                  type="email"
                  className="form-input"
                  value={user?.email || ''}
                  disabled
                  style={{ opacity: 0.5, cursor: 'not-allowed' }}
                />
              </div>

              <div>
                <label className="form-label">Phone Number</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="+91 98765 43210"
                  value={personalForm.phoneNumber}
                  onChange={(e) => setPersonalForm((f) => ({ ...f, phoneNumber: e.target.value }))}
                />
              </div>

              <button
                type="submit"
                className="btn-primary"
                disabled={personalLoading}
                style={{ marginTop: 4, padding: '7px 14px', fontSize: 12 }}
              >
                <Save size={13} />
                {personalLoading ? 'Saving...' : 'Update Details'}
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: EV Vehicle Profile & Preferences */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="panel" style={{ padding: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
              <Car size={15} color="#8a8f98" />
              <h3 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8' }}>
                Vehicle Specifications
              </h3>
            </div>
            <p style={{ fontSize: 12, color: '#8a8f98', marginBottom: 16 }}>
              Provide accurate battery telemetry to enable compatibility verification and estimate charge times.
            </p>

            {evMsg.text && (
              <div
                style={{
                  marginBottom: 14,
                  padding: '8px 12px',
                  borderRadius: 6,
                  background: evMsg.type === 'success' ? 'rgba(39, 166, 68, 0.1)' : 'rgba(235, 87, 87, 0.1)',
                  border: evMsg.type === 'success' ? '1px solid rgba(39, 166, 68, 0.25)' : '1px solid rgba(235, 87, 87, 0.25)',
                  color: evMsg.type === 'success' ? '#34d399' : '#f87171',
                  fontSize: 12,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                }}
              >
                {evMsg.type === 'success' ? <CheckCircle size={14} /> : <AlertCircle size={14} />}
                <span>{evMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleUpdateEvProfile} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <label className="form-label">Vehicle Make & Model</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g. Tata Nexon EV Max, MG ZS EV"
                  value={evForm.vehicleModel}
                  onChange={(e) => setEvForm((f) => ({ ...f, vehicleModel: e.target.value }))}
                  required
                />
              </div>

              <div>
                <label className="form-label">Registration Plate</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g. MH 02 AB 1234"
                  value={evForm.registrationNumber}
                  onChange={(e) => setEvForm((f) => ({ ...f, registrationNumber: e.target.value }))}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <div>
                  <label className="form-label">Battery Capacity (kWh)</label>
                  <input
                    type="number"
                    step="0.1"
                    className="form-input"
                    placeholder="e.g. 40.5"
                    value={evForm.batteryCapacity}
                    onChange={(e) => setEvForm((f) => ({ ...f, batteryCapacity: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="form-label">Standard Port</label>
                  <select
                    className="form-input"
                    value={evForm.connectorType}
                    onChange={(e) => setEvForm((f) => ({ ...f, connectorType: e.target.value }))}
                  >
                    {CONNECTOR_TYPES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="btn-primary"
                disabled={evLoading}
                style={{ marginTop: 4, padding: '7px 14px', fontSize: 12 }}
              >
                <Zap size={13} />
                {evLoading ? 'Saving...' : 'Save Specifications'}
              </button>
            </form>
          </div>

          {/* Telemetry Architecture Notes */}
          <div className="panel" style={{ padding: '18px 20px' }}>
            <h4 style={{ fontSize: 12, fontWeight: 600, color: '#f7f8f8', marginBottom: 8, letterSpacing: '-0.01em' }}>
              Why configure vehicle specs?
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 12, color: '#8a8f98' }}>
              <div style={{ display: 'flex', gap: 6 }}>
                <span style={{ color: '#5e6ad2' }}>—</span>
                <span>Automatic filtering of compatible wallboxes and sockets</span>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <span style={{ color: '#5e6ad2' }}>—</span>
                <span>Accurate arrival estimate calculations based on vehicle SoC</span>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <span style={{ color: '#5e6ad2' }}>—</span>
                <span>Automated plate verification for homeowner parking and gate access</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
