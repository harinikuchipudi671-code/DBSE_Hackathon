import { Link } from 'react-router-dom';
import {
  Zap, MapPin, Calendar, Star, Shield, Clock, ChevronRight,
  ArrowUpRight
} from 'lucide-react';

const features = [
  {
    icon: MapPin,
    title: 'Precise Geospatial Search',
    desc: 'Locate certified residential chargers in your immediate radius with real-time slot availability.',
  },
  {
    icon: Calendar,
    title: 'Frictionless Slot Reservation',
    desc: 'Lock in guaranteed arrival windows. Eliminate queue anxiety and arrive with certainty.',
  },
  {
    icon: Zap,
    title: 'Precision Telemetry',
    desc: 'Verify delivered kWh, peak draw, and charging rate through real-time session tracking.',
  },
  {
    icon: Star,
    title: 'Community Verification',
    desc: 'Transparent host reviews and station ratings protect your vehicle and charging experience.',
  },
  {
    icon: Shield,
    title: 'Transparent Micro-Billing',
    desc: 'Instant settlement per kilowatt-hour without hidden fees or recurring subscriptions.',
  },
  {
    icon: Clock,
    title: 'Autonomous Scheduling',
    desc: 'Hosts dictate precise availability windows, tariff rules, and designated parking access.',
  },
];

const steps = [
  {
    num: '01',
    title: 'Set up credentials',
    desc: 'Create your account as an EV driver or host in seconds with zero friction.',
  },
  {
    num: '02',
    title: 'Discover or publish',
    desc: 'Register your residential wallbox or explore nearby charging ports on the live map.',
  },
  {
    num: '03',
    title: 'Confirm slot window',
    desc: 'Select preferred hours, connector compatibility, and submit booking requests.',
  },
  {
    num: '04',
    title: 'Plug, charge, settle',
    desc: 'Complete charging sessions and reconcile payments with instant digital receipts.',
  },
];

const metrics = [
  { value: '540+', label: 'Registered Ports', detail: 'Level 2 & DC Fast' },
  { value: '3,800+', label: 'Active Drivers', detail: 'Verified vehicles' },
  { value: '42,000+', label: 'kWh Dispatched', detail: 'Zero-emission power' },
  { value: '99.4%', label: 'Session Success', detail: 'Verified uptime' },
];

export default function Landing() {
  return (
    <div style={{ background: '#010102', minHeight: '100vh', color: '#f7f8f8' }}>
      {/* Top Nav (56px) */}
      <nav
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          zIndex: 100,
          background: 'rgba(1, 1, 2, 0.85)',
          backdropFilter: 'blur(12px)',
          borderBottom: '1px solid #23252a',
          height: 56,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 32px',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div
            style={{
              width: 28,
              height: 28,
              borderRadius: 6,
              background: '#5e6ad2',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#ffffff',
            }}
          >
            <Zap size={16} fill="currentColor" stroke="none" />
          </div>
          <span style={{ fontWeight: 600, fontSize: 14, letterSpacing: '-0.02em', color: '#f7f8f8' }}>
            ChargeShare
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Link
            to="/login"
            style={{
              fontSize: 13,
              fontWeight: 500,
              color: '#8a8f98',
              textDecoration: 'none',
              padding: '6px 14px',
              borderRadius: 6,
              transition: 'color 0.15s ease',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#f7f8f8')}
            onMouseLeave={(e) => (e.currentTarget.style.color = '#8a8f98')}
          >
            Sign In
          </Link>
          <Link
            to="/register"
            className="btn-primary"
            style={{ textDecoration: 'none', padding: '6px 14px', fontSize: 13 }}
          >
            Get Started
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section
        style={{
          paddingTop: 130,
          paddingBottom: 80,
          paddingLeft: 24,
          paddingRight: 24,
          maxWidth: 1100,
          margin: '0 auto',
          textAlign: 'center',
        }}
      >
        {/* Eyebrow Pill */}
        <div style={{ display: 'inline-flex', marginBottom: 24 }}>
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              padding: '4px 12px',
              borderRadius: 999,
              background: '#0f1011',
              border: '1px solid #23252a',
              fontSize: 12,
              fontWeight: 500,
              color: '#8a8f98',
            }}
          >
            <span
              style={{
                width: 6,
                height: 6,
                borderRadius: '50%',
                background: '#5e6ad2',
              }}
            />
            <span>ChargeShare 2.0 · Residential EV Charging Protocol</span>
            <ArrowUpRight size={13} color="#62666d" />
          </div>
        </div>

        {/* Headline */}
        <h1
          style={{
            fontSize: 'clamp(36px, 5.5vw, 64px)',
            fontWeight: 600,
            lineHeight: 1.1,
            letterSpacing: '-0.03em',
            color: '#f7f8f8',
            marginBottom: 20,
            maxWidth: 820,
            marginLeft: 'auto',
            marginRight: 'auto',
          }}
        >
          Decentralized EV charging for modern neighborhoods
        </h1>

        <p
          style={{
            fontSize: 'clamp(16px, 2vw, 18px)',
            lineHeight: 1.6,
            color: '#8a8f98',
            maxWidth: 620,
            margin: '0 auto 36px',
            letterSpacing: '-0.01em',
          }}
        >
          ChargeShare pairs private charger owners with EV drivers. Book reserved ports, track power consumption, and monetize unused home capacity.
        </p>

        {/* CTA Buttons */}
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap', marginBottom: 56 }}>
          <Link
            to="/register"
            className="btn-primary"
            style={{ textDecoration: 'none', padding: '10px 22px', fontSize: 14 }}
          >
            Find a Charger <ChevronRight size={15} />
          </Link>
          <Link
            to="/register?role=HOMEOWNER"
            className="btn-secondary"
            style={{ textDecoration: 'none', padding: '10px 22px', fontSize: 14 }}
          >
            List Your Station
          </Link>
        </div>

        {/* Hero Interactive UI Preview Mock */}
        <div
          style={{
            maxWidth: 860,
            margin: '0 auto',
            borderRadius: 10,
            background: '#0f1011',
            border: '1px solid #23252a',
            overflow: 'hidden',
            boxShadow: '0 24px 64px rgba(0, 0, 0, 0.6)',
            textAlign: 'left',
          }}
        >
          {/* Mock Window Header */}
          <div
            style={{
              height: 38,
              padding: '0 16px',
              borderBottom: '1px solid #23252a',
              background: '#141516',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#23252a' }} />
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#23252a' }} />
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#23252a' }} />
              <span style={{ fontSize: 11, color: '#62666d', marginLeft: 10, fontFamily: 'monospace' }}>
                app.chargeshare.io/stations/in_mum_402
              </span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span className="badge badge-active">Live Telemetry</span>
            </div>
          </div>

          {/* Mock Content */}
          <div style={{ padding: '24px 28px', display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 24 }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <span className="badge badge-completed">Type 2 AC</span>
                <span style={{ fontSize: 12, color: '#8a8f98' }}>· 22.0 kW Capacity</span>
              </div>
              <h3 style={{ fontSize: 18, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 6 }}>
                Bandra West HyperCharge Dock
              </h3>
              <p style={{ fontSize: 13, color: '#8a8f98', marginBottom: 18, lineHeight: 1.5 }}>
                14th Road, Khar West, Mumbai · Covered driveway with secure gated access and high-speed Wi-Fi.
              </p>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
                <div style={{ background: '#141516', padding: '10px 12px', borderRadius: 6, border: '1px solid #23252a' }}>
                  <div style={{ fontSize: 11, color: '#8a8f98' }}>Tariff Rate</div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>₹18.5/kWh</div>
                </div>
                <div style={{ background: '#141516', padding: '10px 12px', borderRadius: 6, border: '1px solid #23252a' }}>
                  <div style={{ fontSize: 11, color: '#8a8f98' }}>Host Rating</div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: '#f7f8f8', display: 'flex', alignItems: 'center', gap: 4 }}>
                    <Star size={13} fill="#f59e0b" color="#f59e0b" /> 4.9 <span style={{ fontSize: 11, color: '#62666d' }}>(38)</span>
                  </div>
                </div>
                <div style={{ background: '#141516', padding: '10px 12px', borderRadius: 6, border: '1px solid #23252a' }}>
                  <div style={{ fontSize: 11, color: '#8a8f98' }}>Availability</div>
                  <div style={{ fontSize: 13, fontWeight: 500, color: '#27a644' }}>Available Now</div>
                </div>
              </div>
            </div>

            {/* Mock Booking Window */}
            <div
              style={{
                background: '#141516',
                border: '1px solid #23252a',
                borderRadius: 8,
                padding: '16px 18px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
              }}
            >
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                  <span style={{ fontSize: 12, fontWeight: 500, color: '#8a8f98' }}>Upcoming Available Slot</span>
                  <span style={{ fontSize: 11, color: '#5e6ad2', fontFamily: 'monospace' }}>Today</span>
                </div>
                <div
                  style={{
                    padding: '8px 12px',
                    borderRadius: 6,
                    background: '#18191a',
                    border: '1px solid #34343a',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: 10,
                  }}
                >
                  <span style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8' }}>14:00 — 16:30</span>
                  <span style={{ fontSize: 11, color: '#8a8f98' }}>2h 30m</span>
                </div>
                <div style={{ fontSize: 12, color: '#8a8f98', display: 'flex', justifyContent: 'space-between', padding: '4px 0' }}>
                  <span>Est. Energy (25 kWh)</span>
                  <span style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>₹462.50</span>
                </div>
              </div>

              <Link
                to="/register"
                className="btn-primary"
                style={{ width: '100%', textDecoration: 'none', marginTop: 14, fontSize: 13 }}
              >
                Instant Reserve
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Metrics Bar with Hairline Dividers */}
      <section style={{ borderTop: '1px solid #23252a', borderBottom: '1px solid #23252a', background: '#080809' }}>
        <div
          style={{
            maxWidth: 1100,
            margin: '0 auto',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          }}
        >
          {metrics.map((m, idx) => (
            <div
              key={m.label}
              style={{
                padding: '36px 28px',
                borderRight: idx < metrics.length - 1 ? '1px solid #23252a' : 'none',
              }}
            >
              <div
                style={{
                  fontSize: 32,
                  fontWeight: 600,
                  letterSpacing: '-0.03em',
                  color: '#f7f8f8',
                  fontFamily: 'monospace',
                  marginBottom: 6,
                }}
              >
                {m.value}
              </div>
              <div style={{ fontSize: 13, fontWeight: 500, color: '#d0d6e0', marginBottom: 2 }}>
                {m.label}
              </div>
              <div style={{ fontSize: 11, color: '#62666d' }}>{m.detail}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features Grid */}
      <section style={{ padding: '96px 24px', maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ marginBottom: 56, textAlign: 'left' }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#5e6ad2', letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: 8 }}>
            Architecture & Features
          </div>
          <h2
            style={{
              fontSize: 'clamp(28px, 4vw, 36px)',
              fontWeight: 600,
              letterSpacing: '-0.025em',
              color: '#f7f8f8',
              maxWidth: 600,
            }}
          >
            Engineered for reliability, safety, and seamless energy settlement
          </h2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 16 }}>
          {features.map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="panel-interactive"
              style={{ padding: '24px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}
            >
              <div>
                <div
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 6,
                    background: '#141516',
                    border: '1px solid #23252a',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginBottom: 16,
                    color: '#8a8f98',
                  }}
                >
                  <Icon size={16} />
                </div>
                <h3 style={{ fontSize: 15, fontWeight: 500, color: '#f7f8f8', letterSpacing: '-0.01em', marginBottom: 8 }}>
                  {title}
                </h3>
                <p style={{ fontSize: 13, color: '#8a8f98', lineHeight: 1.55 }}>
                  {desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Workflow Steps */}
      <section style={{ padding: '80px 24px', borderTop: '1px solid #23252a', background: '#080809' }}>
        <div style={{ maxWidth: 1100, margin: '0 auto' }}>
          <div style={{ marginBottom: 48 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: '#5e6ad2', letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: 8 }}>
              Workflow
            </div>
            <h2 style={{ fontSize: 28, fontWeight: 600, letterSpacing: '-0.02em', color: '#f7f8f8' }}>
              How ChargeShare operates
            </h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 16 }}>
            {steps.map((s) => (
              <div
                key={s.num}
                style={{
                  padding: '24px',
                  background: '#0f1011',
                  border: '1px solid #23252a',
                  borderRadius: 8,
                }}
              >
                <div
                  style={{
                    fontFamily: 'monospace',
                    fontSize: 14,
                    fontWeight: 600,
                    color: '#5e6ad2',
                    marginBottom: 12,
                  }}
                >
                  {s.num}
                </div>
                <h3 style={{ fontSize: 14, fontWeight: 500, color: '#f7f8f8', marginBottom: 6 }}>
                  {s.title}
                </h3>
                <p style={{ fontSize: 12, color: '#8a8f98', lineHeight: 1.5 }}>
                  {s.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Box */}
      <section style={{ padding: '80px 24px' }}>
        <div
          style={{
            maxWidth: 820,
            margin: '0 auto',
            padding: '48px 36px',
            borderRadius: 10,
            background: '#0f1011',
            border: '1px solid #23252a',
            textAlign: 'center',
          }}
        >
          <div
            style={{
              width: 36,
              height: 36,
              borderRadius: 8,
              background: '#5e6ad2',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#ffffff',
              marginBottom: 20,
            }}
          >
            <Zap size={18} fill="currentColor" stroke="none" />
          </div>
          <h2 style={{ fontSize: 28, fontWeight: 600, letterSpacing: '-0.02em', color: '#f7f8f8', marginBottom: 12 }}>
            Start sharing or charging today
          </h2>
          <p style={{ fontSize: 14, color: '#8a8f98', maxWidth: 460, margin: '0 auto 28px', lineHeight: 1.6 }}>
            Join our peer-to-peer charging network. Zero subscription commitments, instant activation.
          </p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
            <Link to="/register" className="btn-primary" style={{ textDecoration: 'none', padding: '9px 20px', fontSize: 13 }}>
              Create Account
            </Link>
            <Link to="/login" className="btn-secondary" style={{ textDecoration: 'none', padding: '9px 20px', fontSize: 13 }}>
              Sign In
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer
        style={{
          padding: '32px 32px',
          borderTop: '1px solid #23252a',
          background: '#010102',
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 16,
          maxWidth: 1200,
          margin: '0 auto',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div
            style={{
              width: 20,
              height: 20,
              borderRadius: 4,
              background: '#5e6ad2',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#ffffff',
            }}
          >
            <Zap size={12} fill="currentColor" stroke="none" />
          </div>
          <span style={{ fontSize: 12, color: '#8a8f98' }}>
            ChargeShare Platform © {new Date().getFullYear()} · Craft-focused EV Charging
          </span>
        </div>

        <div style={{ display: 'flex', gap: 20 }}>
          {['Network Status', 'API Docs', 'Privacy Policy', 'Terms of Service'].map((link) => (
            <span
              key={link}
              style={{ fontSize: 12, color: '#62666d', cursor: 'pointer', transition: 'color 0.15s ease' }}
              onMouseEnter={(e) => (e.currentTarget.style.color = '#d0d6e0')}
              onMouseLeave={(e) => (e.currentTarget.style.color = '#62666d')}
            >
              {link}
            </span>
          ))}
        </div>
      </footer>
    </div>
  );
}
