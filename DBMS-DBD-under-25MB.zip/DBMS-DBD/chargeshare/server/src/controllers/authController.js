const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const prisma = require('../config/database');

const generateToken = (userId) => {
  return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
};

// POST /api/auth/register
const register = async (req, res) => {
  try {
    const { fullName, email, password, phoneNumber, role } = req.body;

    if (!fullName || !email || !password || !role) {
      return res.status(400).json({ success: false, message: 'Full name, email, password and role are required' });
    }
    if (!['HOMEOWNER', 'EV_OWNER'].includes(role)) {
      return res.status(400).json({ success: false, message: 'Role must be HOMEOWNER or EV_OWNER' });
    }

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) {
      return res.status(409).json({ success: false, message: 'Email already registered' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: { fullName, email, passwordHash, phoneNumber, role },
      select: { id: true, fullName: true, email: true, role: true, phoneNumber: true, createdAt: true }
    });

    const token = generateToken(user.id);
    res.status(201).json({ success: true, message: 'Registration successful', data: { user, token } });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ success: false, message: 'Server error during registration' });
  }
};

// POST /api/auth/login
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required' });
    }

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    const token = generateToken(user.id);
    const { passwordHash, ...userWithoutPassword } = user;
    res.json({ success: true, message: 'Login successful', data: { user: userWithoutPassword, token } });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: 'Server error during login' });
  }
};

// GET /api/auth/me
const getMe = async (req, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      select: {
        id: true, fullName: true, email: true, role: true,
        phoneNumber: true, profileImage: true, createdAt: true,
        evProfile: true,
        _count: { select: { chargingStations: true, reservationsAsEV: true } }
      }
    });
    res.json({ success: true, data: user });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// PUT /api/users/profile
const updateProfile = async (req, res) => {
  try {
    const { fullName, phoneNumber, profileImage } = req.body;
    const user = await prisma.user.update({
      where: { id: req.user.id },
      data: { fullName, phoneNumber, profileImage },
      select: { id: true, fullName: true, email: true, role: true, phoneNumber: true, profileImage: true }
    });
    res.json({ success: true, message: 'Profile updated', data: user });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// POST /api/users/ev-profile
const upsertEvProfile = async (req, res) => {
  try {
    const { vehicleModel, registrationNumber, batteryCapacity, connectorType } = req.body;
    if (!vehicleModel || !connectorType) {
      return res.status(400).json({ success: false, message: 'Vehicle model and connector type are required' });
    }
    const profile = await prisma.evProfile.upsert({
      where: { userId: req.user.id },
      create: { userId: req.user.id, vehicleModel, registrationNumber, batteryCapacity: parseFloat(batteryCapacity) || null, connectorType },
      update: { vehicleModel, registrationNumber, batteryCapacity: parseFloat(batteryCapacity) || null, connectorType }
    });
    res.json({ success: true, message: 'EV profile saved', data: profile });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { register, login, getMe, updateProfile, upsertEvProfile };
