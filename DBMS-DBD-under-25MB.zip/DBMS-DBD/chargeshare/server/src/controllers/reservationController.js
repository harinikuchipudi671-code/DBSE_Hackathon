const prisma = require('../config/database');

const createNotification = async (userId, title, message, type) => {
  try {
    await prisma.notification.create({ data: { userId, title, message, notificationType: type } });
  } catch (e) { console.error('Notification error:', e); }
};

// POST /api/reservations
const createReservation = async (req, res) => {
  try {
    const { stationId, slotId, bookingDate, startTime, endTime, estimatedEnergy } = req.body;

    if (!stationId || !slotId || !bookingDate || !startTime || !endTime) {
      return res.status(400).json({ success: false, message: 'Missing required fields' });
    }

    const station = await prisma.chargingStation.findUnique({ where: { id: parseInt(stationId) } });
    if (!station || !station.isActive) return res.status(404).json({ success: false, message: 'Station not available' });

    // Business rule: homeowner cannot book own station
    if (station.homeownerId === req.user.id) {
      return res.status(403).json({ success: false, message: 'You cannot book your own station' });
    }

    // Atomic slot booking with transaction
    const result = await prisma.$transaction(async (tx) => {
      const slot = await tx.availabilitySlot.findUnique({ where: { id: parseInt(slotId) } });
      if (!slot || slot.slotStatus !== 'AVAILABLE') {
        throw new Error('Slot is not available');
      }

      const estimatedCost = estimatedEnergy ? parseFloat(estimatedEnergy) * station.pricePerKwh : null;

      const reservation = await tx.reservation.create({
        data: {
          evOwnerId: req.user.id,
          stationId: parseInt(stationId),
          slotId: parseInt(slotId),
          bookingDate,
          startTime,
          endTime,
          estimatedEnergy: estimatedEnergy ? parseFloat(estimatedEnergy) : null,
          estimatedCost
        }
      });

      // Mark slot as booked
      await tx.availabilitySlot.update({
        where: { id: parseInt(slotId) },
        data: { slotStatus: 'BOOKED' }
      });

      return reservation;
    });

    // Notify homeowner
    await createNotification(station.homeownerId, 'New Booking Request', `You have a new booking request for ${station.stationName} on ${bookingDate}`, 'BOOKING');

    res.status(201).json({ success: true, message: 'Reservation created, awaiting homeowner confirmation', data: result });
  } catch (err) {
    if (err.message === 'Slot is not available') {
      return res.status(409).json({ success: false, message: 'This slot is no longer available' });
    }
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/reservations/my - EV owner's reservations
const getMyReservations = async (req, res) => {
  try {
    const reservations = await prisma.reservation.findMany({
      where: { evOwnerId: req.user.id },
      include: {
        station: { select: { id: true, stationName: true, completeAddress: true, latitude: true, longitude: true, connectorType: true, chargerType: true, pricePerKwh: true } },
        slot: true,
        chargingSession: { include: { payment: true } },
        review: true
      },
      orderBy: { createdAt: 'desc' }
    });
    res.json({ success: true, data: reservations });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/reservations/received - homeowner's received reservations
const getReceivedReservations = async (req, res) => {
  try {
    const stations = await prisma.chargingStation.findMany({
      where: { homeownerId: req.user.id },
      select: { id: true }
    });
    const stationIds = stations.map(s => s.id);

    const reservations = await prisma.reservation.findMany({
      where: { stationId: { in: stationIds } },
      include: {
        evOwner: { select: { id: true, fullName: true, email: true, phoneNumber: true, profileImage: true, evProfile: true } },
        station: { select: { id: true, stationName: true, pricePerKwh: true } },
        slot: true,
        chargingSession: { include: { payment: true } }
      },
      orderBy: { createdAt: 'desc' }
    });
    res.json({ success: true, data: reservations });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/reservations/:id
const getReservationById = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const reservation = await prisma.reservation.findUnique({
      where: { id },
      include: {
        evOwner: { select: { id: true, fullName: true, email: true, phoneNumber: true, evProfile: true } },
        station: { include: { homeowner: { select: { id: true, fullName: true, phoneNumber: true } } } },
        slot: true,
        chargingSession: { include: { payment: true } },
        review: true
      }
    });

    if (!reservation) return res.status(404).json({ success: false, message: 'Reservation not found' });

    // Only involved parties can view
    const stationOwnerId = reservation.station.homeownerId;
    if (reservation.evOwnerId !== req.user.id && stationOwnerId !== req.user.id && req.user.role !== 'ADMIN') {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    res.json({ success: true, data: reservation });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// PATCH /api/reservations/:id/status (homeowner: CONFIRMED / REJECTED)
const updateReservationStatus = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { status } = req.body;

    if (!['CONFIRMED', 'REJECTED'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Status must be CONFIRMED or REJECTED' });
    }

    const reservation = await prisma.reservation.findUnique({
      where: { id },
      include: { station: true }
    });
    if (!reservation) return res.status(404).json({ success: false, message: 'Reservation not found' });
    if (reservation.station.homeownerId !== req.user.id) return res.status(403).json({ success: false, message: 'Not authorized' });
    if (reservation.bookingStatus !== 'PENDING') {
      return res.status(400).json({ success: false, message: 'Only pending reservations can be updated' });
    }

    const updated = await prisma.reservation.update({
      where: { id },
      data: { bookingStatus: status }
    });

    // If rejected, release the slot
    if (status === 'REJECTED') {
      await prisma.availabilitySlot.update({
        where: { id: reservation.slotId },
        data: { slotStatus: 'AVAILABLE' }
      });
    }

    // Notify EV owner
    const msg = status === 'CONFIRMED' ? `Your booking for ${reservation.station.stationName} on ${reservation.bookingDate} has been confirmed!` : `Your booking for ${reservation.station.stationName} on ${reservation.bookingDate} was rejected.`;
    await createNotification(reservation.evOwnerId, `Booking ${status}`, msg, 'BOOKING');

    res.json({ success: true, message: `Reservation ${status.toLowerCase()}`, data: updated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// POST /api/reservations/:id/cancel
const cancelReservation = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const reservation = await prisma.reservation.findUnique({
      where: { id },
      include: { station: true }
    });

    if (!reservation) return res.status(404).json({ success: false, message: 'Reservation not found' });

    const isEvOwner = reservation.evOwnerId === req.user.id;
    const isHomeowner = reservation.station.homeownerId === req.user.id;

    if (!isEvOwner && !isHomeowner && req.user.role !== 'ADMIN') {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    if (!['PENDING', 'CONFIRMED'].includes(reservation.bookingStatus)) {
      return res.status(400).json({ success: false, message: 'Cannot cancel a reservation in this state' });
    }

    await prisma.$transaction(async (tx) => {
      await tx.reservation.update({ where: { id }, data: { bookingStatus: 'CANCELLED' } });
      await tx.availabilitySlot.update({ where: { id: reservation.slotId }, data: { slotStatus: 'AVAILABLE' } });
    });

    // Notify the other party
    const notifyUserId = isEvOwner ? reservation.station.homeownerId : reservation.evOwnerId;
    await createNotification(notifyUserId, 'Reservation Cancelled', `A reservation for ${reservation.station.stationName} on ${reservation.bookingDate} was cancelled.`, 'BOOKING');

    res.json({ success: true, message: 'Reservation cancelled successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { createReservation, getMyReservations, getReceivedReservations, getReservationById, updateReservationStatus, cancelReservation };
