const prisma = require('../config/database');

// POST /api/slots
const createSlot = async (req, res) => {
  try {
    const { stationId, availableDate, startTime, endTime } = req.body;
    if (!stationId || !availableDate || !startTime || !endTime) {
      return res.status(400).json({ success: false, message: 'stationId, availableDate, startTime, endTime are required' });
    }

    // Verify ownership
    const station = await prisma.chargingStation.findUnique({ where: { id: parseInt(stationId) } });
    if (!station) return res.status(404).json({ success: false, message: 'Station not found' });
    if (station.homeownerId !== req.user.id) return res.status(403).json({ success: false, message: 'Not authorized' });

    // Check for overlapping slots
    const overlap = await prisma.availabilitySlot.findFirst({
      where: {
        stationId: parseInt(stationId),
        availableDate,
        slotStatus: { not: 'BLOCKED' },
        OR: [
          { startTime: { lte: startTime }, endTime: { gt: startTime } },
          { startTime: { lt: endTime }, endTime: { gte: endTime } },
          { startTime: { gte: startTime }, endTime: { lte: endTime } }
        ]
      }
    });

    if (overlap) {
      return res.status(409).json({ success: false, message: 'Time slot overlaps with an existing slot' });
    }

    const slot = await prisma.availabilitySlot.create({
      data: { stationId: parseInt(stationId), availableDate, startTime, endTime }
    });
    res.status(201).json({ success: true, message: 'Slot created', data: slot });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/slots/:stationId
const getSlotsByStation = async (req, res) => {
  try {
    const stationId = parseInt(req.params.stationId);
    const { date } = req.query;
    const where = { stationId };
    if (date) where.availableDate = date;

    const slots = await prisma.availabilitySlot.findMany({
      where,
      orderBy: [{ availableDate: 'asc' }, { startTime: 'asc' }]
    });
    res.json({ success: true, data: slots });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// PUT /api/slots/:id
const updateSlot = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const slot = await prisma.availabilitySlot.findUnique({
      where: { id },
      include: { station: true }
    });
    if (!slot) return res.status(404).json({ success: false, message: 'Slot not found' });
    if (slot.station.homeownerId !== req.user.id) return res.status(403).json({ success: false, message: 'Not authorized' });

    const { availableDate, startTime, endTime, slotStatus } = req.body;
    const updated = await prisma.availabilitySlot.update({
      where: { id },
      data: { availableDate, startTime, endTime, slotStatus }
    });
    res.json({ success: true, message: 'Slot updated', data: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// DELETE /api/slots/:id
const deleteSlot = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const slot = await prisma.availabilitySlot.findUnique({
      where: { id },
      include: { station: true }
    });
    if (!slot) return res.status(404).json({ success: false, message: 'Slot not found' });
    if (slot.station.homeownerId !== req.user.id) return res.status(403).json({ success: false, message: 'Not authorized' });
    if (slot.slotStatus === 'BOOKED') return res.status(400).json({ success: false, message: 'Cannot delete a booked slot' });

    await prisma.availabilitySlot.delete({ where: { id } });
    res.json({ success: true, message: 'Slot deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { createSlot, getSlotsByStation, updateSlot, deleteSlot };
