const { spawn } = require('child_process');
const path = require('path');

const rootDir = __dirname;
const serverDir = path.join(rootDir, 'chargeshare', 'server');
const clientDir = path.join(rootDir, 'chargeshare', 'client');

console.log('⚡ Starting ChargeShare Backend & Frontend...\n');

const isWindows = process.platform === 'win32';
const npmCmd = isWindows ? 'npm.cmd' : 'npm';

// Start Server
const server = spawn(npmCmd, ['run', 'dev'], {
  cwd: serverDir,
  shell: true,
  stdio: 'inherit'
});

// Start Client
const client = spawn(npmCmd, ['run', 'dev'], {
  cwd: clientDir,
  shell: true,
  stdio: 'inherit'
});

const cleanup = () => {
  console.log('\n🛑 Shutting down ChargeShare servers...');
  if (server) server.kill();
  if (client) client.kill();
  process.exit(0);
};

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
