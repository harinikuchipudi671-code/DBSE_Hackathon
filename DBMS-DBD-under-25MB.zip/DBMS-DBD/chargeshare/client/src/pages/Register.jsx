import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Zap, User, Mail, Phone, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phoneNumber: '',
    role: searchParams.get('role') || 'EV_OWNER',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (form.password !== form.confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (form.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    try {
      setLoading(true);
      await register({
        fullName: form.fullName,
        email: form.email,
        password: form.password,
        phoneNumber: form.phoneNumber,
        role: form.role,
      });
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#010102',
        padding: '36px 20px',
      }}
    >
      <div style={{ width: '100%', maxWidth: 420 }}>
        {/* Brand */}
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <Link
            to="/"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              textDecoration: 'none',
              marginBottom: 16,
            }}
          >
            <div
              style={{
                width: 28,
                height: 28,
                borderRadius: 6,
                background: '#5e6ad2',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#ffffff',
              }}
            >
              <Zap size={16} fill="currentColor" stroke="none" />
            </div>
            <span style={{ fontWeight: 600, fontSize: 16, color: '#f7f8f8', letterSpacing: '-0.02em' }}>
              ChargeShare
            </span>
          </Link>
          <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
            Create an account
          </h1>
          <p style={{ fontSize: 13, color: '#8a8f98' }}>Join the residential charging network</p>
        </div>

        {/* Card */}
        <div
          style={{
            background: '#0f1011',
            border: '1px solid #23252a',
            borderRadius: 8,
            padding: '24px',
          }}
        >
          {/* Role Segmented Control */}
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: 4,
              marginBottom: 20,
              padding: 3,
              background: '#141516',
              borderRadius: 6,
              border: '1px solid #23252a',
            }}
          >
            {[
              { v: 'EV_OWNER', label: 'EV Driver', sub: 'Book chargers' },
              { v: 'HOMEOWNER', label: 'Charging Host', sub: 'List wallbox' },
            ].map((r) => {
              const active = form.role === r.v;
              return (
                <button
                  key={r.v}
                  type="button"
                  onClick={() => update('role', r.v)}
                  style={{
                    padding: '8px 10px',
                    borderRadius: 4,
                    border: 'none',
                    background: active ? '#191a1b' : 'transparent',
                    boxShadow: active ? '0 1px 3px rgba(0,0,0,0.4)' : 'none',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease',
                    textAlign: 'center',
                  }}
                >
                  <div style={{ fontSize: 12, fontWeight: active ? 600 : 400, color: active ? '#f7f8f8' : '#8a8f98' }}>
                    {r.label}
                  </div>
                  <div style={{ fontSize: 10, color: '#62666d', marginTop: 1 }}>{r.sub}</div>
                </button>
              );
            })}
          </div>

          <form onSubmit={handleSubmit}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <label className="form-label">Full Name *</label>
                <div style={{ position: 'relative' }}>
                  <User
                    size={15}
                    style={{
                      position: 'absolute',
                      left: 11,
                      top: '50%',
                      transform: 'translateY(-50%)',
                      color: '#62666d',
                    }}
                  />
                  <input
                    className="form-input"
                    style={{ paddingLeft: 34 }}
                    type="text"
                    placeholder="Arjun Mehta"
                    value={form.fullName}
                    onChange={(e) => update('fullName', e.target.value)}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="form-label">Email Address *</label>
                <div style={{ position: 'relative' }}>
                  <Mail
                    size={15}
                    style={{
                      position: 'absolute',
                      left: 11,
                      top: '50%',
                      transform: 'translateY(-50%)',
                      color: '#62666d',
                    }}
                  />
                  <input
                    className="form-input"
                    style={{ paddingLeft: 34 }}
                    type="email"
                    placeholder="arjun@example.com"
                    value={form.email}
                    onChange={(e) => update('email', e.target.value)}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="form-label">Phone Number</label>
                <div style={{ position: 'relative' }}>
                  <Phone
                    size={15}
                    style={{
                      position: 'absolute',
                      left: 11,
                      top: '50%',
                      transform: 'translateY(-50%)',
                      color: '#62666d',
                    }}
                  />
                  <input
                    className="form-input"
                    style={{ paddingLeft: 34 }}
                    type="tel"
                    placeholder="+91 98765 43210"
                    value={form.phoneNumber}
                    onChange={(e) => update('phoneNumber', e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <div>
                  <label className="form-label">Password *</label>
                  <input
                    className="form-input"
                    type={showPw ? 'text' : 'password'}
                    placeholder="Min 6 chars"
                    value={form.password}
                    onChange={(e) => update('password', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <label className="form-label">Confirm *</label>
                  <input
                    className="form-input"
                    type={showPw ? 'text' : 'password'}
                    placeholder="Repeat"
                    value={form.confirmPassword}
                    onChange={(e) => update('confirmPassword', e.target.value)}
                    required
                  />
                </div>
              </div>

              {error && (
                <div
                  style={{
                    padding: '8px 12px',
                    borderRadius: 6,
                    background: 'rgba(235, 87, 87, 0.1)',
                    border: '1px solid rgba(235, 87, 87, 0.25)',
                    color: '#f87171',
                    fontSize: 12,
                    lineHeight: 1.4,
                  }}
                >
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="btn-primary"
                style={{ width: '100%', padding: '9px 16px', fontSize: 13, marginTop: 4 }}
              >
                {loading ? 'Creating account...' : 'Create Account'}
              </button>
            </div>
          </form>
        </div>

        <p style={{ textAlign: 'center', marginTop: 20, fontSize: 12, color: '#8a8f98' }}>
          Already have an account?{' '}
          <Link to="/login" style={{ color: '#5e6ad2', textDecoration: 'none', fontWeight: 500 }}>
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
