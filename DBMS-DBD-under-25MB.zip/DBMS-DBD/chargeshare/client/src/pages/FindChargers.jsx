import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  MapPin, Search, Star,
  CheckCircle, AlertCircle, X,
  BatteryCharging
} from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import DashboardLayout from '../layouts/DashboardLayout';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

// Clean Leaflet marker pin styled with Linear tokens
const customPinIcon = (color = '#5e6ad2') =>
  L.divIcon({
    className: 'custom-map-pin',
    html: `<div style="
      background: ${color};
      width: 28px;
      height: 28px;
      border-radius: 50% 50% 50% 0;
      transform: rotate(-45deg);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(0,0,0,0.6);
      border: 2px solid #0f1011;
    ">
      <div style="transform: rotate(45deg); display: flex; align-items: center; justify-content: center;">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="#ffffff" stroke="none">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
        </svg>
      </div>
    </div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 28],
    popupAnchor: [0, -28],
  });

function ChangeView({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    if (center && center[0] && center[1]) {
      map.setView(center, zoom);
    }
  }, [center, zoom, map]);
  return null;
}

export default function FindChargers() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [stations, setStations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [connectorFilter, setConnectorFilter] = useState('ALL');
  const [maxPrice, setMaxPrice] = useState(50);
  const [selectedStation, setSelectedStation] = useState(null);
  const [activeTab, setActiveTab] = useState('split'); // 'split' | 'map' | 'list'

  // Booking modal state
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [bookingStation, setBookingStation] = useState(null);
  const [slots, setSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [selectedSlotId, setSelectedSlotId] = useState('');
  const [bookingDate, setBookingDate] = useState(new Date().toISOString().split('T')[0]);
  const [vehicleModel, setVehicleModel] = useState(user?.evProfile?.vehicleModel || 'Tata Nexon EV');
  const [licensePlate, setLicensePlate] = useState(user?.evProfile?.licensePlate || 'MH 02 AB 1234');
  const [estimatedKwh, setEstimatedKwh] = useState(25);
  const [bookingNotes, setBookingNotes] = useState('');
  const [submittingBooking, setSubmittingBooking] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(null);
  const [bookingError, setBookingError] = useState('');

  const fetchStations = useCallback(async () => {
    try {
      setLoading(true);
      const res = await api.get('/stations');
      const data = res.data?.data || res.data || [];
      setStations(data);
      if (data.length > 0) {
        setSelectedStation(data[0]);
      }
    } catch (err) {
      console.error('Failed to fetch stations:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStations();
  }, [fetchStations]);

  const handleOpenBooking = async (station) => {
    setBookingStation(station);
    setBookingModalOpen(true);
    setBookingError('');
    setBookingSuccess(null);
    setSelectedSlotId('');

    try {
      setLoadingSlots(true);
      const res = await api.get(`/slots/station/${station.id}?date=${bookingDate}`);
      const fetchedSlots = res.data?.data || res.data || [];
      setSlots(fetchedSlots);
      if (fetchedSlots.length > 0) {
        setSelectedSlotId(fetchedSlots[0].id);
      }
    } catch (err) {
      console.error('Failed to fetch slots:', err);
    } finally {
      setLoadingSlots(false);
    }
  };

  const handleCreateReservation = async (e) => {
    e.preventDefault();
    setBookingError('');
    setSubmittingBooking(true);

    try {
      const selectedSlot = slots.find((s) => s.id === selectedSlotId);
      const payload = {
        stationId: bookingStation.id,
        slotId: selectedSlotId || undefined,
        bookingDate,
        startTime: selectedSlot ? selectedSlot.startTime : '10:00',
        endTime: selectedSlot ? selectedSlot.endTime : '12:00',
        vehicleModel,
        licensePlate,
        estimatedKwh: Number(estimatedKwh),
        notes: bookingNotes,
      };

      const res = await api.post('/reservations', payload);
      setBookingSuccess(res.data?.data || res.data || true);
    } catch (err) {
      setBookingError(err.response?.data?.message || 'Failed to create reservation. Please try again.');
    } finally {
      setSubmittingBooking(false);
    }
  };

  const filteredStations = stations.filter((s) => {
    const nameStr = (s.stationName || s.name || s.title || '').toLowerCase();
    const addrStr = (s.completeAddress || s.address || '').toLowerCase();
    const cityStr = (s.city || '').toLowerCase();
    const query = searchQuery.toLowerCase();

    const matchesSearch = nameStr.includes(query) || addrStr.includes(query) || cityStr.includes(query);
    const matchesConnector =
      connectorFilter === 'ALL' || (s.connectorType || '').toUpperCase().includes(connectorFilter);
    const matchesPrice = (s.pricePerKwh || s.ratePerKwh || 0) <= maxPrice;

    return matchesSearch && matchesConnector && matchesPrice;
  });

  const mapCenter =
    selectedStation?.latitude && selectedStation?.longitude
      ? [selectedStation.latitude, selectedStation.longitude]
      : [19.076, 72.8777];

  return (
    <DashboardLayout>
      <div style={{ paddingBottom: 40 }}>
        {/* Header & Controls */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 16 }}>
            <div>
              <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
                Find EV Chargers
              </h1>
              <p style={{ color: '#8a8f98', fontSize: 13 }}>
                Geospatial discovery of verified residential wallboxes with slot reservation
              </p>
            </div>

            {/* Segmented View Switcher */}
            <div
              style={{
                display: 'inline-flex',
                gap: 2,
                background: '#0f1011',
                padding: 3,
                borderRadius: 6,
                border: '1px solid #23252a',
              }}
            >
              {[
                { id: 'split', label: 'Split' },
                { id: 'map', label: 'Map' },
                { id: 'list', label: 'List' },
              ].map((v) => {
                const active = activeTab === v.id;
                return (
                  <button
                    key={v.id}
                    onClick={() => setActiveTab(v.id)}
                    style={{
                      padding: '5px 12px',
                      borderRadius: 4,
                      fontSize: 12,
                      fontWeight: active ? 500 : 400,
                      border: 'none',
                      cursor: 'pointer',
                      background: active ? '#191a1b' : 'transparent',
                      color: active ? '#f7f8f8' : '#8a8f98',
                      transition: 'all 0.15s ease',
                    }}
                  >
                    {v.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Filter Bar */}
          <div
            style={{
              marginTop: 16,
              background: '#0f1011',
              borderRadius: 8,
              padding: '12px 16px',
              border: '1px solid #23252a',
              display: 'flex',
              flexWrap: 'wrap',
              gap: 12,
              alignItems: 'center',
            }}
          >
            {/* Search Input */}
            <div style={{ flex: '1 1 240px', position: 'relative' }}>
              <Search
                size={14}
                color="#62666d"
                style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)' }}
              />
              <input
                type="text"
                placeholder="Filter by locality, city, address..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="form-input"
                style={{ paddingLeft: 32, fontSize: 12 }}
              />
            </div>

            {/* Connector Dropdown */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontSize: 12, color: '#8a8f98' }}>Port:</span>
              <select
                value={connectorFilter}
                onChange={(e) => setConnectorFilter(e.target.value)}
                style={{
                  padding: '6px 10px',
                  borderRadius: 6,
                  background: '#141516',
                  border: '1px solid #23252a',
                  color: '#f7f8f8',
                  fontSize: 12,
                  outline: 'none',
                  cursor: 'pointer',
                }}
              >
                <option value="ALL">All Standards</option>
                <option value="CCS">CCS</option>
                <option value="TYPE2">Type 2</option>
                <option value="CHADEMO">CHAdeMO</option>
                <option value="J1772">J1772</option>
              </select>
            </div>

            {/* Price Slider */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 12, color: '#8a8f98' }}>Max Tariff:</span>
              <span style={{ fontSize: 12, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                ₹{maxPrice}/kWh
              </span>
              <input
                type="range"
                min="5"
                max="50"
                step="1"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                style={{ width: 80, accentColor: '#5e6ad2', cursor: 'pointer' }}
              />
            </div>

            <div style={{ marginLeft: 'auto', fontSize: 12, color: '#62666d' }}>
              <span style={{ color: '#f7f8f8', fontWeight: 500, fontFamily: 'monospace' }}>
                {filteredStations.length}
              </span>{' '}
              chargers matched
            </div>
          </div>
        </div>

        {/* Content Layout */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns:
              activeTab === 'map' ? '1fr' : activeTab === 'list' ? '1fr' : '1fr 1fr',
            gap: 16,
            minHeight: 640,
          }}
        >
          {/* Station List Column */}
          {activeTab !== 'map' && (
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: 10,
                maxHeight: activeTab === 'split' ? '700px' : 'none',
                overflowY: activeTab === 'split' ? 'auto' : 'visible',
                paddingRight: activeTab === 'split' ? 4 : 0,
              }}
            >
              {loading ? (
                <div style={{ textAlign: 'center', padding: 40, color: '#8a8f98' }}>
                  <div className="spinner mx-auto mb-3" />
                  Loading charging nodes...
                </div>
              ) : filteredStations.length === 0 ? (
                <div
                  className="panel"
                  style={{
                    padding: '36px 20px',
                    textAlign: 'center',
                    color: '#8a8f98',
                  }}
                >
                  <AlertCircle size={24} color="#62666d" style={{ margin: '0 auto 8px' }} />
                  <h3 style={{ color: '#f7f8f8', fontWeight: 500, fontSize: 14, marginBottom: 4 }}>
                    No Stations Found
                  </h3>
                  <p style={{ fontSize: 12, color: '#62666d' }}>
                    Adjust your connector type, price ceiling, or search parameters.
                  </p>
                </div>
              ) : (
                filteredStations.map((station) => {
                  const isSelected = selectedStation?.id === station.id;
                  const price = station.pricePerKwh || station.ratePerKwh || 18;
                  const power = station.chargingCapacityKw || station.powerOutput || 7.4;
                  const rating = station.rating || station.avgRating || 4.8;

                  return (
                    <div
                      key={station.id}
                      onClick={() => setSelectedStation(station)}
                      style={{
                        background: isSelected ? '#141516' : '#0f1011',
                        border: isSelected ? '1px solid #5e6ad2' : '1px solid #23252a',
                        borderRadius: 8,
                        padding: '14px 16px',
                        cursor: 'pointer',
                        transition: 'all 0.15s ease',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                        <div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                            <span className="badge badge-active">Available</span>
                            <span className="badge badge-completed">{station.connectorType || 'Type 2'}</span>
                            <span style={{ fontSize: 11, color: '#8a8f98', fontFamily: 'monospace' }}>
                              {power} kW
                            </span>
                          </div>

                          <h3 style={{ fontSize: 14, fontWeight: 500, color: '#f7f8f8', marginBottom: 2 }}>
                            {station.stationName || station.name || station.title}
                          </h3>

                          <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: '#8a8f98', fontSize: 11 }}>
                            <MapPin size={12} color="#62666d" />
                            <span>{station.completeAddress || station.address || 'Mumbai'}</span>
                          </div>
                        </div>

                        {/* Price & Rating */}
                        <div style={{ textAlign: 'right' }}>
                          <div style={{ fontSize: 16, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                            ₹{price}
                            <span style={{ fontSize: 11, color: '#8a8f98', fontWeight: 400 }}>/kWh</span>
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 3, justifyContent: 'flex-end', marginTop: 2 }}>
                            <Star size={11} color="#f59e0b" fill="#f59e0b" />
                            <span style={{ fontSize: 11, fontWeight: 500, color: '#f7f8f8' }}>
                              {Number(rating).toFixed(1)}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Footer Actions */}
                      <div
                        style={{
                          marginTop: 10,
                          paddingTop: 10,
                          borderTop: '1px solid #1a1c20',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                        }}
                      >
                        <div style={{ fontSize: 11, color: '#62666d' }}>
                          Host: {station.homeowner?.fullName || station.host?.fullName || 'Verified'}
                        </div>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenBooking(station);
                          }}
                          className="btn-primary"
                          style={{ padding: '5px 12px', fontSize: 11 }}
                        >
                          <BatteryCharging size={13} /> Reserve Slot
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* Interactive Dark Map Column */}
          {activeTab !== 'list' && (
            <div
              style={{
                borderRadius: 8,
                overflow: 'hidden',
                border: '1px solid #23252a',
                position: 'relative',
                height: '700px',
              }}
            >
              <MapContainer
                center={mapCenter}
                zoom={13}
                style={{ height: '100%', width: '100%', background: '#090a0b' }}
              >
                <ChangeView center={mapCenter} zoom={13} />
                {/* CartoDB Dark Matter dark tile layer */}
                <TileLayer
                  attribution='&copy; <a href="https://carto.com/">CartoDB</a>'
                  url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                />

                {filteredStations.map((station) => {
                  const lat = station.latitude || 19.076;
                  const lng = station.longitude || 72.8777;
                  const isSelected = selectedStation?.id === station.id;

                  return (
                    <Marker
                      key={station.id}
                      position={[lat, lng]}
                      icon={customPinIcon(isSelected ? '#27a644' : '#5e6ad2')}
                      eventHandlers={{
                        click: () => setSelectedStation(station),
                      }}
                    >
                      <Popup>
                        <div style={{ minWidth: 180 }}>
                          <div style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8', marginBottom: 2 }}>
                            {station.stationName || station.name}
                          </div>
                          <div style={{ fontSize: 11, color: '#8a8f98', marginBottom: 6 }}>
                            {station.completeAddress || station.address}
                          </div>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                            <span style={{ fontSize: 12, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                              ₹{station.pricePerKwh || 18}/kWh
                            </span>
                            <span style={{ fontSize: 11, color: '#8a8f98' }}>
                              {station.chargingCapacityKw || 7.4} kW
                            </span>
                          </div>
                          <button
                            onClick={() => handleOpenBooking(station)}
                            className="btn-primary"
                            style={{ width: '100%', padding: '5px 10px', fontSize: 11 }}
                          >
                            Reserve Slot
                          </button>
                        </div>
                      </Popup>
                    </Marker>
                  );
                })}
              </MapContainer>
            </div>
          )}
        </div>

        {/* Booking Reservation Modal */}
        {bookingModalOpen && bookingStation && (
          <div
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9999,
              background: 'rgba(0, 0, 0, 0.75)',
              backdropFilter: 'blur(4px)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 16,
            }}
          >
            <div
              style={{
                background: '#0f1011',
                border: '1px solid #23252a',
                borderRadius: 8,
                width: '100%',
                maxWidth: 480,
                maxHeight: '90vh',
                overflowY: 'auto',
                padding: '24px',
                boxShadow: '0 24px 64px rgba(0,0,0,0.8)',
                position: 'relative',
              }}
            >
              <button
                onClick={() => setBookingModalOpen(false)}
                aria-label="Close dialog"
                style={{
                  position: 'absolute',
                  right: 18,
                  top: 18,
                  background: 'none',
                  border: 'none',
                  color: '#62666d',
                  cursor: 'pointer',
                  padding: 2,
                }}
              >
                <X size={16} />
              </button>

              {bookingSuccess ? (
                <div style={{ textAlign: 'center', padding: '16px 0' }}>
                  <div
                    style={{
                      width: 44,
                      height: 44,
                      borderRadius: '50%',
                      background: 'rgba(39, 166, 68, 0.1)',
                      border: '1px solid rgba(39, 166, 68, 0.25)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      margin: '0 auto 12px',
                    }}
                  >
                    <CheckCircle size={22} color="#27a644" />
                  </div>
                  <h3 style={{ fontSize: 18, fontWeight: 600, color: '#f7f8f8', marginBottom: 4 }}>
                    Booking Request Submitted
                  </h3>
                  <p style={{ color: '#8a8f98', fontSize: 12, marginBottom: 20 }}>
                    The station host has been notified. You can track status under Bookings.
                  </p>

                  <div
                    style={{
                      background: '#141516',
                      borderRadius: 6,
                      padding: 14,
                      textAlign: 'left',
                      border: '1px solid #23252a',
                      marginBottom: 20,
                      fontSize: 12,
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                      <span style={{ color: '#8a8f98' }}>Station:</span>
                      <span style={{ color: '#f7f8f8', fontWeight: 500 }}>
                        {bookingStation.stationName || bookingStation.name}
                      </span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                      <span style={{ color: '#8a8f98' }}>Date:</span>
                      <span style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>{bookingDate}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: '#8a8f98' }}>Est. Cost:</span>
                      <span style={{ color: '#27a644', fontWeight: 600, fontFamily: 'monospace' }}>
                        ₹{(estimatedKwh * (bookingStation.pricePerKwh || 18)).toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: 10 }}>
                    <button
                      onClick={() => {
                        setBookingModalOpen(false);
                        navigate('/reservations');
                      }}
                      className="btn-primary"
                      style={{ flex: 1, padding: '8px 14px' }}
                    >
                      View Reservations
                    </button>
                    <button
                      onClick={() => setBookingModalOpen(false)}
                      className="btn-secondary"
                      style={{ flex: 1, padding: '8px 14px' }}
                    >
                      Close
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleCreateReservation}>
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: '#5e6ad2', letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: 4 }}>
                      Reservation Request
                    </div>
                    <h2 style={{ fontSize: 16, fontWeight: 600, color: '#f7f8f8' }}>
                      {bookingStation.stationName || bookingStation.name}
                    </h2>
                    <p style={{ color: '#8a8f98', fontSize: 12 }}>
                      {bookingStation.completeAddress || bookingStation.address}
                    </p>
                  </div>

                  {bookingError && (
                    <div
                      style={{
                        background: 'rgba(235, 87, 87, 0.1)',
                        border: '1px solid rgba(235, 87, 87, 0.25)',
                        color: '#f87171',
                        padding: '8px 12px',
                        borderRadius: 6,
                        fontSize: 12,
                        marginBottom: 14,
                      }}
                    >
                      {bookingError}
                    </div>
                  )}

                  <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    <div>
                      <label className="form-label">Reservation Date</label>
                      <input
                        type="date"
                        min={new Date().toISOString().split('T')[0]}
                        value={bookingDate}
                        onChange={(e) => setBookingDate(e.target.value)}
                        required
                        className="form-input"
                      />
                    </div>

                    <div>
                      <label className="form-label">Select Time Slot</label>
                      {loadingSlots ? (
                        <div style={{ color: '#8a8f98', fontSize: 12 }}>Fetching host slots...</div>
                      ) : slots.length === 0 ? (
                        <div
                          style={{
                            padding: '10px 12px',
                            borderRadius: 6,
                            background: '#141516',
                            border: '1px solid #23252a',
                            color: '#8a8f98',
                            fontSize: 12,
                          }}
                        >
                          Standard 2-hour window (10:00 – 12:00) will be requested.
                        </div>
                      ) : (
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 6 }}>
                          {slots.map((s) => (
                            <button
                              key={s.id}
                              type="button"
                              onClick={() => setSelectedSlotId(s.id)}
                              style={{
                                padding: '8px 10px',
                                borderRadius: 6,
                                fontSize: 12,
                                fontWeight: 500,
                                background: selectedSlotId === s.id ? '#191a1b' : '#141516',
                                color: selectedSlotId === s.id ? '#f7f8f8' : '#8a8f98',
                                border: selectedSlotId === s.id ? '1px solid #5e6ad2' : '1px solid #23252a',
                                cursor: 'pointer',
                                textAlign: 'center',
                              }}
                            >
                              {s.startTime} – {s.endTime}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                      <div>
                        <label className="form-label">Vehicle</label>
                        <input
                          type="text"
                          placeholder="e.g. Tata Nexon EV"
                          value={vehicleModel}
                          onChange={(e) => setVehicleModel(e.target.value)}
                          required
                          className="form-input"
                        />
                      </div>
                      <div>
                        <label className="form-label">License Plate</label>
                        <input
                          type="text"
                          placeholder="e.g. MH 02 AB 1234"
                          value={licensePlate}
                          onChange={(e) => setLicensePlate(e.target.value)}
                          required
                          className="form-input"
                        />
                      </div>
                    </div>

                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <label className="form-label">Estimated Energy</label>
                        <span style={{ fontSize: 12, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                          {estimatedKwh} kWh
                        </span>
                      </div>
                      <input
                        type="range"
                        min="5"
                        max="100"
                        step="1"
                        value={estimatedKwh}
                        onChange={(e) => setEstimatedKwh(Number(e.target.value))}
                        style={{ width: '100%', accentColor: '#5e6ad2', cursor: 'pointer' }}
                      />
                    </div>

                    <div>
                      <label className="form-label">Notes for Host (Optional)</label>
                      <textarea
                        rows="2"
                        placeholder="Arrival details or instructions..."
                        value={bookingNotes}
                        onChange={(e) => setBookingNotes(e.target.value)}
                        className="form-input"
                        style={{ resize: 'none' }}
                      />
                    </div>

                    {/* Estimate Calculation */}
                    <div
                      style={{
                        background: '#141516',
                        borderRadius: 6,
                        padding: '10px 12px',
                        border: '1px solid #23252a',
                        fontSize: 12,
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <span style={{ color: '#8a8f98' }}>Tariff:</span>
                        <span style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>
                          ₹{bookingStation.pricePerKwh || 18}/kWh
                        </span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 6, borderTop: '1px solid #23252a' }}>
                        <span style={{ color: '#f7f8f8', fontWeight: 500 }}>Estimated Total:</span>
                        <span style={{ color: '#27a644', fontWeight: 600, fontFamily: 'monospace' }}>
                          ₹{(estimatedKwh * (bookingStation.pricePerKwh || 18)).toFixed(2)}
                        </span>
                      </div>
                    </div>

                    <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                      <button
                        type="button"
                        onClick={() => setBookingModalOpen(false)}
                        className="btn-secondary"
                        style={{ flex: 1, padding: '8px 14px' }}
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={submittingBooking}
                        className="btn-primary"
                        style={{ flex: 1.5, padding: '8px 14px' }}
                      >
                        {submittingBooking ? 'Submitting...' : 'Submit Request'}
                      </button>
                    </div>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
