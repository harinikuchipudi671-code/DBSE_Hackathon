import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Loader while checking auth
const Loader = () => (
  <div className="flex items-center justify-center min-h-screen" style={{background:'#050d1a'}}>
    <div className="text-center">
      <div className="spinner mx-auto mb-4"/>
      <p style={{color:'#4d97f7', fontSize:14}}>Loading ChargeShare...</p>
    </div>
  </div>
);

export const ProtectedRoute = ({ children, roles }) => {
  const { user, loading } = useAuth();
  if (loading) return <Loader />;
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/dashboard" replace />;
  return children;
};

export const PublicRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <Loader />;
  if (user) return <Navigate to="/dashboard" replace />;
  return children;
};
