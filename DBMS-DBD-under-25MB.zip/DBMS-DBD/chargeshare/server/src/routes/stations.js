const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const {
  createStation, getAllStations, getNearbyStations,
  getStationById, getMyStations, updateStation, deleteStation
} = require('../controllers/stationController');
const { getStationReviews } = require('../controllers/reviewController');

router.get('/nearby', authenticate, getNearbyStations);
router.get('/my', authenticate, authorize('HOMEOWNER'), getMyStations);
router.post('/', authenticate, authorize('HOMEOWNER'), createStation);
router.get('/', authenticate, getAllStations);
router.get('/:id', authenticate, getStationById);
router.put('/:id', authenticate, authorize('HOMEOWNER'), updateStation);
router.delete('/:id', authenticate, deleteStation);
router.get('/:id/reviews', authenticate, getStationReviews);

module.exports = router;
