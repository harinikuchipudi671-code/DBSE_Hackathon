import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Plug, TrendingUp, Clock, CheckCircle, Plus } from 'lucide-react';
import DashboardLayout from '../layouts/DashboardLayout';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const StatCard = ({ icon: Icon, label, value, sub }) => (
  <div className="stat-card">
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
      <span style={{ fontSize: 12, fontWeight: 500, color: '#8a8f98' }}>{label}</span>
      <div
        style={{
          width: 28,
          height: 28,
          borderRadius: 6,
          background: '#141516',
          border: '1px solid #23252a',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#8a8f98',
        }}
      >
        <Icon size={14} />
      </div>
    </div>
    <div style={{ fontSize: 24, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace', letterSpacing: '-0.02em', marginBottom: 4 }}>
      {value}
    </div>
    {sub && <div style={{ fontSize: 11, color: '#62666d' }}>{sub}</div>}
  </div>
);

export default function HomeownerDashboard() {
  const [stations, setStations] = useState([]);
  const [reservations, setReservations] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/stations/my'),
      api.get('/reservations/received'),
      api.get('/sessions/history'),
    ])
      .then(([s, r, se]) => {
        setStations(s.data?.data || []);
        setReservations(r.data?.data || []);
        setSessions(se.data?.data || []);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const totalEarnings = sessions
    .filter((s) => s.sessionStatus === 'COMPLETED')
    .reduce((a, s) => a + (s.totalAmount || 0), 0);

  const pending = reservations.filter((r) => r.bookingStatus === 'PENDING').length;
  const activeStations = stations.filter((s) => s.isActive).length;

  const handleStatusUpdate = async (id, status) => {
    try {
      await api.patch(`/reservations/${id}/status`, { status });
      setReservations((prev) =>
        prev.map((r) => (r.id === id ? { ...r, bookingStatus: status } : r))
      );
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to update reservation');
    }
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 300 }}>
          <div className="spinner" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      {/* Header */}
      <div style={{ marginBottom: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
            Host Telemetry
          </h1>
          <p style={{ color: '#8a8f98', fontSize: 13 }}>
            Manage charging stations, evaluate incoming bookings, and track host revenue
          </p>
        </div>
        <Link to="/stations" className="btn-primary" style={{ textDecoration: 'none', padding: '7px 14px', fontSize: 13 }}>
          <Plus size={14} /> Add Station
        </Link>
      </div>

      {/* Metrics Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: 14, marginBottom: 24 }}>
        <StatCard icon={Plug} label="Registered Ports" value={stations.length} sub={`${activeStations} currently online`} />
        <StatCard
          icon={CheckCircle}
          label="Active Listings"
          value={activeStations}
          sub="Accepting bookings"
        />
        <StatCard
          icon={Clock}
          label="Pending Inquiries"
          value={pending}
          sub="Awaiting review"
        />
        <StatCard
          icon={TrendingUp}
          label="Accumulated Revenue"
          value={`₹${totalEarnings.toFixed(2)}`}
          sub={`${sessions.filter((s) => s.sessionStatus === 'COMPLETED').length} sessions settled`}
        />
      </div>

      {/* Grid: Pending Inquiries & Station Overview */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 20 }}>
        {/* Pending Requests */}
        <div className="panel" style={{ padding: '18px 20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.01em' }}>
                Pending Reservation Requests
              </h2>
              {pending > 0 && <span className="badge badge-pending">{pending} action required</span>}
            </div>
            <Link to="/reservations" style={{ fontSize: 12, color: '#8a8f98', textDecoration: 'none' }}>
              View all →
            </Link>
          </div>

          {reservations.filter((r) => r.bookingStatus === 'PENDING').length === 0 ? (
            <div style={{ padding: '40px 16px', textAlign: 'center', color: '#62666d', fontSize: 13 }}>
              No pending driver booking requests at this time
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {reservations
                .filter((r) => r.bookingStatus === 'PENDING')
                .slice(0, 4)
                .map((r) => (
                  <div
                    key={r.id}
                    style={{
                      padding: '14px',
                      borderRadius: 6,
                      background: '#141516',
                      border: '1px solid #23252a',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: 10,
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8' }}>
                          {r.evOwner?.fullName || 'EV Driver'}
                        </div>
                        <div style={{ fontSize: 11, color: '#8a8f98', marginTop: 2 }}>
                          {r.station?.stationName} · {r.bookingDate} ({r.startTime} – {r.endTime})
                        </div>
                        {r.notes && (
                          <div style={{ fontSize: 11, color: '#62666d', marginTop: 4, fontStyle: 'italic' }}>
                            "{r.notes}"
                          </div>
                        )}
                      </div>
                      {r.estimatedCost && (
                        <div style={{ fontSize: 13, fontWeight: 600, color: '#27a644', fontFamily: 'monospace' }}>
                          ≈ ₹{r.estimatedCost.toFixed(2)}
                        </div>
                      )}
                    </div>

                    <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', paddingTop: 6, borderTop: '1px solid #1f2126' }}>
                      <button
                        onClick={() => handleStatusUpdate(r.id, 'REJECTED')}
                        className="btn-danger"
                        style={{ padding: '4px 10px', fontSize: 11 }}
                      >
                        Decline
                      </button>
                      <button
                        onClick={() => handleStatusUpdate(r.id, 'CONFIRMED')}
                        className="btn-primary"
                        style={{ padding: '4px 12px', fontSize: 11 }}
                      >
                        Confirm Slot
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>

        {/* Stations List */}
        <div className="panel" style={{ padding: '18px 20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.01em' }}>
              Your Deployed Stations
            </h2>
            <Link to="/stations" style={{ fontSize: 12, color: '#8a8f98', textDecoration: 'none' }}>
              Manage →
            </Link>
          </div>

          {stations.length === 0 ? (
            <div style={{ padding: '40px 16px', textAlign: 'center' }}>
              <Plug size={24} color="#3e3e44" style={{ margin: '0 auto 10px' }} />
              <div style={{ color: '#8a8f98', fontSize: 13, marginBottom: 14 }}>
                No charging stations listed yet
              </div>
              <Link to="/stations" className="btn-secondary" style={{ textDecoration: 'none', fontSize: 12, padding: '6px 14px' }}>
                Add First Station
              </Link>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {stations.map((s) => (
                <div
                  key={s.id}
                  style={{
                    padding: '12px 14px',
                    borderRadius: 6,
                    background: '#141516',
                    border: '1px solid #23252a',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}
                >
                  <div style={{ minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                      <span
                        style={{
                          width: 6,
                          height: 6,
                          borderRadius: '50%',
                          background: s.isActive ? '#27a644' : '#62666d',
                        }}
                      />
                      <span style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {s.stationName}
                      </span>
                    </div>
                    <div style={{ fontSize: 11, color: '#8a8f98' }}>
                      {s.chargerType} · {s.chargingCapacityKw} kW ·{' '}
                      <span style={{ color: '#d0d6e0', fontFamily: 'monospace' }}>₹{s.pricePerKwh}/kWh</span>
                    </div>
                  </div>

                  <span className={s.isActive ? 'badge badge-confirmed' : 'badge badge-cancelled'}>
                    {s.isActive ? 'Online' : 'Paused'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
