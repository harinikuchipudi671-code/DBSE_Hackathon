import { useState, useEffect } from 'react';
import { CreditCard, CheckCircle, Zap, DollarSign, Shield, AlertCircle, Copy, Check, X } from 'lucide-react';
import DashboardLayout from '../layouts/DashboardLayout';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const StatCard = ({ icon: Icon, label, value, sub }) => (
  <div className="stat-card">
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
      <span style={{ fontSize: 12, fontWeight: 500, color: '#8a8f98' }}>{label}</span>
      <div
        style={{
          width: 28,
          height: 28,
          borderRadius: 6,
          background: '#141516',
          border: '1px solid #23252a',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#8a8f98',
        }}
      >
        <Icon size={14} />
      </div>
    </div>
    <div style={{ fontSize: 24, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace', letterSpacing: '-0.02em', marginBottom: 4 }}>
      {value}
    </div>
    {sub && <div style={{ fontSize: 11, color: '#62666d' }}>{sub}</div>}
  </div>
);

export default function Payments() {
  const { user } = useAuth();
  const [payments, setPayments] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedReceipt, setSelectedReceipt] = useState(null);
  const [copiedId, setCopiedId] = useState(null);

  // Pay modal state for pending sessions
  const [payModalSession, setPayModalSession] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('UPI');
  const [paying, setPaying] = useState(false);
  const [paySuccess, setPaySuccess] = useState(false);

  const fetchData = async () => {
    try {
      const [payRes, sesRes] = await Promise.all([
        api.get('/payments/history'),
        api.get('/sessions/history'),
      ]);
      setPayments(payRes.data?.data || []);
      setSessions(sesRes.data?.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const totalPaid = payments.reduce((acc, p) => acc + (p.amount || 0), 0);
  const totalKwh = payments.reduce((acc, p) => acc + (p.session?.energyConsumedKwh || 0), 0);
  const avgCostPerKwh = totalKwh > 0 ? totalPaid / totalKwh : 0;

  const unpaidSessions = sessions.filter(
    (s) => s.sessionStatus === 'COMPLETED' && !s.payment
  );

  const copyToClipboard = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handlePay = async (e) => {
    e.preventDefault();
    if (!payModalSession) return;
    try {
      setPaying(true);
      await api.post('/payments', {
        sessionId: payModalSession.id,
        paymentMethod,
      });
      setPaySuccess(true);
      setTimeout(async () => {
        setPaySuccess(false);
        setPayModalSession(null);
        await fetchData();
      }, 1500);
    } catch (err) {
      alert(err.response?.data?.message || 'Payment failed. Please try again.');
    } finally {
      setPaying(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 300 }}>
          <div className="spinner" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
          Payments & Billing
        </h1>
        <p style={{ color: '#8a8f98', fontSize: 13 }}>
          Driver expense logs, itemized receipts, and pending invoices
        </p>
      </div>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: 14, marginBottom: 24 }}>
        <StatCard
          icon={CreditCard}
          label="Cumulative Expenditure"
          value={`₹${totalPaid.toFixed(2)}`}
          sub={`${payments.length} transactions settled`}
        />
        <StatCard
          icon={Zap}
          label="Energy Charged"
          value={`${totalKwh.toFixed(1)} kWh`}
          sub="Dispatched power delivered"
        />
        <StatCard
          icon={DollarSign}
          label="Blended Rate"
          value={avgCostPerKwh > 0 ? `₹${avgCostPerKwh.toFixed(2)}/kWh` : '—'}
          sub="Average charging price"
        />
        <StatCard
          icon={Shield}
          label="Settlement Sandbox"
          value="Live Protocol"
          sub="Zero-failure simulation"
        />
      </div>

      {/* Unpaid Sessions Alert Banner */}
      {unpaidSessions.length > 0 && (
        <div
          style={{
            marginBottom: 20,
            padding: '16px 18px',
            borderRadius: 8,
            background: '#141516',
            border: '1px solid #f59e0b',
            display: 'flex',
            flexDirection: 'column',
            gap: 12,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <AlertCircle size={16} color="#f59e0b" />
            <span style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8' }}>
              Pending Invoices Requiring Settlement ({unpaidSessions.length})
            </span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {unpaidSessions.map((s) => (
              <div
                key={s.id}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  background: '#0f1011',
                  border: '1px solid #23252a',
                  padding: '10px 14px',
                  borderRadius: 6,
                  flexWrap: 'wrap',
                  gap: 8,
                }}
              >
                <div>
                  <div style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8' }}>
                    {s.reservation?.station?.stationName || 'Charging Station'}
                  </div>
                  <div style={{ fontSize: 11, color: '#8a8f98' }}>
                    {s.energyConsumedKwh?.toFixed(2)} kWh dispensed · Session #{s.id}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ fontSize: 15, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                    ₹{s.totalAmount?.toFixed(2)}
                  </div>
                  <button
                    onClick={() => setPayModalSession(s)}
                    className="btn-primary"
                    style={{ padding: '5px 12px', fontSize: 11 }}
                  >
                    Pay Invoice
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Payment History Table */}
      <div className="panel" style={{ padding: '0', overflow: 'hidden' }}>
        <div style={{ padding: '14px 18px', borderBottom: '1px solid #23252a' }}>
          <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8' }}>
            Reconciled Invoices ({payments.length})
          </h2>
        </div>

        {payments.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px 16px', color: '#62666d', fontSize: 12 }}>
            No payment history recorded yet.
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Timestamp</th>
                  <th>Station</th>
                  <th>Amount</th>
                  <th>Delivered</th>
                  <th>Channel</th>
                  <th>Reference</th>
                  <th>Status</th>
                  <th>Receipt</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((p) => (
                  <tr key={p.id}>
                    <td style={{ color: '#8a8f98', fontFamily: 'monospace', whiteSpace: 'nowrap' }}>
                      {new Date(p.paymentDate || p.createdAt).toLocaleDateString()}
                    </td>
                    <td style={{ fontWeight: 500, color: '#f7f8f8' }}>
                      {p.session?.reservation?.station?.stationName || 'Charging Station'}
                    </td>
                    <td style={{ fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                      ₹{p.amount?.toFixed(2)}
                    </td>
                    <td style={{ fontFamily: 'monospace' }}>
                      {p.session?.energyConsumedKwh ? `${p.session.energyConsumedKwh.toFixed(1)} kWh` : '—'}
                    </td>
                    <td>
                      <span className="badge badge-completed">{p.paymentMethod}</span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ fontSize: 11, fontFamily: 'monospace', color: '#8a8f98' }}>
                          {p.transactionReference}
                        </span>
                        <button
                          onClick={() => copyToClipboard(p.transactionReference, p.id)}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#62666d', padding: 1 }}
                          title="Copy reference"
                        >
                          {copiedId === p.id ? <Check size={12} color="#27a644" /> : <Copy size={12} />}
                        </button>
                      </div>
                    </td>
                    <td>
                      <span className="badge badge-confirmed">Settled</span>
                    </td>
                    <td>
                      <button
                        onClick={() => setSelectedReceipt(p)}
                        className="btn-secondary"
                        style={{ padding: '3px 8px', fontSize: 11 }}
                      >
                        Receipt
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pay Modal */}
      {payModalSession && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 100,
            background: 'rgba(0,0,0,0.75)',
            backdropFilter: 'blur(4px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 20,
          }}
        >
          <div
            style={{
              width: '100%',
              maxWidth: 400,
              padding: 24,
              background: '#0f1011',
              border: '1px solid #23252a',
              borderRadius: 8,
              boxShadow: '0 24px 64px rgba(0,0,0,0.8)',
              position: 'relative',
            }}
          >
            <button
              onClick={() => setPayModalSession(null)}
              aria-label="Close"
              style={{
                position: 'absolute',
                right: 16,
                top: 16,
                background: 'none',
                border: 'none',
                color: '#62666d',
                cursor: 'pointer',
              }}
            >
              <X size={16} />
            </button>

            <h3 style={{ fontSize: 16, fontWeight: 600, color: '#f7f8f8', marginBottom: 2 }}>
              Settle Invoice
            </h3>
            <p style={{ fontSize: 12, color: '#8a8f98', marginBottom: 16 }}>
              {payModalSession.reservation?.station?.stationName || 'Charging Station'}
            </p>

            {paySuccess ? (
              <div style={{ padding: '20px 0', textAlign: 'center' }}>
                <CheckCircle size={36} color="#27a644" style={{ margin: '0 auto 10px' }} />
                <h4 style={{ color: '#f7f8f8', fontSize: 15, fontWeight: 600, marginBottom: 2 }}>
                  Payment Reconciled
                </h4>
                <p style={{ color: '#27a644', fontSize: 12 }}>Digital receipt dispatched to host ledger</p>
              </div>
            ) : (
              <form onSubmit={handlePay}>
                <div
                  style={{
                    padding: 14,
                    borderRadius: 6,
                    background: '#141516',
                    border: '1px solid #23252a',
                    marginBottom: 16,
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 12, color: '#8a8f98' }}>
                    <span>Energy Consumed</span>
                    <span style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>
                      {payModalSession.energyConsumedKwh?.toFixed(2)} kWh
                    </span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 12, color: '#8a8f98' }}>
                    <span>Rate / kWh</span>
                    <span style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>
                      ₹{payModalSession.reservation?.station?.pricePerKwh || '—'}
                    </span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 6, borderTop: '1px solid #23252a', fontSize: 14, fontWeight: 600 }}>
                    <span style={{ color: '#f7f8f8' }}>Total Due</span>
                    <span style={{ color: '#27a644', fontFamily: 'monospace' }}>
                      ₹{payModalSession.totalAmount?.toFixed(2)}
                    </span>
                  </div>
                </div>

                <div style={{ marginBottom: 18 }}>
                  <label className="form-label">Payment Channel</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
                    {['UPI', 'CARD', 'WALLET'].map((m) => {
                      const active = paymentMethod === m;
                      return (
                        <button
                          key={m}
                          type="button"
                          onClick={() => setPaymentMethod(m)}
                          style={{
                            padding: '8px 6px',
                            borderRadius: 4,
                            fontSize: 11,
                            fontWeight: 500,
                            cursor: 'pointer',
                            border: active ? '1px solid #5e6ad2' : '1px solid #23252a',
                            background: active ? '#191a1b' : '#141516',
                            color: active ? '#f7f8f8' : '#8a8f98',
                          }}
                        >
                          {m}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
                  <button
                    type="button"
                    onClick={() => setPayModalSession(null)}
                    className="btn-secondary"
                    style={{ flex: 1, padding: '7px 14px' }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="btn-primary"
                    disabled={paying}
                    style={{ flex: 1.5, padding: '7px 14px' }}
                  >
                    {paying ? 'Processing...' : `Pay ₹${payModalSession.totalAmount?.toFixed(2)}`}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Receipt View Modal */}
      {selectedReceipt && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 100,
            background: 'rgba(0,0,0,0.75)',
            backdropFilter: 'blur(4px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 20,
          }}
        >
          <div
            style={{
              width: '100%',
              maxWidth: 420,
              padding: 24,
              background: '#0f1011',
              border: '1px solid #23252a',
              borderRadius: 8,
              boxShadow: '0 24px 64px rgba(0,0,0,0.8)',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <div>
                <div style={{ fontSize: 10, textTransform: 'uppercase', color: '#5e6ad2', fontWeight: 600, letterSpacing: '0.04em' }}>
                  Electronic Tax Receipt
                </div>
                <h3 style={{ fontSize: 16, fontWeight: 600, color: '#f7f8f8', marginTop: 2 }}>
                  ChargeShare Settlement
                </h3>
              </div>
              <span className="badge badge-confirmed">Settled</span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: 12, color: '#8a8f98', marginBottom: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Date:</span>
                <span style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>
                  {new Date(selectedReceipt.paymentDate || selectedReceipt.createdAt).toLocaleString()}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Reference:</span>
                <span style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>
                  {selectedReceipt.transactionReference}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Station:</span>
                <span style={{ color: '#f7f8f8' }}>
                  {selectedReceipt.session?.reservation?.station?.stationName}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Host:</span>
                <span style={{ color: '#f7f8f8' }}>
                  {selectedReceipt.receiver?.fullName || 'Station Host'}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Energy Dispensed:</span>
                <span style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>
                  {selectedReceipt.session?.energyConsumedKwh?.toFixed(2)} kWh
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Payment Channel:</span>
                <span style={{ color: '#f7f8f8' }}>{selectedReceipt.paymentMethod}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 8, borderTop: '1px solid #23252a', fontSize: 14, fontWeight: 600 }}>
                <span style={{ color: '#f7f8f8' }}>Total Settled:</span>
                <span style={{ color: '#27a644', fontFamily: 'monospace' }}>
                  ₹{selectedReceipt.amount?.toFixed(2)}
                </span>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <button
                type="button"
                onClick={() => setSelectedReceipt(null)}
                className="btn-secondary"
                style={{ padding: '6px 14px', fontSize: 12 }}
              >
                Close Receipt
              </button>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
