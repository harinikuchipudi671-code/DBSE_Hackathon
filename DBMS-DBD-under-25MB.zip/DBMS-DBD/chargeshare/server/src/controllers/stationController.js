const prisma = require('../config/database');

// POST /api/stations
const createStation = async (req, res) => {
  try {
    const {
      stationName, description, completeAddress, latitude, longitude,
      chargerType, connectorType, chargingCapacityKw, pricePerKwh, amenities
    } = req.body;

    if (!stationName || !completeAddress || !latitude || !longitude || !chargerType || !connectorType || !chargingCapacityKw || !pricePerKwh) {
      return res.status(400).json({ success: false, message: 'Missing required fields' });
    }

    const station = await prisma.chargingStation.create({
      data: {
        homeownerId: req.user.id,
        stationName,
        description,
        completeAddress,
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude),
        chargerType,
        connectorType,
        chargingCapacityKw: parseFloat(chargingCapacityKw),
        pricePerKwh: parseFloat(pricePerKwh),
        amenities: amenities ? JSON.stringify(amenities) : null,
      }
    });
    res.status(201).json({ success: true, message: 'Charging station created', data: station });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/stations - get all active stations (EV owner discovery)
const getAllStations = async (req, res) => {
  try {
    const { connectorType, chargerType, maxPrice, isActive } = req.query;
    const where = { verificationStatus: { not: 'SUSPENDED' } };

    if (isActive !== 'false') where.isActive = true;
    if (connectorType && connectorType !== 'ALL') where.connectorType = connectorType;
    if (chargerType && chargerType !== 'ALL') where.chargerType = chargerType;
    if (maxPrice) where.pricePerKwh = { lte: parseFloat(maxPrice) };

    const stations = await prisma.chargingStation.findMany({
      where,
      include: {
        homeowner: { select: { id: true, fullName: true, profileImage: true } },
        reviews: { select: { rating: true } },
        _count: { select: { reservations: true } }
      },
      orderBy: { createdAt: 'desc' }
    });

    const mapped = stations.map(s => ({
      ...s,
      amenities: s.amenities ? JSON.parse(s.amenities) : [],
      images: s.images ? JSON.parse(s.images) : [],
      avgRating: s.reviews.length ? (s.reviews.reduce((a, r) => a + r.rating, 0) / s.reviews.length).toFixed(1) : null,
      reviewCount: s.reviews.length
    }));

    res.json({ success: true, data: mapped });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/stations/nearby
const getNearbyStations = async (req, res) => {
  try {
    const { lat, lng, radius = 50 } = req.query;
    if (!lat || !lng) {
      return res.status(400).json({ success: false, message: 'lat and lng are required' });
    }

    const userLat = parseFloat(lat);
    const userLng = parseFloat(lng);
    const radiusKm = parseFloat(radius);

    const stations = await prisma.chargingStation.findMany({
      where: { isActive: true, verificationStatus: { not: 'SUSPENDED' } },
      include: {
        homeowner: { select: { id: true, fullName: true, profileImage: true } },
        reviews: { select: { rating: true } }
      }
    });

    // Haversine distance calculation
    const nearby = stations.map(s => {
      const R = 6371;
      const dLat = ((s.latitude - userLat) * Math.PI) / 180;
      const dLng = ((s.longitude - userLng) * Math.PI) / 180;
      const a = Math.sin(dLat / 2) ** 2 +
        Math.cos((userLat * Math.PI) / 180) * Math.cos((s.latitude * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
      const distance = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      return {
        ...s,
        amenities: s.amenities ? JSON.parse(s.amenities) : [],
        images: s.images ? JSON.parse(s.images) : [],
        distance: parseFloat(distance.toFixed(2)),
        avgRating: s.reviews.length ? (s.reviews.reduce((a, r) => a + r.rating, 0) / s.reviews.length).toFixed(1) : null,
        reviewCount: s.reviews.length
      };
    }).filter(s => s.distance <= radiusKm).sort((a, b) => a.distance - b.distance);

    res.json({ success: true, data: nearby });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/stations/:id
const getStationById = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const station = await prisma.chargingStation.findUnique({
      where: { id },
      include: {
        homeowner: { select: { id: true, fullName: true, profileImage: true, phoneNumber: true } },
        availabilitySlots: { where: { slotStatus: 'AVAILABLE' }, orderBy: [{ availableDate: 'asc' }, { startTime: 'asc' }] },
        reviews: {
          include: { reviewer: { select: { fullName: true, profileImage: true } } },
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!station) return res.status(404).json({ success: false, message: 'Station not found' });

    const result = {
      ...station,
      amenities: station.amenities ? JSON.parse(station.amenities) : [],
      images: station.images ? JSON.parse(station.images) : [],
      avgRating: station.reviews.length ? (station.reviews.reduce((a, r) => a + r.rating, 0) / station.reviews.length).toFixed(1) : null,
      reviewCount: station.reviews.length
    };

    res.json({ success: true, data: result });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// GET /api/stations/my - homeowner's own stations
const getMyStations = async (req, res) => {
  try {
    const stations = await prisma.chargingStation.findMany({
      where: { homeownerId: req.user.id },
      include: {
        _count: { select: { reservations: true, availabilitySlots: true } },
        reviews: { select: { rating: true } },
        reservations: {
          where: { bookingStatus: { in: ['PENDING', 'CONFIRMED'] } },
          include: {
            evOwner: { select: { fullName: true, email: true } },
            slot: true
          },
          orderBy: { bookingDate: 'asc' }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    const mapped = stations.map(s => ({
      ...s,
      amenities: s.amenities ? JSON.parse(s.amenities) : [],
      images: s.images ? JSON.parse(s.images) : [],
      avgRating: s.reviews.length ? (s.reviews.reduce((a, r) => a + r.rating, 0) / s.reviews.length).toFixed(1) : null
    }));

    res.json({ success: true, data: mapped });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// PUT /api/stations/:id
const updateStation = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const station = await prisma.chargingStation.findUnique({ where: { id } });
    if (!station) return res.status(404).json({ success: false, message: 'Station not found' });
    if (station.homeownerId !== req.user.id) return res.status(403).json({ success: false, message: 'Not authorized' });

    const {
      stationName, description, completeAddress, latitude, longitude,
      chargerType, connectorType, chargingCapacityKw, pricePerKwh, amenities, isActive
    } = req.body;

    const updated = await prisma.chargingStation.update({
      where: { id },
      data: {
        stationName, description, completeAddress,
        latitude: latitude ? parseFloat(latitude) : undefined,
        longitude: longitude ? parseFloat(longitude) : undefined,
        chargerType, connectorType,
        chargingCapacityKw: chargingCapacityKw ? parseFloat(chargingCapacityKw) : undefined,
        pricePerKwh: pricePerKwh ? parseFloat(pricePerKwh) : undefined,
        amenities: amenities ? JSON.stringify(amenities) : undefined,
        isActive: isActive !== undefined ? isActive : undefined
      }
    });
    res.json({ success: true, message: 'Station updated', data: updated });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// DELETE /api/stations/:id
const deleteStation = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const station = await prisma.chargingStation.findUnique({ where: { id } });
    if (!station) return res.status(404).json({ success: false, message: 'Station not found' });
    if (station.homeownerId !== req.user.id && req.user.role !== 'ADMIN') {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    await prisma.chargingStation.delete({ where: { id } });
    res.json({ success: true, message: 'Station deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { createStation, getAllStations, getNearbyStations, getStationById, getMyStations, updateStation, deleteStation };
