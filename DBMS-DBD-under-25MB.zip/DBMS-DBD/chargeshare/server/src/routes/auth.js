const express = require('express');
const router = express.Router();
const { register, login, getMe, updateProfile, upsertEvProfile } = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');

router.post('/register', register);
router.post('/login', login);
router.get('/me', authenticate, getMe);
router.put('/profile', authenticate, updateProfile);
router.post('/ev-profile', authenticate, upsertEvProfile);

module.exports = router;
