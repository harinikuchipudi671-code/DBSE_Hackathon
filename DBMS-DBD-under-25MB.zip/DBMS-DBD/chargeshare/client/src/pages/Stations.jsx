import { useState, useEffect } from 'react';
import { Plus, Edit3, Trash2, Power, Calendar, Star, ChevronDown, ChevronUp, X, Check, MapPin } from 'lucide-react';
import DashboardLayout from '../layouts/DashboardLayout';
import api from '../services/api';

const CONNECTOR_TYPES = ['CCS', 'CHAdeMO', 'Type2', 'J1772', 'Multiple'];
const CHARGER_TYPES = ['Level1', 'Level2', 'DC_Fast'];
const AMENITIES_LIST = ['WiFi', 'Covered Parking', 'Restroom', 'Water', 'Snacks', 'Tea/Coffee', 'Security Camera', 'Waiting Area'];

const defaultForm = {
  stationName: '',
  description: '',
  completeAddress: '',
  latitude: '',
  longitude: '',
  chargerType: 'Level2',
  connectorType: 'CCS',
  chargingCapacityKw: '',
  pricePerKwh: '',
  amenities: [],
};

export default function Stations() {
  const [stations, setStations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(defaultForm);
  const [formLoading, setFormLoading] = useState(false);
  const [error, setError] = useState('');
  const [expandedId, setExpandedId] = useState(null);

  // Slot management
  const [showSlotForm, setShowSlotForm] = useState(null);
  const [slots, setSlots] = useState({});
  const [slotForm, setSlotForm] = useState({ availableDate: '', startTime: '', endTime: '' });

  const fetchStations = async () => {
    try {
      const res = await api.get('/stations/my');
      setStations(res.data?.data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStations();
  }, []);

  const fetchSlots = async (stationId) => {
    try {
      const res = await api.get(`/slots/${stationId}`);
      setSlots((prev) => ({ ...prev, [stationId]: res.data?.data || [] }));
    } catch (e) {}
  };

  const toggleExpand = (id) => {
    if (expandedId === id) {
      setExpandedId(null);
    } else {
      setExpandedId(id);
      fetchSlots(id);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setFormLoading(true);
    try {
      const data = {
        ...form,
        chargingCapacityKw: parseFloat(form.chargingCapacityKw),
        pricePerKwh: parseFloat(form.pricePerKwh),
        latitude: parseFloat(form.latitude),
        longitude: parseFloat(form.longitude),
      };
      if (editingId) {
        await api.put(`/stations/${editingId}`, data);
      } else {
        await api.post('/stations', data);
      }
      setShowForm(false);
      setEditingId(null);
      setForm(defaultForm);
      fetchStations();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save station');
    } finally {
      setFormLoading(false);
    }
  };

  const toggleAmenity = (a) =>
    setForm((f) => ({
      ...f,
      amenities: f.amenities.includes(a) ? f.amenities.filter((x) => x !== a) : [...f.amenities, a],
    }));

  const handleEdit = (s) => {
    setForm({
      stationName: s.stationName,
      description: s.description || '',
      completeAddress: s.completeAddress,
      latitude: s.latitude,
      longitude: s.longitude,
      chargerType: s.chargerType,
      connectorType: s.connectorType,
      chargingCapacityKw: s.chargingCapacityKw,
      pricePerKwh: s.pricePerKwh,
      amenities: Array.isArray(s.amenities) ? s.amenities : [],
    });
    setEditingId(s.id);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to remove this station?')) return;
    try {
      await api.delete(`/stations/${id}`);
      fetchStations();
    } catch (err) {
      alert(err.response?.data?.message || 'Delete failed');
    }
  };

  const handleToggleActive = async (s) => {
    try {
      await api.put(`/stations/${s.id}`, { isActive: !s.isActive });
      fetchStations();
    } catch (err) {
      alert('Failed to update status');
    }
  };

  const handleAddSlot = async (stationId) => {
    try {
      await api.post('/slots', { stationId, ...slotForm });
      setSlotForm({ availableDate: '', startTime: '', endTime: '' });
      setShowSlotForm(null);
      fetchSlots(stationId);
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to add slot');
    }
  };

  const handleDeleteSlot = async (slotId, stationId) => {
    try {
      await api.delete(`/slots/${slotId}`);
      fetchSlots(stationId);
    } catch (err) {
      alert(err.response?.data?.message || 'Cannot delete slot');
    }
  };

  const getLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        setForm((f) => ({
          ...f,
          latitude: pos.coords.latitude.toFixed(6),
          longitude: pos.coords.longitude.toFixed(6),
        }));
      });
    }
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 300 }}>
          <div className="spinner" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
            My Charging Stations
          </h1>
          <p style={{ color: '#8a8f98', fontSize: 13 }}>
            {stations.length} hardware {stations.length === 1 ? 'node' : 'nodes'} deployed
          </p>
        </div>
        <button
          onClick={() => {
            setShowForm(true);
            setEditingId(null);
            setForm(defaultForm);
          }}
          className="btn-primary"
          style={{ padding: '7px 14px', fontSize: 13 }}
        >
          <Plus size={14} /> Register Station
        </button>
      </div>

      {/* Station Form Modal */}
      {showForm && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0, 0, 0, 0.75)',
            backdropFilter: 'blur(4px)',
            zIndex: 200,
            display: 'flex',
            alignItems: 'flex-start',
            justifyContent: 'center',
            padding: '40px 20px',
            overflowY: 'auto',
          }}
        >
          <div
            style={{
              background: '#0f1011',
              border: '1px solid #23252a',
              borderRadius: 8,
              padding: '24px',
              width: '100%',
              maxWidth: 560,
              position: 'relative',
              boxShadow: '0 24px 64px rgba(0,0,0,0.8)',
            }}
          >
            <button
              onClick={() => setShowForm(false)}
              aria-label="Close dialog"
              style={{
                position: 'absolute',
                top: 16,
                right: 16,
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                color: '#62666d',
              }}
            >
              <X size={16} />
            </button>

            <h2 style={{ fontSize: 16, fontWeight: 600, color: '#f7f8f8', marginBottom: 16 }}>
              {editingId ? 'Edit Charging Station' : 'Register New Station'}
            </h2>

            {error && (
              <div
                style={{
                  padding: '8px 12px',
                  borderRadius: 6,
                  background: 'rgba(235, 87, 87, 0.1)',
                  border: '1px solid rgba(235, 87, 87, 0.25)',
                  color: '#f87171',
                  fontSize: 12,
                  marginBottom: 14,
                }}
              >
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <div style={{ gridColumn: '1/-1' }}>
                  <label className="form-label">Station Name *</label>
                  <input
                    className="form-input"
                    placeholder="e.g. Bandra GreenPort Dock 1"
                    value={form.stationName}
                    onChange={(e) => setForm((f) => ({ ...f, stationName: e.target.value }))}
                    required
                  />
                </div>

                <div style={{ gridColumn: '1/-1' }}>
                  <label className="form-label">Physical Address *</label>
                  <input
                    className="form-input"
                    placeholder="Full street address and landmark"
                    value={form.completeAddress}
                    onChange={(e) => setForm((f) => ({ ...f, completeAddress: e.target.value }))}
                    required
                  />
                </div>

                <div>
                  <label className="form-label">Latitude *</label>
                  <input
                    className="form-input"
                    type="number"
                    step="any"
                    placeholder="19.0760"
                    value={form.latitude}
                    onChange={(e) => setForm((f) => ({ ...f, latitude: e.target.value }))}
                    required
                  />
                </div>

                <div>
                  <label className="form-label">Longitude *</label>
                  <input
                    className="form-input"
                    type="number"
                    step="any"
                    placeholder="72.8777"
                    value={form.longitude}
                    onChange={(e) => setForm((f) => ({ ...f, longitude: e.target.value }))}
                    required
                  />
                </div>

                <div style={{ gridColumn: '1/-1', textAlign: 'right', marginTop: -6 }}>
                  <button
                    type="button"
                    onClick={getLocation}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: '#5e6ad2',
                      fontSize: 11,
                      cursor: 'pointer',
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 4,
                    }}
                  >
                    <MapPin size={11} /> Use Device Coordinates
                  </button>
                </div>

                <div>
                  <label className="form-label">Hardware Tier *</label>
                  <select
                    className="form-input"
                    value={form.chargerType}
                    onChange={(e) => setForm((f) => ({ ...f, chargerType: e.target.value }))}
                  >
                    {CHARGER_TYPES.map((t) => (
                      <option key={t} value={t}>
                        {t.replace('_', ' ')}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="form-label">Connector Standard *</label>
                  <select
                    className="form-input"
                    value={form.connectorType}
                    onChange={(e) => setForm((f) => ({ ...f, connectorType: e.target.value }))}
                  >
                    {CONNECTOR_TYPES.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="form-label">Output Capacity (kW) *</label>
                  <input
                    className="form-input"
                    type="number"
                    step="0.1"
                    min="0.1"
                    placeholder="7.4"
                    value={form.chargingCapacityKw}
                    onChange={(e) => setForm((f) => ({ ...f, chargingCapacityKw: e.target.value }))}
                    required
                  />
                </div>

                <div>
                  <label className="form-label">Price per kWh (₹) *</label>
                  <input
                    className="form-input"
                    type="number"
                    step="0.1"
                    min="0.1"
                    placeholder="18.50"
                    value={form.pricePerKwh}
                    onChange={(e) => setForm((f) => ({ ...f, pricePerKwh: e.target.value }))}
                    required
                  />
                </div>

                <div style={{ gridColumn: '1/-1' }}>
                  <label className="form-label">Station Description</label>
                  <textarea
                    className="form-input"
                    rows={2}
                    placeholder="Parking instructions, gate codes, or access details..."
                    value={form.description}
                    onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                    style={{ resize: 'vertical' }}
                  />
                </div>

                <div style={{ gridColumn: '1/-1' }}>
                  <label className="form-label">Amenities</label>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 4 }}>
                    {AMENITIES_LIST.map((a) => {
                      const active = form.amenities.includes(a);
                      return (
                        <button
                          type="button"
                          key={a}
                          onClick={() => toggleAmenity(a)}
                          style={{
                            padding: '4px 10px',
                            borderRadius: 4,
                            fontSize: 11,
                            cursor: 'pointer',
                            transition: 'all 0.15s ease',
                            background: active ? '#191a1b' : '#141516',
                            border: active ? '1px solid #5e6ad2' : '1px solid #23252a',
                            color: active ? '#f7f8f8' : '#8a8f98',
                          }}
                        >
                          {a}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="btn-secondary"
                  style={{ flex: 1, padding: '8px 14px' }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formLoading}
                  className="btn-primary"
                  style={{ flex: 1.5, padding: '8px 14px' }}
                >
                  {formLoading ? 'Saving...' : editingId ? 'Update Station' : 'Deploy Station'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Stations List */}
      {stations.length === 0 ? (
        <div className="panel" style={{ textAlign: 'center', padding: '60px 20px' }}>
          <Zap size={32} color="#3e3e44" style={{ margin: '0 auto 12px' }} />
          <p style={{ color: '#8a8f98', fontSize: 13, marginBottom: 16 }}>
            No charging stations registered on your account
          </p>
          <button
            onClick={() => setShowForm(true)}
            className="btn-primary"
            style={{ padding: '7px 16px', fontSize: 13 }}
          >
            Deploy First Station
          </button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {stations.map((s) => (
            <div key={s.id} className="panel" style={{ overflow: 'hidden' }}>
              <div
                style={{
                  padding: '16px 20px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer',
                }}
                onClick={() => toggleExpand(s.id)}
              >
                <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
                  <div
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: 6,
                      background: '#141516',
                      border: '1px solid #23252a',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: s.isActive ? '#27a644' : '#62666d',
                    }}
                  >
                    <Power size={16} />
                  </div>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 500, color: '#f7f8f8', marginBottom: 2 }}>
                      {s.stationName}
                    </div>
                    <div style={{ fontSize: 12, color: '#8a8f98' }}>
                      {s.chargerType} · {s.connectorType} · {s.chargingCapacityKw} kW ·{' '}
                      <span style={{ color: '#d0d6e0', fontFamily: 'monospace' }}>₹{s.pricePerKwh}/kWh</span>
                    </div>
                    <div style={{ fontSize: 11, color: '#62666d', marginTop: 2 }}>{s.completeAddress}</div>
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  {s.avgRating && (
                    <span style={{ fontSize: 12, color: '#f59e0b', display: 'flex', alignItems: 'center', gap: 3 }}>
                      <Star size={12} fill="#f59e0b" /> {s.avgRating} ({s.reviewCount})
                    </span>
                  )}
                  <span className={s.isActive ? 'badge badge-confirmed' : 'badge badge-cancelled'}>
                    {s.isActive ? 'Online' : 'Paused'}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleActive(s);
                    }}
                    className="btn-secondary"
                    style={{ padding: '4px 10px', fontSize: 11 }}
                  >
                    {s.isActive ? 'Pause' : 'Activate'}
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEdit(s);
                    }}
                    className="btn-secondary"
                    style={{ padding: '5px 8px' }}
                    title="Edit station"
                  >
                    <Edit3 size={13} />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(s.id);
                    }}
                    className="btn-danger"
                    style={{ padding: '5px 8px' }}
                    title="Delete station"
                  >
                    <Trash2 size={13} />
                  </button>
                  <span style={{ color: '#62666d' }}>
                    {expandedId === s.id ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </span>
                </div>
              </div>

              {/* Slot Management Drawer */}
              {expandedId === s.id && (
                <div style={{ padding: '16px 20px 20px', borderTop: '1px solid #23252a', background: '#090a0b' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                    <div>
                      <h3 style={{ fontSize: 12, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.01em' }}>
                        Configured Availability Windows
                      </h3>
                      <p style={{ fontSize: 11, color: '#8a8f98' }}>Drivers can only reserve slots created here</p>
                    </div>
                    <button
                      onClick={() => setShowSlotForm(showSlotForm === s.id ? null : s.id)}
                      className="btn-secondary"
                      style={{ fontSize: 11, padding: '4px 10px' }}
                    >
                      <Calendar size={12} /> Add Window
                    </button>
                  </div>

                  {showSlotForm === s.id && (
                    <div
                      style={{
                        padding: 12,
                        borderRadius: 6,
                        background: '#141516',
                        border: '1px solid #23252a',
                        marginBottom: 12,
                        display: 'flex',
                        gap: 10,
                        alignItems: 'flex-end',
                        flexWrap: 'wrap',
                      }}
                    >
                      <div>
                        <label className="form-label">Date</label>
                        <input
                          className="form-input"
                          type="date"
                          value={slotForm.availableDate}
                          onChange={(e) => setSlotForm((f) => ({ ...f, availableDate: e.target.value }))}
                          style={{ width: 140, padding: '6px 8px', fontSize: 12 }}
                          min={new Date().toISOString().split('T')[0]}
                        />
                      </div>
                      <div>
                        <label className="form-label">Start Time</label>
                        <input
                          className="form-input"
                          type="time"
                          value={slotForm.startTime}
                          onChange={(e) => setSlotForm((f) => ({ ...f, startTime: e.target.value }))}
                          style={{ width: 110, padding: '6px 8px', fontSize: 12 }}
                        />
                      </div>
                      <div>
                        <label className="form-label">End Time</label>
                        <input
                          className="form-input"
                          type="time"
                          value={slotForm.endTime}
                          onChange={(e) => setSlotForm((f) => ({ ...f, endTime: e.target.value }))}
                          style={{ width: 110, padding: '6px 8px', fontSize: 12 }}
                        />
                      </div>
                      <button
                        onClick={() => handleAddSlot(s.id)}
                        className="btn-primary"
                        style={{ fontSize: 12, padding: '6px 14px' }}
                      >
                        <Check size={12} /> Save Slot
                      </button>
                    </div>
                  )}

                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                    {(slots[s.id] || []).length === 0 ? (
                      <p style={{ fontSize: 12, color: '#62666d' }}>
                        No availability windows defined. Add available slots for drivers.
                      </p>
                    ) : (
                      (slots[s.id] || []).map((slot) => (
                        <div
                          key={slot.id}
                          style={{
                            padding: '6px 10px',
                            borderRadius: 4,
                            fontSize: 11,
                            display: 'flex',
                            alignItems: 'center',
                            gap: 8,
                            background: '#141516',
                            border: '1px solid #23252a',
                            color: slot.slotStatus === 'AVAILABLE' ? '#34d399' : '#8a8f98',
                          }}
                        >
                          <span style={{ fontFamily: 'monospace' }}>
                            {slot.availableDate} {slot.startTime}–{slot.endTime}
                          </span>
                          <span className={slot.slotStatus === 'AVAILABLE' ? 'badge badge-confirmed' : 'badge badge-pending'}>
                            {slot.slotStatus}
                          </span>
                          {slot.slotStatus === 'AVAILABLE' && (
                            <button
                              onClick={() => handleDeleteSlot(slot.id, s.id)}
                              style={{
                                background: 'none',
                                border: 'none',
                                cursor: 'pointer',
                                color: '#62666d',
                                display: 'flex',
                                padding: 0,
                              }}
                              title="Delete slot"
                            >
                              <X size={12} />
                            </button>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
