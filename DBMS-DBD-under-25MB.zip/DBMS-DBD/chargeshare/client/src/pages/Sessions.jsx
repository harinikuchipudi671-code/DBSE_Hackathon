import { useState, useEffect } from 'react';
import {
  Zap, BatteryCharging, Play, Square, CreditCard, RefreshCw, X
} from 'lucide-react';
import DashboardLayout from '../layouts/DashboardLayout';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function Sessions() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [sessions, setSessions] = useState([]);
  const [confirmedReservations, setConfirmedReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeSession, setActiveSession] = useState(null);

  // Homeowner session control states
  const [selectedResId, setSelectedResId] = useState('');
  const [startingSession, setStartingSession] = useState(false);
  const [completeModalOpen, setCompleteModalOpen] = useState(false);
  const [completingSessionId, setCompletingSessionId] = useState(null);
  const [finalKwh, setFinalKwh] = useState(24.5);
  const [completing, setCompleting] = useState(false);

  // EV Owner payment modal state
  const [payModalOpen, setPayModalOpen] = useState(false);
  const [payingSession, setPayingSession] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('UPI');
  const [submittingPayment, setSubmittingPayment] = useState(false);

  // Live simulation tick state for active session
  const [simulatedKwh, setSimulatedKwh] = useState(12.4);
  const [simulatedMinutes, setSimulatedMinutes] = useState(45);
  const [batteryPercent, setBatteryPercent] = useState(58);

  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    fetchData();
  }, [user]);

  // Real-time animation timer for active session
  useEffect(() => {
    if (!activeSession) return;
    const interval = setInterval(() => {
      setSimulatedMinutes((prev) => prev + 1);
      setSimulatedKwh((prev) => +(prev + 0.12).toFixed(2));
      setBatteryPercent((prev) => (prev < 99 ? prev + 1 : 99));
    }, 4000);
    return () => clearInterval(interval);
  }, [activeSession]);

  const fetchData = async () => {
    try {
      setLoading(true);
      setErrorMsg('');
      const res = await api.get('/sessions/history');
      const sessionList = res.data?.data || res.data || [];
      setSessions(sessionList);

      const currentActive = sessionList.find((s) => s.sessionStatus === 'ACTIVE');
      setActiveSession(currentActive || null);

      if (user?.role === 'HOMEOWNER') {
        const resResp = await api.get('/reservations/received');
        const allRes = resResp.data?.data || resResp.data || [];
        const readyToStart = allRes.filter((r) => r.status === 'CONFIRMED' || r.bookingStatus === 'CONFIRMED');
        setConfirmedReservations(readyToStart);
        if (readyToStart.length > 0) {
          setSelectedResId(readyToStart[0].id);
        }
      }
    } catch (err) {
      console.error('Error fetching sessions:', err);
      setErrorMsg('Failed to load charging sessions.');
    } finally {
      setLoading(false);
    }
  };

  // Homeowner: Start Session
  const handleStartSession = async (e) => {
    e.preventDefault();
    if (!selectedResId) return;
    try {
      setStartingSession(true);
      setErrorMsg('');
      await api.post('/sessions/start', { reservationId: selectedResId });
      setSuccessMsg('Charging session initiated.');
      fetchData();
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Failed to start charging session.');
    } finally {
      setStartingSession(false);
    }
  };

  // Homeowner: Complete Session
  const handleCompleteSession = async (e) => {
    e.preventDefault();
    if (!completingSessionId) return;
    try {
      setCompleting(true);
      await api.patch(`/sessions/${completingSessionId}/complete`, {
        energyConsumedKwh: Number(finalKwh),
      });
      setSuccessMsg('Session concluded. Invoice generated.');
      setCompleteModalOpen(false);
      fetchData();
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Failed to complete session.');
    } finally {
      setCompleting(false);
    }
  };

  // EV Owner: Pay for completed session
  const handlePaySession = async (e) => {
    e.preventDefault();
    if (!payingSession) return;
    try {
      setSubmittingPayment(true);
      await api.post('/payments', {
        sessionId: payingSession.id,
        paymentMethod,
      });
      setSuccessMsg(`Payment of ₹${payingSession.totalAmount || 0} completed successfully!`);
      setPayModalOpen(false);
      fetchData();
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Payment processing failed.');
    } finally {
      setSubmittingPayment(false);
    }
  };

  const activeRate = activeSession?.pricePerKwh || activeSession?.reservation?.station?.pricePerKwh || 18;
  const liveCost = (simulatedKwh * activeRate).toFixed(2);

  return (
    <DashboardLayout>
      <div style={{ paddingBottom: 40 }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 16, marginBottom: 20 }}>
          <div>
            <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
              Charging Sessions
            </h1>
            <p style={{ color: '#8a8f98', fontSize: 13 }}>
              Real-time hardware telemetry, session control, and billing records
            </p>
          </div>

          <button
            onClick={fetchData}
            className="btn-secondary"
            style={{ padding: '6px 12px', fontSize: 12 }}
          >
            <RefreshCw size={13} /> Refresh
          </button>
        </div>

        {/* Feedback alerts */}
        {errorMsg && (
          <div
            style={{
              background: 'rgba(235, 87, 87, 0.1)',
              border: '1px solid rgba(235, 87, 87, 0.25)',
              color: '#f87171',
              padding: '10px 14px',
              borderRadius: 6,
              marginBottom: 16,
              fontSize: 12,
            }}
          >
            {errorMsg}
          </div>
        )}
        {successMsg && (
          <div
            style={{
              background: 'rgba(39, 166, 68, 0.1)',
              border: '1px solid rgba(39, 166, 68, 0.25)',
              color: '#34d399',
              padding: '10px 14px',
              borderRadius: 6,
              marginBottom: 16,
              fontSize: 12,
            }}
          >
            {successMsg}
          </div>
        )}

        {/* ACTIVE CHARGING SESSION CARD */}
        {activeSession ? (
          <div
            className="panel"
            style={{
              padding: '24px',
              marginBottom: 24,
              border: '1px solid #27a644',
              background: '#0f1011',
              boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 16, marginBottom: 20 }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                  <span className="badge badge-active">Live Telemetry</span>
                  <span style={{ fontSize: 11, color: '#62666d', fontFamily: 'monospace' }}>
                    Session #{activeSession.id}
                  </span>
                </div>
                <h2 style={{ fontSize: 18, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.01em' }}>
                  {activeSession.reservation?.station?.stationName || activeSession.reservation?.station?.name || 'Active Station'}
                </h2>
                <p style={{ color: '#8a8f98', fontSize: 12, marginTop: 2 }}>
                  Vehicle: <span style={{ color: '#f7f8f8' }}>{activeSession.reservation?.vehicleModel || 'Electric Vehicle'}</span> ({activeSession.reservation?.licensePlate || 'MH 02 AB 1234'})
                </p>
              </div>

              {/* Stop Session Button for Homeowner */}
              {user?.role === 'HOMEOWNER' && (
                <button
                  onClick={() => {
                    setCompletingSessionId(activeSession.id);
                    setFinalKwh(simulatedKwh);
                    setCompleteModalOpen(true);
                  }}
                  className="btn-danger"
                  style={{ padding: '8px 16px', fontSize: 12 }}
                >
                  <Square size={13} fill="currentColor" /> Stop & Bill Session
                </button>
              )}
            </div>

            {/* Battery Level Progress Bar */}
            <div style={{ marginBottom: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 6 }}>
                <span style={{ color: '#8a8f98', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <BatteryCharging size={14} color="#27a644" /> State of Charge (SoC)
                </span>
                <span style={{ color: '#27a644', fontWeight: 600, fontFamily: 'monospace' }}>
                  {batteryPercent}%
                </span>
              </div>
              <div style={{ width: '100%', height: 6, borderRadius: 3, background: '#141516', overflow: 'hidden' }}>
                <div
                  style={{
                    width: `${batteryPercent}%`,
                    height: '100%',
                    background: '#27a644',
                    borderRadius: 3,
                    transition: 'width 0.4s ease',
                  }}
                />
              </div>
            </div>

            {/* Telemetry Gauges */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 10 }}>
              <div style={{ background: '#141516', borderRadius: 6, padding: '12px 14px', border: '1px solid #23252a' }}>
                <div style={{ fontSize: 11, color: '#8a8f98', marginBottom: 2 }}>Energy Dispatched</div>
                <div style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                  {simulatedKwh} <span style={{ fontSize: 11, color: '#62666d' }}>kWh</span>
                </div>
              </div>

              <div style={{ background: '#141516', borderRadius: 6, padding: '12px 14px', border: '1px solid #23252a' }}>
                <div style={{ fontSize: 11, color: '#8a8f98', marginBottom: 2 }}>Current Draw</div>
                <div style={{ fontSize: 20, fontWeight: 600, color: '#27a644', fontFamily: 'monospace' }}>
                  7.2 <span style={{ fontSize: 11, color: '#62666d' }}>kW</span>
                </div>
              </div>

              <div style={{ background: '#141516', borderRadius: 6, padding: '12px 14px', border: '1px solid #23252a' }}>
                <div style={{ fontSize: 11, color: '#8a8f98', marginBottom: 2 }}>Duration Elapsed</div>
                <div style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                  {Math.floor(simulatedMinutes / 60)}h {simulatedMinutes % 60}m
                </div>
              </div>

              <div style={{ background: '#141516', borderRadius: 6, padding: '12px 14px', border: '1px solid #23252a' }}>
                <div style={{ fontSize: 11, color: '#8a8f98', marginBottom: 2 }}>Accumulated Total</div>
                <div style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                  ₹{liveCost}
                </div>
              </div>
            </div>
          </div>
        ) : (
          user?.role === 'HOMEOWNER' &&
          confirmedReservations.length > 0 && (
            <div className="panel" style={{ padding: '18px 20px', marginBottom: 24 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <Play size={15} color="#27a644" />
                <h3 style={{ fontSize: 14, fontWeight: 600, color: '#f7f8f8' }}>
                  Start Charging for Confirmed Driver
                </h3>
              </div>
              <p style={{ color: '#8a8f98', fontSize: 12, marginBottom: 14 }}>
                A driver has arrived for an approved reservation. Initiate session telemetry:
              </p>

              <form onSubmit={handleStartSession} style={{ display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'center' }}>
                <select
                  value={selectedResId}
                  onChange={(e) => setSelectedResId(e.target.value)}
                  style={{
                    flex: '1 1 300px',
                    padding: '8px 12px',
                    borderRadius: 6,
                    background: '#141516',
                    border: '1px solid #23252a',
                    color: '#f7f8f8',
                    fontSize: 12,
                    outline: 'none',
                  }}
                >
                  {confirmedReservations.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.station?.stationName || r.station?.name} – Driver:{' '}
                      {r.user?.fullName || r.evOwner?.fullName || 'Driver'} ({r.startTime} – {r.endTime})
                    </option>
                  ))}
                </select>

                <button
                  type="submit"
                  disabled={startingSession}
                  className="btn-primary"
                  style={{ padding: '8px 16px', fontSize: 12 }}
                >
                  <Play size={13} fill="currentColor" />
                  {startingSession ? 'Initiating...' : 'Start Session'}
                </button>
              </form>
            </div>
          )
        )}

        {/* SESSIONS HISTORY */}
        <div>
          <h2 style={{ fontSize: 14, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.01em', marginBottom: 14 }}>
            Session Invoices & History
          </h2>

          {loading ? (
            <div style={{ textAlign: 'center', padding: 40, color: '#8a8f98' }}>
              <div className="spinner mx-auto mb-3" />
              Loading history...
            </div>
          ) : sessions.length === 0 ? (
            <div className="panel" style={{ padding: '40px 20px', textAlign: 'center' }}>
              <Zap size={28} color="#3e3e44" style={{ margin: '0 auto 10px' }} />
              <p style={{ fontSize: 12, color: '#8a8f98' }}>No completed sessions recorded yet.</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {sessions.map((s) => {
                const isPaid = !!s.payment;
                const isCompleted = s.sessionStatus === 'COMPLETED';
                const dateStr = s.sessionStart
                  ? new Date(s.sessionStart).toLocaleDateString(undefined, {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : 'N/A';

                return (
                  <div
                    key={s.id}
                    className="panel"
                    style={{
                      padding: '14px 18px',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      gap: 14,
                    }}
                  >
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                        <span className={isCompleted ? 'badge badge-completed' : 'badge badge-active'}>
                          {s.sessionStatus}
                        </span>
                        <span style={{ fontSize: 11, color: '#62666d', fontFamily: 'monospace' }}>
                          {dateStr}
                        </span>
                      </div>

                      <h4 style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8', marginBottom: 2 }}>
                        {s.reservation?.station?.stationName || s.reservation?.station?.name || 'Charging Session'}
                      </h4>

                      <div style={{ display: 'flex', gap: 12, fontSize: 11, color: '#8a8f98' }}>
                        <span>
                          Delivered: <strong style={{ color: '#d0d6e0', fontFamily: 'monospace' }}>{s.energyConsumedKwh || 0} kWh</strong>
                        </span>
                        <span>
                          Rate: <span style={{ fontFamily: 'monospace' }}>₹{s.pricePerKwh}/kWh</span>
                        </span>
                        {user?.role === 'HOMEOWNER' && (
                          <span>Driver: {s.reservation?.evOwner?.fullName || 'EV Driver'}</span>
                        )}
                      </div>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontSize: 14, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                          ₹{(s.totalAmount || 0).toFixed(2)}
                        </div>
                        <span className={isPaid ? 'badge badge-confirmed' : 'badge badge-pending'}>
                          {isPaid ? 'Settled' : 'Payment Due'}
                        </span>
                      </div>

                      {/* EV Owner Pay Button */}
                      {user?.role === 'EV_OWNER' && isCompleted && !isPaid && (
                        <button
                          onClick={() => {
                            setPayingSession(s);
                            setPayModalOpen(true);
                          }}
                          className="btn-primary"
                          style={{ padding: '5px 12px', fontSize: 11 }}
                        >
                          <CreditCard size={12} /> Pay Now
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Complete Session Modal (Homeowner) */}
        {completeModalOpen && (
          <div
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9999,
              background: 'rgba(0, 0, 0, 0.75)',
              backdropFilter: 'blur(4px)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 16,
            }}
          >
            <div
              style={{
                background: '#0f1011',
                border: '1px solid #23252a',
                borderRadius: 8,
                width: '100%',
                maxWidth: 400,
                padding: '24px',
                position: 'relative',
                boxShadow: '0 24px 64px rgba(0,0,0,0.8)',
              }}
            >
              <button
                onClick={() => setCompleteModalOpen(false)}
                aria-label="Close"
                style={{
                  position: 'absolute',
                  right: 16,
                  top: 16,
                  background: 'none',
                  border: 'none',
                  color: '#62666d',
                  cursor: 'pointer',
                }}
              >
                <X size={16} />
              </button>

              <h2 style={{ fontSize: 16, fontWeight: 600, color: '#f7f8f8', marginBottom: 4 }}>
                Complete Session
              </h2>
              <p style={{ color: '#8a8f98', fontSize: 12, marginBottom: 16 }}>
                Record final dispensed energy in kWh to calculate total invoice amount.
              </p>

              <form onSubmit={handleCompleteSession}>
                <div style={{ marginBottom: 14 }}>
                  <label className="form-label">Energy Dispensed (kWh)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.1"
                    value={finalKwh}
                    onChange={(e) => setFinalKwh(e.target.value)}
                    required
                    className="form-input"
                    style={{ fontSize: 16, fontFamily: 'monospace', fontWeight: 600 }}
                  />
                </div>

                <div
                  style={{
                    background: '#141516',
                    borderRadius: 6,
                    padding: 12,
                    border: '1px solid #23252a',
                    marginBottom: 16,
                    fontSize: 12,
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ color: '#8a8f98' }}>Rate per kWh:</span>
                    <span style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>₹{activeRate}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 6, borderTop: '1px solid #23252a' }}>
                    <span style={{ color: '#f7f8f8', fontWeight: 500 }}>Invoice Total:</span>
                    <span style={{ color: '#27a644', fontWeight: 600, fontFamily: 'monospace' }}>
                      ₹{(finalKwh * activeRate).toFixed(2)}
                    </span>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 10 }}>
                  <button
                    type="button"
                    onClick={() => setCompleteModalOpen(false)}
                    className="btn-secondary"
                    style={{ flex: 1, padding: '7px 14px' }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={completing}
                    className="btn-primary"
                    style={{ flex: 1.5, padding: '7px 14px' }}
                  >
                    {completing ? 'Completing...' : 'Generate Invoice'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* EV Owner Payment Modal */}
        {payModalOpen && payingSession && (
          <div
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9999,
              background: 'rgba(0, 0, 0, 0.75)',
              backdropFilter: 'blur(4px)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 16,
            }}
          >
            <div
              style={{
                background: '#0f1011',
                border: '1px solid #23252a',
                borderRadius: 8,
                width: '100%',
                maxWidth: 400,
                padding: '24px',
                position: 'relative',
                boxShadow: '0 24px 64px rgba(0,0,0,0.8)',
              }}
            >
              <button
                onClick={() => setPayModalOpen(false)}
                aria-label="Close"
                style={{
                  position: 'absolute',
                  right: 16,
                  top: 16,
                  background: 'none',
                  border: 'none',
                  color: '#62666d',
                  cursor: 'pointer',
                }}
              >
                <X size={16} />
              </button>

              <h2 style={{ fontSize: 16, fontWeight: 600, color: '#f7f8f8', marginBottom: 2 }}>
                Settle Invoice
              </h2>
              <p style={{ color: '#8a8f98', fontSize: 12, marginBottom: 16 }}>
                {payingSession.reservation?.station?.stationName || 'Charging Station'}
              </p>

              <form onSubmit={handlePaySession}>
                {/* Bill Amount Display */}
                <div
                  style={{
                    background: '#141516',
                    borderRadius: 6,
                    padding: 16,
                    textAlign: 'center',
                    border: '1px solid #23252a',
                    marginBottom: 16,
                  }}
                >
                  <div style={{ fontSize: 10, color: '#62666d', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 2 }}>
                    Amount Due
                  </div>
                  <div style={{ fontSize: 26, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                    ₹{(payingSession.totalAmount || 0).toFixed(2)}
                  </div>
                  <div style={{ fontSize: 11, color: '#8a8f98', marginTop: 2 }}>
                    {payingSession.energyConsumedKwh} kWh @ ₹{payingSession.pricePerKwh}/kWh
                  </div>
                </div>

                {/* Payment Method Selector */}
                <div style={{ marginBottom: 16 }}>
                  <label className="form-label">Payment Channel</label>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                    {['UPI', 'CARD', 'NET_BANKING', 'WALLET'].map((method) => {
                      const active = paymentMethod === method;
                      return (
                        <button
                          key={method}
                          type="button"
                          onClick={() => setPaymentMethod(method)}
                          style={{
                            padding: '8px 10px',
                            borderRadius: 4,
                            fontSize: 11,
                            fontWeight: 500,
                            background: active ? '#191a1b' : '#141516',
                            color: active ? '#f7f8f8' : '#8a8f98',
                            border: active ? '1px solid #5e6ad2' : '1px solid #23252a',
                            cursor: 'pointer',
                          }}
                        >
                          {method.replace('_', ' ')}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 10 }}>
                  <button
                    type="button"
                    onClick={() => setPayModalOpen(false)}
                    className="btn-secondary"
                    style={{ flex: 1, padding: '7px 14px' }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submittingPayment}
                    className="btn-primary"
                    style={{ flex: 1.5, padding: '7px 14px' }}
                  >
                    {submittingPayment ? 'Processing...' : `Pay ₹${(payingSession.totalAmount || 0).toFixed(2)}`}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
