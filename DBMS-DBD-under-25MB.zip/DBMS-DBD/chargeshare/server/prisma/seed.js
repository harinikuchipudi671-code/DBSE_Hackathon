const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding ChargeShare database...');

  // Clear existing data
  await prisma.notification.deleteMany();
  await prisma.review.deleteMany();
  await prisma.payment.deleteMany();
  await prisma.chargingSession.deleteMany();
  await prisma.reservation.deleteMany();
  await prisma.availabilitySlot.deleteMany();
  await prisma.chargingStation.deleteMany();
  await prisma.evProfile.deleteMany();
  await prisma.user.deleteMany();

  const hash = async (pw) => bcrypt.hash(pw, 12);

  // Users
  const admin = await prisma.user.create({
    data: { fullName: 'Admin User', email: 'admin@chargeshare.com', passwordHash: await hash('Admin@123'), role: 'ADMIN', phoneNumber: '9000000001' }
  });

  const homeowner1 = await prisma.user.create({
    data: { fullName: 'Rajesh Sharma', email: 'rajesh@example.com', passwordHash: await hash('Password@123'), role: 'HOMEOWNER', phoneNumber: '9876543210' }
  });
  const homeowner2 = await prisma.user.create({
    data: { fullName: 'Priya Patel', email: 'priya@example.com', passwordHash: await hash('Password@123'), role: 'HOMEOWNER', phoneNumber: '9876543211' }
  });
  const homeowner3 = await prisma.user.create({
    data: { fullName: 'Vikram Nair', email: 'vikram@example.com', passwordHash: await hash('Password@123'), role: 'HOMEOWNER', phoneNumber: '9876543212' }
  });

  const evOwner1 = await prisma.user.create({
    data: { fullName: 'Arjun Mehta', email: 'arjun@example.com', passwordHash: await hash('Password@123'), role: 'EV_OWNER', phoneNumber: '9123456789' }
  });
  const evOwner2 = await prisma.user.create({
    data: { fullName: 'Sneha Gupta', email: 'sneha@example.com', passwordHash: await hash('Password@123'), role: 'EV_OWNER', phoneNumber: '9123456790' }
  });
  const evOwner3 = await prisma.user.create({
    data: { fullName: 'Rahul Verma', email: 'rahul@example.com', passwordHash: await hash('Password@123'), role: 'EV_OWNER', phoneNumber: '9123456791' }
  });

  // EV Profiles
  await prisma.evProfile.create({ data: { userId: evOwner1.id, vehicleModel: 'Tata Nexon EV', registrationNumber: 'MH01AB1234', batteryCapacity: 30.2, connectorType: 'CCS' } });
  await prisma.evProfile.create({ data: { userId: evOwner2.id, vehicleModel: 'MG ZS EV', registrationNumber: 'DL02CD5678', batteryCapacity: 50.3, connectorType: 'Type2' } });
  await prisma.evProfile.create({ data: { userId: evOwner3.id, vehicleModel: 'Hyundai Ioniq 5', registrationNumber: 'KA03EF9012', batteryCapacity: 72.6, connectorType: 'CCS' } });

  // Charging Stations - Mumbai/India coordinates
  const station1 = await prisma.chargingStation.create({
    data: {
      homeownerId: homeowner1.id,
      stationName: 'Sharma Residence Charger',
      description: 'Level 2 home charger with covered parking. Clean and safe environment.',
      completeAddress: '12, Green Park Colony, Bandra West, Mumbai 400050',
      latitude: 19.0596,
      longitude: 72.8295,
      chargerType: 'Level2',
      connectorType: 'CCS',
      chargingCapacityKw: 7.4,
      pricePerKwh: 12.5,
      amenities: JSON.stringify(['WiFi', 'Covered Parking', 'Restroom', 'Water']),
      verificationStatus: 'VERIFIED',
      isActive: true
    }
  });

  const station2 = await prisma.chargingStation.create({
    data: {
      homeownerId: homeowner2.id,
      stationName: 'Priya\'s Fast Charger',
      description: 'DC fast charger in gated community. 24/7 access for confirmed bookings.',
      completeAddress: '45B, Koregaon Park, Pune 411001',
      latitude: 18.5362,
      longitude: 73.8944,
      chargerType: 'DC_Fast',
      connectorType: 'Type2',
      chargingCapacityKw: 22.0,
      pricePerKwh: 15.0,
      amenities: JSON.stringify(['WiFi', 'Security Camera', 'Tea/Coffee']),
      verificationStatus: 'VERIFIED',
      isActive: true
    }
  });

  const station3 = await prisma.chargingStation.create({
    data: {
      homeownerId: homeowner3.id,
      stationName: 'Vikram\'s EV Hub',
      description: 'Multiple connector types available. Great for long-distance travelers.',
      completeAddress: '88, Indiranagar, Bengaluru 560038',
      latitude: 12.9784,
      longitude: 77.6408,
      chargerType: 'Level2',
      connectorType: 'Multiple',
      chargingCapacityKw: 11.0,
      pricePerKwh: 10.0,
      amenities: JSON.stringify(['WiFi', 'Snacks', 'Waiting Area', 'Restroom']),
      verificationStatus: 'VERIFIED',
      isActive: true
    }
  });

  const station4 = await prisma.chargingStation.create({
    data: {
      homeownerId: homeowner1.id,
      stationName: 'Sharma South Mumbai Charger',
      description: 'Convenient Level 1 charger near Colaba area.',
      completeAddress: '3, Apollo Bunder, Colaba, Mumbai 400005',
      latitude: 18.9218,
      longitude: 72.8323,
      chargerType: 'Level1',
      connectorType: 'J1772',
      chargingCapacityKw: 3.3,
      pricePerKwh: 8.0,
      amenities: JSON.stringify(['Covered Parking']),
      verificationStatus: 'VERIFIED',
      isActive: true
    }
  });

  // Availability Slots (future dates)
  const today = new Date();
  const formatDate = (d) => d.toISOString().split('T')[0];
  const addDays = (d, n) => { const r = new Date(d); r.setDate(r.getDate() + n); return r; };

  // Station 1 slots
  for (let i = 1; i <= 7; i++) {
    const date = formatDate(addDays(today, i));
    await prisma.availabilitySlot.create({ data: { stationId: station1.id, availableDate: date, startTime: '09:00', endTime: '13:00' } });
    await prisma.availabilitySlot.create({ data: { stationId: station1.id, availableDate: date, startTime: '14:00', endTime: '18:00' } });
  }

  // Station 2 slots
  for (let i = 1; i <= 5; i++) {
    const date = formatDate(addDays(today, i));
    await prisma.availabilitySlot.create({ data: { stationId: station2.id, availableDate: date, startTime: '08:00', endTime: '20:00' } });
  }

  // Station 3 slots
  for (let i = 1; i <= 7; i++) {
    const date = formatDate(addDays(today, i));
    await prisma.availabilitySlot.create({ data: { stationId: station3.id, availableDate: date, startTime: '10:00', endTime: '14:00' } });
    await prisma.availabilitySlot.create({ data: { stationId: station3.id, availableDate: date, startTime: '15:00', endTime: '20:00' } });
  }

  // Station 4 slots
  for (let i = 1; i <= 7; i++) {
    const date = formatDate(addDays(today, i));
    await prisma.availabilitySlot.create({ data: { stationId: station4.id, availableDate: date, startTime: '06:00', endTime: '22:00' } });
  }

  // Sample completed reservation with session, payment, and review
  const pastDate = formatDate(addDays(today, -3));
  const pastSlot = await prisma.availabilitySlot.create({
    data: { stationId: station1.id, availableDate: pastDate, startTime: '10:00', endTime: '14:00', slotStatus: 'BOOKED' }
  });

  const completedReservation = await prisma.reservation.create({
    data: {
      evOwnerId: evOwner1.id,
      stationId: station1.id,
      slotId: pastSlot.id,
      bookingDate: pastDate,
      startTime: '10:00',
      endTime: '14:00',
      estimatedEnergy: 20,
      estimatedCost: 250,
      bookingStatus: 'COMPLETED'
    }
  });

  const session = await prisma.chargingSession.create({
    data: {
      reservationId: completedReservation.id,
      sessionStart: new Date(addDays(today, -3).setHours(10, 5)),
      sessionEnd: new Date(addDays(today, -3).setHours(13, 45)),
      energyConsumedKwh: 22.4,
      pricePerKwh: 12.5,
      totalAmount: 280.0,
      sessionStatus: 'COMPLETED'
    }
  });

  await prisma.payment.create({
    data: {
      sessionId: session.id,
      payerId: evOwner1.id,
      receiverId: homeowner1.id,
      amount: 280.0,
      paymentMethod: 'UPI',
      paymentStatus: 'COMPLETED',
      transactionReference: 'TXN-SEED-001-ABC123'
    }
  });

  await prisma.review.create({
    data: {
      reservationId: completedReservation.id,
      reviewerId: evOwner1.id,
      homeownerId: homeowner1.id,
      stationId: station1.id,
      rating: 5,
      comment: 'Excellent charging experience! Rajesh was very helpful and the charger worked perfectly. Will definitely book again!'
    }
  });

  // Sample CONFIRMED reservation (ready to start session)
  const tomorrowDate = formatDate(addDays(today, 1));
  const tomorrowSlots = await prisma.availabilitySlot.findMany({
    where: { stationId: station2.id, availableDate: tomorrowDate }
  });
  if (tomorrowSlots.length > 0) {
    await prisma.reservation.create({
      data: {
        evOwnerId: evOwner2.id,
        stationId: station2.id,
        slotId: tomorrowSlots[0].id,
        bookingDate: tomorrowDate,
        startTime: tomorrowSlots[0].startTime,
        endTime: tomorrowSlots[0].endTime,
        estimatedEnergy: 30,
        estimatedCost: 450,
        bookingStatus: 'CONFIRMED'
      }
    });
    await prisma.availabilitySlot.update({ where: { id: tomorrowSlots[0].id }, data: { slotStatus: 'BOOKED' } });
  }

  // Notifications
  await prisma.notification.createMany({
    data: [
      { userId: homeowner1.id, title: 'Welcome to ChargeShare!', message: 'Start earning by listing your EV charger today.', notificationType: 'SYSTEM' },
      { userId: evOwner1.id, title: 'Booking Completed', message: 'Your session at Sharma Residence Charger has been completed. Total: ₹280.00', notificationType: 'SESSION', isRead: true },
      { userId: evOwner2.id, title: 'Booking Confirmed!', message: 'Your booking at Priya\'s Fast Charger has been confirmed!', notificationType: 'BOOKING' },
    ]
  });

  console.log('✅ Seeding complete!\n');
  console.log('Test Accounts:');
  console.log('  Admin: admin@chargeshare.com / Admin@123');
  console.log('  Homeowner 1: rajesh@example.com / Password@123');
  console.log('  Homeowner 2: priya@example.com / Password@123');
  console.log('  Homeowner 3: vikram@example.com / Password@123');
  console.log('  EV Owner 1: arjun@example.com / Password@123');
  console.log('  EV Owner 2: sneha@example.com / Password@123');
  console.log('  EV Owner 3: rahul@example.com / Password@123\n');
}

main().catch(console.error).finally(() => prisma.$disconnect());
