const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const {
  createReservation, getMyReservations, getReceivedReservations,
  getReservationById, updateReservationStatus, cancelReservation
} = require('../controllers/reservationController');

router.post('/', authenticate, authorize('EV_OWNER'), createReservation);
router.get('/my', authenticate, getMyReservations);
router.get('/received', authenticate, authorize('HOMEOWNER'), getReceivedReservations);
router.get('/:id', authenticate, getReservationById);
router.patch('/:id/status', authenticate, authorize('HOMEOWNER'), updateReservationStatus);
router.post('/:id/cancel', authenticate, cancelReservation);

module.exports = router;
