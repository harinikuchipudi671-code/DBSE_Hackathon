import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Calendar, Battery, TrendingUp, Clock, CheckCircle, ArrowRight } from 'lucide-react';
import DashboardLayout from '../layouts/DashboardLayout';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const StatCard = ({ icon: Icon, label, value, sub }) => (
  <div className="stat-card">
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
      <span style={{ fontSize: 12, fontWeight: 500, color: '#8a8f98' }}>{label}</span>
      <div
        style={{
          width: 28,
          height: 28,
          borderRadius: 6,
          background: '#141516',
          border: '1px solid #23252a',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#8a8f98',
        }}
      >
        <Icon size={14} />
      </div>
    </div>
    <div style={{ fontSize: 24, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace', letterSpacing: '-0.02em', marginBottom: 4 }}>
      {value}
    </div>
    {sub && <div style={{ fontSize: 11, color: '#62666d' }}>{sub}</div>}
  </div>
);

export default function EVOwnerDashboard() {
  const { user } = useAuth();
  const [reservations, setReservations] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.get('/reservations/my'), api.get('/sessions/history')])
      .then(([r, s]) => {
        setReservations(r.data?.data || []);
        setSessions(s.data?.data || []);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const totalEnergy = sessions
    .filter((s) => s.sessionStatus === 'COMPLETED')
    .reduce((a, s) => a + (s.energyConsumedKwh || 0), 0);

  const totalPaid = sessions
    .filter((s) => s.sessionStatus === 'COMPLETED')
    .reduce((a, s) => a + (s.totalAmount || 0), 0);

  const upcoming = reservations.filter((r) => ['PENDING', 'CONFIRMED'].includes(r.bookingStatus));
  const active = reservations.find((r) => r.chargingSession?.sessionStatus === 'ACTIVE');

  const statusBadge = (s) => {
    const map = {
      PENDING: 'badge-pending',
      CONFIRMED: 'badge-confirmed',
      REJECTED: 'badge-rejected',
      CANCELLED: 'badge-cancelled',
      COMPLETED: 'badge-completed',
    };
    return <span className={`badge ${map[s] || 'badge-pending'}`}>{s}</span>;
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 300 }}>
          <div className="spinner" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      {/* Page Header */}
      <div style={{ marginBottom: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
            Overview
          </h1>
          <p style={{ color: '#8a8f98', fontSize: 13 }}>
            Telemetry and upcoming bookings for {user?.fullName || 'Driver'}
          </p>
        </div>
        <Link to="/find" className="btn-primary" style={{ textDecoration: 'none', padding: '7px 14px', fontSize: 13 }}>
          <MapPin size={14} /> Find Charger
        </Link>
      </div>

      {/* Active Session Notification */}
      {active && (
        <div
          style={{
            marginBottom: 20,
            padding: '14px 18px',
            borderRadius: 8,
            background: '#0f1011',
            border: '1px solid #27a644',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 16,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span
              style={{
                width: 8,
                height: 8,
                borderRadius: '50%',
                background: '#27a644',
                boxShadow: '0 0 8px rgba(39, 166, 68, 0.6)',
              }}
            />
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8' }}>
                Active Charging Session in Progress
              </div>
              <div style={{ fontSize: 12, color: '#8a8f98' }}>
                Connected at {active.station?.stationName || 'Station'} · Port: Level 2 AC
              </div>
            </div>
          </div>
          <Link
            to="/sessions"
            className="btn-secondary"
            style={{ textDecoration: 'none', padding: '6px 12px', fontSize: 12 }}
          >
            Live Monitor <ArrowRight size={13} />
          </Link>
        </div>
      )}

      {/* Telemetry Stat Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: 14, marginBottom: 24 }}>
        <StatCard icon={Calendar} label="Total Bookings" value={reservations.length} sub={`${upcoming.length} upcoming`} />
        <StatCard
          icon={CheckCircle}
          label="Completed Sessions"
          value={sessions.filter((s) => s.sessionStatus === 'COMPLETED').length}
          sub="Verified charging"
        />
        <StatCard
          icon={Battery}
          label="Energy Delivered"
          value={`${totalEnergy.toFixed(1)} kWh`}
          sub="Dispatched power"
        />
        <StatCard
          icon={TrendingUp}
          label="Cumulative Expenditure"
          value={`₹${totalPaid.toFixed(2)}`}
          sub="Reconciled payments"
        />
      </div>

      {/* Main Grid: Quick Actions + Bookings */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: 20 }}>
        {/* Left Column: Quick Actions & Registered Vehicle */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="panel" style={{ padding: '18px 20px' }}>
            <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.01em', marginBottom: 14 }}>
              Navigation Shortcuts
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <Link
                to="/find"
                style={{
                  padding: '10px 14px',
                  borderRadius: 6,
                  background: '#141516',
                  border: '1px solid #23252a',
                  textDecoration: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  transition: 'border-color 0.15s ease',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = '#34343a')}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = '#23252a')}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <MapPin size={16} color="#5e6ad2" />
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8' }}>Find Nearby Chargers</div>
                    <div style={{ fontSize: 11, color: '#8a8f98' }}>Interactive geospatial map & instant filter</div>
                  </div>
                </div>
                <ArrowRight size={14} color="#62666d" />
              </Link>

              <Link
                to="/reservations"
                style={{
                  padding: '10px 14px',
                  borderRadius: 6,
                  background: '#141516',
                  border: '1px solid #23252a',
                  textDecoration: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  transition: 'border-color 0.15s ease',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = '#34343a')}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = '#23252a')}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <Calendar size={16} color="#8a8f98" />
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8' }}>Booking Schedule</div>
                    <div style={{ fontSize: 11, color: '#8a8f98' }}>{upcoming.length} active or pending</div>
                  </div>
                </div>
                <ArrowRight size={14} color="#62666d" />
              </Link>

              <Link
                to="/payments"
                style={{
                  padding: '10px 14px',
                  borderRadius: 6,
                  background: '#141516',
                  border: '1px solid #23252a',
                  textDecoration: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  transition: 'border-color 0.15s ease',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = '#34343a')}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = '#23252a')}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <TrendingUp size={16} color="#8a8f98" />
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8' }}>Payment Records</div>
                    <div style={{ fontSize: 11, color: '#8a8f98' }}>Invoices and settlement logs</div>
                  </div>
                </div>
                <ArrowRight size={14} color="#62666d" />
              </Link>
            </div>
          </div>

          {/* Vehicle Profile Widget */}
          <div className="panel" style={{ padding: '18px 20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.01em' }}>
                Vehicle Telemetry Profile
              </h2>
              <Link to="/profile" style={{ fontSize: 11, color: '#5e6ad2', textDecoration: 'none' }}>
                Edit
              </Link>
            </div>
            {user?.evProfile ? (
              <div
                style={{
                  padding: '12px 14px',
                  borderRadius: 6,
                  background: '#141516',
                  border: '1px solid #23252a',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}
              >
                <div>
                  <div style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8' }}>
                    {user.evProfile.vehicleModel || 'Electric Vehicle'}
                  </div>
                  <div style={{ fontSize: 11, color: '#8a8f98', marginTop: 2 }}>
                    Connector: <span style={{ color: '#d0d6e0' }}>{user.evProfile.connectorType || 'CCS'}</span> · Battery:{' '}
                    <span style={{ color: '#d0d6e0' }}>{user.evProfile.batteryCapacity || '40'} kWh</span>
                  </div>
                </div>
                <span className="badge badge-completed">Verified</span>
              </div>
            ) : (
              <div style={{ fontSize: 12, color: '#8a8f98', textAlign: 'center', padding: '14px 0' }}>
                No vehicle details registered.{' '}
                <Link to="/profile" style={{ color: '#5e6ad2', textDecoration: 'none' }}>
                  Add vehicle profile →
                </Link>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Upcoming Bookings */}
        <div className="panel" style={{ padding: '18px 20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.01em' }}>
              Upcoming Bookings
            </h2>
            <Link to="/reservations" style={{ fontSize: 12, color: '#8a8f98', textDecoration: 'none' }}>
              View all →
            </Link>
          </div>

          {upcoming.length === 0 ? (
            <div style={{ padding: '48px 16px', textAlign: 'center' }}>
              <Clock size={28} color="#3e3e44" style={{ margin: '0 auto 12px' }} />
              <div style={{ color: '#8a8f98', fontSize: 13, marginBottom: 14 }}>
                No active or upcoming reservations scheduled
              </div>
              <Link to="/find" className="btn-secondary" style={{ textDecoration: 'none', fontSize: 12, padding: '6px 14px' }}>
                Discover Ports
              </Link>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {upcoming.slice(0, 4).map((r) => (
                <div
                  key={r.id}
                  style={{
                    padding: '12px 14px',
                    borderRadius: 6,
                    background: '#141516',
                    border: '1px solid #23252a',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}
                >
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8', marginBottom: 3 }}>
                      {r.station?.stationName || 'Homeowner Station'}
                    </div>
                    <div style={{ fontSize: 11, color: '#8a8f98' }}>
                      {r.bookingDate} · {r.startTime} – {r.endTime}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ marginBottom: 4 }}>{statusBadge(r.bookingStatus)}</div>
                    {r.estimatedCost && (
                      <div style={{ fontSize: 11, color: '#d0d6e0', fontFamily: 'monospace' }}>
                        ≈ ₹{r.estimatedCost.toFixed(2)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
