import { useState, useEffect } from 'react';
import { DollarSign, TrendingUp, Zap, CheckCircle, CreditCard, Building2, X } from 'lucide-react';
import DashboardLayout from '../layouts/DashboardLayout';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

const StatCard = ({ icon: Icon, label, value, sub }) => (
  <div className="stat-card">
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
      <span style={{ fontSize: 12, fontWeight: 500, color: '#8a8f98' }}>{label}</span>
      <div
        style={{
          width: 28,
          height: 28,
          borderRadius: 6,
          background: '#141516',
          border: '1px solid #23252a',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#8a8f98',
        }}
      >
        <Icon size={14} />
      </div>
    </div>
    <div style={{ fontSize: 24, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace', letterSpacing: '-0.02em', marginBottom: 4 }}>
      {value}
    </div>
    {sub && <div style={{ fontSize: 11, color: '#62666d' }}>{sub}</div>}
  </div>
);

export default function Earnings() {
  const { user } = useAuth();
  const [sessions, setSessions] = useState([]);
  const [stations, setStations] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStation, setFilterStation] = useState('ALL');
  const [payoutModal, setPayoutModal] = useState(false);
  const [payoutSuccess, setPayoutSuccess] = useState(false);
  const [upiId, setUpiId] = useState('rajesh@okhdfcbank');

  useEffect(() => {
    Promise.all([
      api.get('/sessions/history'),
      api.get('/stations/my'),
      api.get('/payments/history'),
    ])
      .then(([sesRes, staRes, payRes]) => {
        setSessions(sesRes.data?.data || []);
        setStations(staRes.data?.data || []);
        setPayments(payRes.data?.data || []);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const completedSessions = sessions.filter((s) => s.sessionStatus === 'COMPLETED');
  const filteredSessions =
    filterStation === 'ALL'
      ? completedSessions
      : completedSessions.filter((s) => s.reservation?.stationId === parseInt(filterStation));

  const totalEarned = completedSessions.reduce((acc, s) => acc + (s.totalAmount || 0), 0);
  const totalKwh = completedSessions.reduce((acc, s) => acc + (s.energyConsumedKwh || 0), 0);
  const avgSessionEarning = completedSessions.length > 0 ? totalEarned / completedSessions.length : 0;

  const handleRequestPayout = (e) => {
    e.preventDefault();
    setPayoutSuccess(true);
    setTimeout(() => {
      setPayoutSuccess(false);
      setPayoutModal(false);
    }, 1800);
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 300 }}>
          <div className="spinner" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 20, flexWrap: 'wrap', gap: 16 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
            Host Financial Telemetry
          </h1>
          <p style={{ color: '#8a8f98', fontSize: 13 }}>
            Yield analytics, automated settlement logs, and station revenue attribution
          </p>
        </div>
        <button
          onClick={() => setPayoutModal(true)}
          className="btn-primary"
          style={{ padding: '7px 14px', fontSize: 13 }}
        >
          <CreditCard size={14} /> Request Payout
        </button>
      </div>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: 14, marginBottom: 24 }}>
        <StatCard
          icon={TrendingUp}
          label="Total Settled Revenue"
          value={`₹${totalEarned.toFixed(2)}`}
          sub={`${completedSessions.length} completed sessions`}
        />
        <StatCard
          icon={Zap}
          label="Dispatched Energy"
          value={`${totalKwh.toFixed(1)} kWh`}
          sub="Dispatched to drivers"
        />
        <StatCard
          icon={DollarSign}
          label="Average Yield / Session"
          value={`₹${avgSessionEarning.toFixed(2)}`}
          sub="Average ticket value"
        />
        <StatCard
          icon={Building2}
          label="Active Chargers"
          value={stations.filter((s) => s.isActive).length}
          sub={`${stations.length} hardware nodes`}
        />
      </div>

      {/* Breakdown Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 16, marginBottom: 24 }}>
        {/* Revenue by Station */}
        <div className="panel" style={{ padding: '20px' }}>
          <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.01em', marginBottom: 14 }}>
            Revenue Attribution by Port
          </h2>
          {stations.length === 0 ? (
            <div style={{ color: '#62666d', fontSize: 12, textAlign: 'center', padding: '24px 0' }}>
              No stations registered yet.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {stations.map((st) => {
                const stSessions = completedSessions.filter((s) => s.reservation?.stationId === st.id);
                const stEarned = stSessions.reduce((sum, s) => sum + (s.totalAmount || 0), 0);
                const pct = totalEarned > 0 ? ((stEarned / totalEarned) * 100).toFixed(0) : 0;
                return (
                  <div
                    key={st.id}
                    style={{
                      padding: '12px 14px',
                      borderRadius: 6,
                      background: '#141516',
                      border: '1px solid #23252a',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8' }}>{st.stationName}</div>
                        <div style={{ fontSize: 11, color: '#8a8f98' }}>
                          ₹{st.pricePerKwh}/kWh · {stSessions.length} sessions
                        </div>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontSize: 14, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                          ₹{stEarned.toFixed(2)}
                        </div>
                        <div style={{ fontSize: 10, color: '#62666d' }}>{pct}% share</div>
                      </div>
                    </div>
                    <div style={{ width: '100%', height: 4, background: '#1e2024', borderRadius: 2, overflow: 'hidden' }}>
                      <div style={{ width: `${pct}%`, height: '100%', background: '#5e6ad2', borderRadius: 2 }} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Payout & Banking Info */}
        <div className="panel" style={{ padding: '20px' }}>
          <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.01em', marginBottom: 14 }}>
            Settlement Account
          </h2>
          <div
            style={{
              padding: '14px',
              borderRadius: 6,
              background: '#141516',
              border: '1px solid #23252a',
              marginBottom: 16,
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#27a644' }} />
              <span style={{ fontSize: 11, fontWeight: 500, color: '#27a644', textTransform: 'uppercase' }}>
                Instant Disbursal Active
              </span>
            </div>
            <div style={{ fontSize: 14, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace', marginBottom: 2 }}>
              {upiId}
            </div>
            <div style={{ fontSize: 11, color: '#8a8f98' }}>
              Standard automated reconciliation via UPI Protocol
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: 12, color: '#8a8f98' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #1a1c20' }}>
              <span>Available Balance</span>
              <span style={{ color: '#27a644', fontWeight: 600, fontFamily: 'monospace' }}>
                ₹{totalEarned.toFixed(2)}
              </span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #1a1c20' }}>
              <span>Platform Take-Rate</span>
              <span style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>0.0% (Fee Waiver)</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0' }}>
              <span>Settlement Window</span>
              <span style={{ color: '#f7f8f8' }}>On Demand</span>
            </div>
          </div>
        </div>
      </div>

      {/* Transaction History Table */}
      <div className="panel" style={{ padding: '0', overflow: 'hidden' }}>
        <div style={{ padding: '14px 18px', borderBottom: '1px solid #23252a', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8' }}>Settled Driver Sessions</h2>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 11, color: '#8a8f98' }}>Filter Station:</span>
            <select
              value={filterStation}
              onChange={(e) => setFilterStation(e.target.value)}
              style={{
                padding: '4px 8px',
                borderRadius: 4,
                background: '#141516',
                border: '1px solid #23252a',
                color: '#f7f8f8',
                fontSize: 11,
                outline: 'none',
              }}
            >
              <option value="ALL">All Stations</option>
              {stations.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.stationName}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Station</th>
                <th>Driver</th>
                <th>Energy</th>
                <th>Rate</th>
                <th>Net Revenue</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredSessions.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '32px 16px', color: '#62666d' }}>
                    No completed sessions recorded for this filter.
                  </td>
                </tr>
              ) : (
                filteredSessions.map((s) => {
                  const dateStr = s.sessionStart
                    ? new Date(s.sessionStart).toLocaleDateString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                      })
                    : 'N/A';
                  return (
                    <tr key={s.id}>
                      <td style={{ color: '#8a8f98', fontFamily: 'monospace' }}>{dateStr}</td>
                      <td style={{ fontWeight: 500, color: '#f7f8f8' }}>
                        {s.reservation?.station?.stationName || 'Station'}
                      </td>
                      <td style={{ color: '#d0d6e0' }}>{s.reservation?.evOwner?.fullName || 'Driver'}</td>
                      <td style={{ fontFamily: 'monospace' }}>{s.energyConsumedKwh || 0} kWh</td>
                      <td style={{ fontFamily: 'monospace' }}>₹{s.pricePerKwh}/kWh</td>
                      <td style={{ fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                        ₹{(s.totalAmount || 0).toFixed(2)}
                      </td>
                      <td>
                        <span className={s.payment ? 'badge badge-confirmed' : 'badge badge-pending'}>
                          {s.payment ? 'Disbursed' : 'In Escrow'}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payout Modal */}
      {payoutModal && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 9999,
            background: 'rgba(0, 0, 0, 0.75)',
            backdropFilter: 'blur(4px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 16,
          }}
        >
          <div
            style={{
              background: '#0f1011',
              border: '1px solid #23252a',
              borderRadius: 8,
              width: '100%',
              maxWidth: 400,
              padding: '24px',
              position: 'relative',
              boxShadow: '0 24px 64px rgba(0,0,0,0.8)',
            }}
          >
            <button
              onClick={() => setPayoutModal(false)}
              aria-label="Close"
              style={{
                position: 'absolute',
                right: 16,
                top: 16,
                background: 'none',
                border: 'none',
                color: '#62666d',
                cursor: 'pointer',
              }}
            >
              <X size={16} />
            </button>

            {payoutSuccess ? (
              <div style={{ textAlign: 'center', padding: '16px 0' }}>
                <div
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: '50%',
                    background: 'rgba(39, 166, 68, 0.1)',
                    border: '1px solid rgba(39, 166, 68, 0.25)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto 12px',
                  }}
                >
                  <CheckCircle size={20} color="#27a644" />
                </div>
                <h3 style={{ fontSize: 16, fontWeight: 600, color: '#f7f8f8', marginBottom: 4 }}>
                  Disbursal Triggered
                </h3>
                <p style={{ color: '#8a8f98', fontSize: 12 }}>
                  ₹{totalEarned.toFixed(2)} has been queued for instant settlement to {upiId}.
                </p>
              </div>
            ) : (
              <form onSubmit={handleRequestPayout}>
                <h2 style={{ fontSize: 16, fontWeight: 600, color: '#f7f8f8', marginBottom: 4 }}>
                  Request Balance Payout
                </h2>
                <p style={{ color: '#8a8f98', fontSize: 12, marginBottom: 16 }}>
                  Direct automated transfer to your linked VPA.
                </p>

                <div
                  style={{
                    background: '#141516',
                    borderRadius: 6,
                    padding: 14,
                    textAlign: 'center',
                    border: '1px solid #23252a',
                    marginBottom: 16,
                  }}
                >
                  <div style={{ fontSize: 10, color: '#62666d', textTransform: 'uppercase', marginBottom: 2 }}>
                    Withdrawable Amount
                  </div>
                  <div style={{ fontSize: 24, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace' }}>
                    ₹{totalEarned.toFixed(2)}
                  </div>
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label className="form-label">Receiving UPI ID / VPA</label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    required
                    className="form-input"
                    style={{ fontFamily: 'monospace' }}
                  />
                </div>

                <div style={{ display: 'flex', gap: 10 }}>
                  <button
                    type="button"
                    onClick={() => setPayoutModal(false)}
                    className="btn-secondary"
                    style={{ flex: 1, padding: '7px 14px' }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="btn-primary"
                    style={{ flex: 1.5, padding: '7px 14px' }}
                  >
                    Confirm Transfer
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
