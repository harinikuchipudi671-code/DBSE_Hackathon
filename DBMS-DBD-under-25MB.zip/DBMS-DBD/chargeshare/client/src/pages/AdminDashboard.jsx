import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Users, Plug, DollarSign, Star, TrendingUp, Activity, Check, Ban } from 'lucide-react';
import DashboardLayout from '../layouts/DashboardLayout';
import api from '../services/api';

const StatCard = ({ icon: Icon, label, value }) => (
  <div className="stat-card">
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
      <span style={{ fontSize: 12, fontWeight: 500, color: '#8a8f98' }}>{label}</span>
      <div
        style={{
          width: 28,
          height: 28,
          borderRadius: 6,
          background: '#141516',
          border: '1px solid #23252a',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#8a8f98',
        }}
      >
        <Icon size={14} />
      </div>
    </div>
    <div style={{ fontSize: 24, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace', letterSpacing: '-0.02em' }}>
      {value}
    </div>
  </div>
);

export default function AdminDashboard() {
  const location = useLocation();
  const getInitialTab = () => {
    if (location.pathname.includes('/users')) return 'users';
    if (location.pathname.includes('/stations')) return 'stations';
    return 'overview';
  };
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [stations, setStations] = useState([]);
  const [tab, setTab] = useState(getInitialTab);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (location.pathname.includes('/users')) setTab('users');
    else if (location.pathname.includes('/stations')) setTab('stations');
    else if (location.pathname === '/dashboard') setTab('overview');
  }, [location.pathname]);

  useEffect(() => {
    Promise.all([api.get('/admin/dashboard'), api.get('/admin/users'), api.get('/admin/stations')])
      .then(([d, u, s]) => {
        setStats(d.data?.data);
        setUsers(u.data?.data || []);
        setStations(s.data?.data || []);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const updateStationStatus = async (id, data) => {
    try {
      await api.patch(`/admin/stations/${id}/status`, data);
      const res = await api.get('/admin/stations');
      setStations(res.data?.data || []);
    } catch (e) {
      alert('Failed to update status');
    }
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 300 }}>
          <div className="spinner" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
          Platform Administration
        </h1>
        <p style={{ color: '#8a8f98', fontSize: 13 }}>System metrics, accounts, and hardware verification</p>
      </div>

      {/* Segmented Tab Controls */}
      <div
        style={{
          display: 'inline-flex',
          gap: 4,
          marginBottom: 20,
          padding: 3,
          background: '#0f1011',
          borderRadius: 6,
          border: '1px solid #23252a',
        }}
      >
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'users', label: `Users (${users.length})` },
          { id: 'stations', label: `Stations (${stations.length})` },
        ].map((t) => {
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{
                padding: '6px 14px',
                borderRadius: 4,
                border: 'none',
                cursor: 'pointer',
                background: active ? '#191a1b' : 'transparent',
                color: active ? '#f7f8f8' : '#8a8f98',
                fontSize: 12,
                fontWeight: active ? 500 : 400,
                transition: 'all 0.15s ease',
              }}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      {tab === 'overview' && stats && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: 14, marginBottom: 16 }}>
            <StatCard icon={Users} label="Total Registered Users" value={stats.totalUsers} />
            <StatCard icon={Plug} label="Network Chargers" value={stats.totalStations} />
            <StatCard icon={Activity} label="Executed Sessions" value={stats.totalSessions} />
            <StatCard
              icon={TrendingUp}
              label="Gross Settled Volume"
              value={`₹${parseFloat(stats.totalRevenue || 0).toFixed(2)}`}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: 14, marginBottom: 20 }}>
            <StatCard icon={DollarSign} label="Completed Payments" value={stats.totalPayments} />
            <StatCard icon={Star} label="Average Network Rating" value={stats.avgRating || '—'} />
            <StatCard icon={Star} label="Driver Reviews" value={stats.totalReviews} />
          </div>

          {/* Reservation Breakdown */}
          {stats.reservationsByStatus?.length > 0 && (
            <div className="panel" style={{ padding: '20px' }}>
              <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.01em', marginBottom: 14 }}>
                Reservations Categorized by Status
              </h2>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 10 }}>
                {stats.reservationsByStatus.map((r) => (
                  <div
                    key={r.bookingStatus}
                    style={{
                      padding: '12px 14px',
                      borderRadius: 6,
                      background: '#141516',
                      border: '1px solid #23252a',
                    }}
                  >
                    <div style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', fontFamily: 'monospace', marginBottom: 4 }}>
                      {r._count}
                    </div>
                    <span className={`badge badge-${r.bookingStatus.toLowerCase()}`}>{r.bookingStatus}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {tab === 'users' && (
        <div className="panel" style={{ padding: '0', overflow: 'hidden' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid #23252a' }}>
            <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8' }}>Registered User Accounts</h2>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>User</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Stations</th>
                  <th>Bookings</th>
                  <th>Created</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id}>
                    <td style={{ fontWeight: 500, color: '#f7f8f8' }}>{u.fullName}</td>
                    <td style={{ color: '#8a8f98' }}>{u.email}</td>
                    <td>
                      <span className={u.role === 'HOMEOWNER' ? 'badge badge-pending' : u.role === 'ADMIN' ? 'badge badge-rejected' : 'badge badge-completed'}>
                        {u.role}
                      </span>
                    </td>
                    <td style={{ fontFamily: 'monospace' }}>{u._count?.chargingStations ?? 0}</td>
                    <td style={{ fontFamily: 'monospace' }}>{u._count?.reservationsAsEV ?? 0}</td>
                    <td style={{ color: '#8a8f98', fontSize: 12 }}>
                      {new Date(u.createdAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'stations' && (
        <div className="panel" style={{ padding: '0', overflow: 'hidden' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid #23252a' }}>
            <h2 style={{ fontSize: 13, fontWeight: 600, color: '#f7f8f8' }}>Network Stations & Moderation</h2>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Station</th>
                  <th>Host</th>
                  <th>Hardware</th>
                  <th>Rate</th>
                  <th>Verification</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {stations.map((s) => (
                  <tr key={s.id}>
                    <td style={{ fontWeight: 500, color: '#f7f8f8' }}>{s.stationName}</td>
                    <td style={{ color: '#8a8f98' }}>{s.homeowner?.fullName || 'Host'}</td>
                    <td>{s.chargerType} · {s.connectorType}</td>
                    <td style={{ color: '#f7f8f8', fontFamily: 'monospace' }}>₹{s.pricePerKwh}/kWh</td>
                    <td>
                      <span className={s.verificationStatus === 'VERIFIED' ? 'badge badge-confirmed' : s.verificationStatus === 'SUSPENDED' ? 'badge badge-rejected' : 'badge badge-pending'}>
                        {s.verificationStatus}
                      </span>
                    </td>
                    <td>
                      <span className={s.isActive ? 'badge badge-confirmed' : 'badge badge-cancelled'}>
                        {s.isActive ? 'Online' : 'Offline'}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        {s.verificationStatus !== 'VERIFIED' && (
                          <button
                            onClick={() => updateStationStatus(s.id, { verificationStatus: 'VERIFIED' })}
                            className="btn-success"
                            style={{ padding: '3px 8px', fontSize: 11 }}
                          >
                            <Check size={12} /> Verify
                          </button>
                        )}
                        {s.verificationStatus !== 'SUSPENDED' && (
                          <button
                            onClick={() => updateStationStatus(s.id, { verificationStatus: 'SUSPENDED', isActive: false })}
                            className="btn-danger"
                            style={{ padding: '3px 8px', fontSize: 11 }}
                          >
                            <Ban size={12} /> Suspend
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
