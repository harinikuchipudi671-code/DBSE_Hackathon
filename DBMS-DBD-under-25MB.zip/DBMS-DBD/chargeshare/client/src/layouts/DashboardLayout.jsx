import { useState } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  Zap, LayoutDashboard, MapPin, Calendar,
  Settings, LogOut, ChevronLeft, ChevronRight, Plug,
  CreditCard, Home
} from 'lucide-react';
import NotificationBell from '../components/NotificationBell';

const homeownerNav = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/stations', icon: Plug, label: 'My Stations' },
  { to: '/reservations', icon: Calendar, label: 'Reservations' },
  { to: '/sessions', icon: Zap, label: 'Sessions' },
  { to: '/earnings', icon: CreditCard, label: 'Earnings' },
  { to: '/profile', icon: Settings, label: 'Profile' },
];

const evOwnerNav = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/find', icon: MapPin, label: 'Find Chargers' },
  { to: '/reservations', icon: Calendar, label: 'My Bookings' },
  { to: '/sessions', icon: Zap, label: 'Sessions' },
  { to: '/payments', icon: CreditCard, label: 'Payments' },
  { to: '/profile', icon: Settings, label: 'Profile' },
];

const adminNav = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Overview' },
  { to: '/admin/users', icon: Home, label: 'Users' },
  { to: '/admin/stations', icon: Plug, label: 'Stations' },
  { to: '/profile', icon: Settings, label: 'Settings' },
];

export default function DashboardLayout({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  const nav = user?.role === 'HOMEOWNER' ? homeownerNav : user?.role === 'ADMIN' ? adminNav : evOwnerNav;
  const roleLabel = user?.role === 'HOMEOWNER' ? 'Host' : user?.role === 'ADMIN' ? 'Admin' : 'Driver';

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const sidebarW = collapsed ? 64 : 230;

  // Derive current page title for the header
  const getPageTitle = () => {
    const path = location.pathname;
    if (path === '/dashboard') return 'Dashboard';
    if (path === '/find') return 'Find Chargers';
    if (path === '/stations') return 'My Charging Stations';
    if (path === '/reservations') return user?.role === 'HOMEOWNER' ? 'Booking Requests' : 'My Bookings';
    if (path === '/sessions') return 'Charging Sessions';
    if (path === '/earnings') return 'Host Earnings';
    if (path === '/payments') return 'Payments & Billing';
    if (path === '/profile') return 'Account Settings';
    if (path.includes('/admin/users')) return 'User Management';
    if (path.includes('/admin/stations')) return 'Station Moderation';
    return 'ChargeShare';
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#010102' }}>
      {/* Sidebar */}
      <aside
        style={{
          width: sidebarW,
          minHeight: '100vh',
          position: 'fixed',
          left: 0,
          top: 0,
          zIndex: 40,
          background: '#0f1011',
          borderRight: '1px solid #23252a',
          display: 'flex',
          flexDirection: 'column',
          transition: 'width 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
          overflow: 'hidden',
        }}
      >
        {/* Brand Header */}
        <div
          style={{
            height: 56,
            padding: '0 14px',
            borderBottom: '1px solid #23252a',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexShrink: 0,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, overflow: 'hidden' }}>
            <div
              style={{
                width: 28,
                height: 28,
                borderRadius: 6,
                flexShrink: 0,
                background: '#5e6ad2',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#ffffff',
              }}
            >
              <Zap size={16} fill="currentColor" stroke="none" />
            </div>
            {!collapsed && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontWeight: 600, fontSize: 14, color: '#f7f8f8', letterSpacing: '-0.02em' }}>
                  ChargeShare
                </span>
                <span
                  style={{
                    fontSize: 10,
                    fontWeight: 500,
                    padding: '1px 6px',
                    borderRadius: 999,
                    background: '#141516',
                    color: '#8a8f98',
                    border: '1px solid #23252a',
                    textTransform: 'uppercase',
                    letterSpacing: '0.04em',
                  }}
                >
                  {roleLabel}
                </span>
              </div>
            )}
          </div>

          <button
            onClick={() => setCollapsed(!collapsed)}
            aria-label="Toggle sidebar"
            style={{
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              color: '#62666d',
              padding: 4,
              borderRadius: 4,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'color 0.15s ease',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#f7f8f8')}
            onMouseLeave={(e) => (e.currentTarget.style.color = '#62666d')}
          >
            {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
          </button>
        </div>

        {/* User Card */}
        {!collapsed && (
          <div style={{ padding: '10px 10px 6px' }}>
            <div
              style={{
                padding: '8px 10px',
                borderRadius: 6,
                background: '#141516',
                border: '1px solid #23252a',
                display: 'flex',
                alignItems: 'center',
                gap: 10,
              }}
            >
              <div
                style={{
                  width: 26,
                  height: 26,
                  borderRadius: 4,
                  flexShrink: 0,
                  background: '#1e2024',
                  color: '#d0d6e0',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 11,
                  fontWeight: 600,
                  border: '1px solid #34343a',
                }}
              >
                {user?.fullName?.charAt(0).toUpperCase() || 'U'}
              </div>
              <div style={{ overflow: 'hidden', flex: 1 }}>
                <div
                  style={{
                    fontSize: 12,
                    fontWeight: 500,
                    color: '#f7f8f8',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    letterSpacing: '-0.01em',
                  }}
                >
                  {user?.fullName || 'User'}
                </div>
                <div
                  style={{
                    fontSize: 11,
                    color: '#8a8f98',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }}
                >
                  {user?.email}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Nav Items */}
        <nav style={{ flex: 1, padding: '10px 8px', display: 'flex', flexDirection: 'column', gap: 2 }}>
          {nav.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/dashboard'}
              title={collapsed ? label : undefined}
              style={({ isActive }) => ({
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: collapsed ? '9px 0' : '7px 10px',
                borderRadius: 6,
                textDecoration: 'none',
                fontSize: 13,
                fontWeight: isActive ? 500 : 400,
                transition: 'all 0.12s ease',
                justifyContent: collapsed ? 'center' : 'flex-start',
                background: isActive ? '#141516' : 'transparent',
                color: isActive ? '#f7f8f8' : '#8a8f98',
                border: isActive ? '1px solid #23252a' : '1px solid transparent',
              })}
            >
              {({ isActive }) => (
                <>
                  <Icon
                    size={16}
                    color={isActive ? '#5e6ad2' : '#8a8f98'}
                    style={{ flexShrink: 0 }}
                  />
                  {!collapsed && <span>{label}</span>}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Bottom Actions */}
        <div style={{ padding: '8px', borderTop: '1px solid #23252a' }}>
          <button
            onClick={handleLogout}
            title={collapsed ? 'Logout' : undefined}
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              padding: collapsed ? '9px 0' : '7px 10px',
              borderRadius: 6,
              border: 'none',
              background: 'transparent',
              color: '#8a8f98',
              fontSize: 13,
              fontWeight: 400,
              cursor: 'pointer',
              transition: 'all 0.15s ease',
              justifyContent: collapsed ? 'center' : 'flex-start',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = '#141516';
              e.currentTarget.style.color = '#eb5757';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.color = '#8a8f98';
            }}
          >
            <LogOut size={16} style={{ flexShrink: 0 }} />
            {!collapsed && <span>Sign Out</span>}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div
        style={{
          marginLeft: sidebarW,
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          minHeight: '100vh',
          transition: 'margin-left 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
      >
        {/* Top bar (56px) following design.md */}
        <header
          style={{
            height: 56,
            padding: '0 24px',
            borderBottom: '1px solid #23252a',
            background: '#010102',
            position: 'sticky',
            top: 0,
            zIndex: 30,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 13, color: '#62666d' }}>Platform</span>
            <span style={{ fontSize: 13, color: '#3e3e44' }}>/</span>
            <span style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8', letterSpacing: '-0.01em' }}>
              {getPageTitle()}
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <NotificationBell />
          </div>
        </header>

        {/* Page Content */}
        <main style={{ flex: 1, padding: '24px 28px', maxWidth: 1400, width: '100%', margin: '0 auto' }}>
          <div className="fade-in">{children}</div>
        </main>
      </div>
    </div>
  );
}
