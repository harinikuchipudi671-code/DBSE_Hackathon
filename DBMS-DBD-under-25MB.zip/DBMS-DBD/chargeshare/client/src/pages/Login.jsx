import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Zap, Eye, EyeOff, Mail, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      setLoading(true);
      await login(form.email, form.password);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const demoAccounts = [
    { role: 'Host', email: 'rajesh@example.com', pw: 'Password@123' },
    { role: 'Driver', email: 'arjun@example.com', pw: 'Password@123' },
    { role: 'Admin', email: 'admin@chargeshare.com', pw: 'Admin@123' },
  ];

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#010102',
        padding: '32px 20px',
      }}
    >
      <div style={{ width: '100%', maxWidth: 380 }}>
        {/* Brand */}
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <Link
            to="/"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              textDecoration: 'none',
              marginBottom: 16,
            }}
          >
            <div
              style={{
                width: 28,
                height: 28,
                borderRadius: 6,
                background: '#5e6ad2',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#ffffff',
              }}
            >
              <Zap size={16} fill="currentColor" stroke="none" />
            </div>
            <span style={{ fontWeight: 600, fontSize: 16, color: '#f7f8f8', letterSpacing: '-0.02em' }}>
              ChargeShare
            </span>
          </Link>
          <h1 style={{ fontSize: 20, fontWeight: 600, color: '#f7f8f8', letterSpacing: '-0.02em', marginBottom: 4 }}>
            Sign in to platform
          </h1>
          <p style={{ fontSize: 13, color: '#8a8f98' }}>Enter your credentials to access your account</p>
        </div>

        {/* Card */}
        <div
          style={{
            background: '#0f1011',
            border: '1px solid #23252a',
            borderRadius: 8,
            padding: '24px',
          }}
        >
          <form onSubmit={handleSubmit}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div>
                <label className="form-label">Email</label>
                <div style={{ position: 'relative' }}>
                  <Mail
                    size={15}
                    style={{
                      position: 'absolute',
                      left: 11,
                      top: '50%',
                      transform: 'translateY(-50%)',
                      color: '#62666d',
                    }}
                  />
                  <input
                    className="form-input"
                    style={{ paddingLeft: 34 }}
                    type="email"
                    placeholder="name@example.com"
                    value={form.email}
                    onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <label className="form-label">Password</label>
                </div>
                <div style={{ position: 'relative' }}>
                  <Lock
                    size={15}
                    style={{
                      position: 'absolute',
                      left: 11,
                      top: '50%',
                      transform: 'translateY(-50%)',
                      color: '#62666d',
                    }}
                  />
                  <input
                    className="form-input"
                    style={{ paddingLeft: 34, paddingRight: 36 }}
                    type={showPw ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={form.password}
                    onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw(!showPw)}
                    aria-label="Toggle password visibility"
                    style={{
                      position: 'absolute',
                      right: 10,
                      top: '50%',
                      transform: 'translateY(-50%)',
                      background: 'none',
                      border: 'none',
                      cursor: 'pointer',
                      color: '#62666d',
                      padding: 2,
                    }}
                  >
                    {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              {error && (
                <div
                  style={{
                    padding: '8px 12px',
                    borderRadius: 6,
                    background: 'rgba(235, 87, 87, 0.1)',
                    border: '1px solid rgba(235, 87, 87, 0.25)',
                    color: '#f87171',
                    fontSize: 12,
                    lineHeight: 1.4,
                  }}
                >
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="btn-primary"
                style={{ width: '100%', padding: '9px 16px', fontSize: 13, marginTop: 4 }}
              >
                {loading ? 'Authenticating...' : 'Continue'}
              </button>
            </div>
          </form>

          {/* Quick Demo Fill */}
          <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid #23252a' }}>
            <div style={{ fontSize: 11, color: '#62666d', textAlign: 'center', marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              Quick Demo Login
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
              {demoAccounts.map((a) => (
                <button
                  key={a.role}
                  type="button"
                  onClick={() => setForm({ email: a.email, password: a.pw })}
                  style={{
                    padding: '6px 8px',
                    borderRadius: 6,
                    border: '1px solid #23252a',
                    background: '#141516',
                    cursor: 'pointer',
                    textAlign: 'center',
                    transition: 'all 0.15s ease',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = '#34343a';
                    e.currentTarget.style.background = '#18191a';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = '#23252a';
                    e.currentTarget.style.background = '#141516';
                  }}
                >
                  <div style={{ fontSize: 12, fontWeight: 500, color: '#f7f8f8' }}>{a.role}</div>
                  <div style={{ fontSize: 10, color: '#62666d', fontFamily: 'monospace' }}>demo</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <p style={{ textAlign: 'center', marginTop: 20, fontSize: 12, color: '#8a8f98' }}>
          Don't have an account?{' '}
          <Link to="/register" style={{ color: '#5e6ad2', textDecoration: 'none', fontWeight: 500 }}>
            Create one
          </Link>
        </p>
      </div>
    </div>
  );
}
