const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const { startSession, completeSession, getSessionHistory, createPayment, getPaymentHistory } = require('../controllers/sessionController');
const { createReview, getNotifications, markRead, getAdminDashboard, getAdminUsers, getAdminStations, updateStationStatus } = require('../controllers/reviewController');

// Sessions
router.post('/sessions/start', authenticate, authorize('HOMEOWNER'), startSession);
router.patch('/sessions/:id/complete', authenticate, authorize('HOMEOWNER'), completeSession);
router.get('/sessions/history', authenticate, getSessionHistory);

// Payments
router.post('/payments', authenticate, authorize('EV_OWNER'), createPayment);
router.get('/payments/history', authenticate, getPaymentHistory);

// Reviews
router.post('/reviews', authenticate, authorize('EV_OWNER'), createReview);

// Notifications
router.get('/notifications', authenticate, getNotifications);
router.patch('/notifications/:id/read', authenticate, markRead);

// Admin
router.get('/admin/dashboard', authenticate, authorize('ADMIN'), getAdminDashboard);
router.get('/admin/users', authenticate, authorize('ADMIN'), getAdminUsers);
router.get('/admin/stations', authenticate, authorize('ADMIN'), getAdminStations);
router.patch('/admin/stations/:id/status', authenticate, authorize('ADMIN'), updateStationStatus);

module.exports = router;
