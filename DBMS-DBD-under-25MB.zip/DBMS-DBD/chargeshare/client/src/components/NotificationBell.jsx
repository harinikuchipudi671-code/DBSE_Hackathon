import { useState, useEffect, useRef } from 'react';
import { Bell, Check } from 'lucide-react';
import api from '../services/api';

export default function NotificationBell() {
  const [notifications, setNotifications] = useState([]);
  const [open, setOpen] = useState(false);
  const ref = useRef();

  const fetchNotifications = async () => {
    try {
      const res = await api.get('/notifications');
      setNotifications(res.data.data || []);
    } catch (e) {}
  };

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const unread = notifications.filter((n) => !n.isRead).length;

  const markAllRead = async () => {
    try {
      await api.patch('/notifications/all/read');
      fetchNotifications();
    } catch (e) {}
  };

  const typeIndicator = (type) => {
    switch (type) {
      case 'BOOKING':
        return '#5e6ad2';
      case 'SESSION':
        return '#27a644';
      case 'PAYMENT':
        return '#f59e0b';
      default:
        return '#8a8f98';
    }
  };

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button
        onClick={() => setOpen(!open)}
        aria-label="Notifications"
        style={{
          position: 'relative',
          background: '#0f1011',
          border: '1px solid #23252a',
          borderRadius: 6,
          padding: '6px 8px',
          cursor: 'pointer',
          color: unread > 0 ? '#f7f8f8' : '#8a8f98',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'all 0.15s ease',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.borderColor = '#34343a';
          e.currentTarget.style.background = '#141516';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.borderColor = '#23252a';
          e.currentTarget.style.background = '#0f1011';
        }}
      >
        <Bell size={16} />
        {unread > 0 && (
          <span
            style={{
              position: 'absolute',
              top: -3,
              right: -3,
              background: '#5e6ad2',
              color: '#ffffff',
              borderRadius: '9999px',
              padding: '0 4px',
              minWidth: 14,
              height: 14,
              fontSize: 9,
              fontWeight: 600,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              lineHeight: 1,
            }}
          >
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>

      {open && (
        <div
          style={{
            position: 'absolute',
            right: 0,
            top: 38,
            width: 340,
            zIndex: 100,
            background: '#0f1011',
            border: '1px solid #23252a',
            borderRadius: 8,
            boxShadow: '0 16px 36px rgba(0,0,0,0.7)',
            overflow: 'hidden',
          }}
        >
          <div
            style={{
              padding: '12px 14px',
              borderBottom: '1px solid #23252a',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              background: '#141516',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontSize: 13, fontWeight: 500, color: '#f7f8f8' }}>Notifications</span>
              {unread > 0 && (
                <span
                  style={{
                    fontSize: 11,
                    color: '#8a8f98',
                    background: '#18191a',
                    padding: '1px 6px',
                    borderRadius: 999,
                    border: '1px solid #23252a',
                  }}
                >
                  {unread} new
                </span>
              )}
            </div>
            {unread > 0 && (
              <button
                onClick={markAllRead}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#5e6ad2',
                  fontSize: 11,
                  fontWeight: 500,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 3,
                }}
              >
                <Check size={12} /> Mark read
              </button>
            )}
          </div>

          <div style={{ maxHeight: 340, overflowY: 'auto' }}>
            {notifications.length === 0 ? (
              <div style={{ padding: '28px 16px', textAlign: 'center', color: '#62666d', fontSize: 12 }}>
                No notifications yet
              </div>
            ) : (
              notifications.map((n) => (
                <div
                  key={n.id}
                  style={{
                    padding: '10px 14px',
                    borderBottom: '1px solid #18191a',
                    background: n.isRead ? 'transparent' : 'rgba(94, 106, 210, 0.05)',
                    transition: 'background 0.15s ease',
                  }}
                >
                  <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                    <div
                      style={{
                        width: 6,
                        height: 6,
                        borderRadius: '50%',
                        background: typeIndicator(n.notificationType),
                        flexShrink: 0,
                        marginTop: 5,
                      }}
                    />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 12, fontWeight: 500, color: '#f7f8f8', marginBottom: 2 }}>
                        {n.title}
                      </div>
                      <div style={{ fontSize: 12, color: '#8a8f98', lineHeight: 1.4 }}>
                        {n.message}
                      </div>
                      <div style={{ fontSize: 10, color: '#62666d', marginTop: 4, fontFamily: 'monospace' }}>
                        {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
